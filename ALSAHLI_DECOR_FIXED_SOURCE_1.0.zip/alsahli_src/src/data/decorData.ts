import heroBanner from '../assets/images/hero_decor_banner_1791004190285.jpg';
import gypsumImg from '../assets/images/gypsum_decor_craft_1791004201895.jpg';
import exteriorImg from '../assets/images/exterior_paint_villa_1791004212247.jpg';
import wallpaperImg from '../assets/images/wallpaper_texture_1791004224318.jpg';

export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  image: string;
  iconName: string;
  features: string[];
  materials: string[];
  duration: string;
  warranty: string;
  startingPrice: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'interior' | 'exterior' | 'gypsum' | 'wallpaper' | 'restoration' | 'decorative';
  categoryLabel: string;
  image: string;
  beforeImage?: string;
  location: string;
  description: string;
  specs: string[];
}

export interface TestimonialItem {
  id: string;
  name: string;
  city: string;
  rating: number;
  comment: string;
  service: string;
  date: string;
}

export interface ColorPaletteItem {
  name: string;
  code: string;
  hex: string;
  category: 'warm' | 'modern' | 'neutral' | 'luxury';
  categoryName: string;
  description: string;
}

export interface QuoteRequest {
  id: string;
  createdAt: string;
  clientName: string;
  phone: string;
  city?: string;
  governorate?: string;
  serviceId: string;
  serviceTitle: string;
  propertyType: string;
  areaEstimate: string;
  details?: string;
  notes?: string;
  images: string[];
  status?: string;
}

export const COMPANY_INFO = {
  name: 'السهلي للديكور',
  englishName: 'Al-Sahli Decor & Painting',
  tagline: 'رواد الدهانات الحديثة والديكورات العصرية في سوريا',
  phone: '0999746357',
  internationalPhone: '+963999746357',
  whatsapp: '963999746357',
  email: 'khaledsahli281@gmail.com',
  handle: 'ALSahliDecor',
  address: 'الجمهورية العربية السورية - دمشق وريف دمشق وكافة المحافظات (تغطية شاملة ومعاينة مجانية)',
  workingHours: 'يومياً: 8:00 صباحاً – 10:00 مساءً',
  experienceYears: '15+ سنة خبرة',
  completedProjects: '1,850+ مشروع',
  satisfiedClients: '99% نسبة رضا',
  warrantyYears: 'إتقان وجودة معتمدة',
};

export const SERVICES: ServiceItem[] = [
  {
    id: 'interior-paint',
    title: 'دهان داخلي',
    shortDesc: 'تنفيذ أجود أنواع الدهانات الداخلية بأحدث ألوان الموضة ولمسات متقنة للمنازل والفلل والمكاتب.',
    fullDesc: 'نقدم خدمات دهانات الجدران والأسقف الداخلية السادة والديكورية بأعلى مقاييس الجودة، مع معالجة وتأسيس كامل للأسطح باستخدام أفضل ماركات الدهانات المعتمدة (جوتن، أمية، كابارول) مع ضمان ثبات الألوان وسهولة التنظيف.',
    image: heroBanner,
    iconName: 'Paintbrush',
    features: [
      'تأسيس ومعجون بثلاث طبقات لصقل فائق النعومة',
      'دهانات مائية وبلاستيكية نصف لمعة ومطفية مقاومة للغسيل',
      'تناسق ألوان عصري وعينات تجريبية على الحائط مجاناً',
      'حماية وتغطية الأثاث والأرضيات بالكامل أثناء العمل'
    ],
    materials: ['جوتن فينوماستيك أصلي', 'دهانات أمية سوبر ديلوكس', 'معجون كابارول ألماني'],
    duration: '3 - 7 أيام حسب المساحة',
    warranty: 'جودة طلاء فائقة وثبات عالي للألوان وسهولة التنظيف',
    startingPrice: 'يبدأ من 35,000 ل.س / م²'
  },
  {
    id: 'exterior-paint',
    title: 'دهان خارجي',
    shortDesc: 'دهانات واجهات بروفايل ورشة عازلة للعوامل الجوية والحرارة الشديدة والرطوبة والأمطار.',
    fullDesc: 'تجديد ودهان واجهات المباني والفلل السكنية والتجارية بدهانات قوية مقاومة لأشعة الشمس والأتربة والأمطار، مع عزل مائي وحراري يطيل عمر المبنى ويمنحه مظهراً معمارياً فخماً وجذاباً.',
    image: exteriorImg,
    iconName: 'Building',
    features: [
      'دهان بروفايل ورشة خارجية بسماكات وملمس متعدد',
      'طلاء واجهات مقاوم للتشققات والأمطار والغبار',
      'تثبيت العوازل المائية والأساسات المقاومة للأملاح',
      'سقالات آمنة وفريق متخصص في المرتفعات والواجهات'
    ],
    materials: ['جوتاشيلد إكستريم عازل', 'بروفايل أكرليك مقاوم', 'أساسات نانو المقاومة للرطوبة'],
    duration: '5 - 14 يوم عمل',
    warranty: 'جودة مواد أصلية ومقاومة عالية لأشعة الشمس والأمطار',
    startingPrice: 'يبدأ من 55,000 ل.س / م²'
  },
  {
    id: 'gypsum-board',
    title: 'ديكور وجبس',
    shortDesc: 'تصميم وتنفيذ أسقف جبس بورد معلقة، إضاءة مخفية، بانوهات فوم، وبدائل الخشب والرخام.',
    fullDesc: 'تنفيذ أحدث ديكورات الأسقف المعلقة (جبس بورد كناوف مقاوم للرطوبة والحرائق)، وتصميم فتحات التكييف المخفي والسبوت لايت وليد ستريب، بالإضافة إلى تركيب براويز الفوم الكلاسيكية، وتكسيات الجدران الحديثة بديل الخشب وبديل الرخام.',
    image: gypsumImg,
    iconName: 'LayoutGrid',
    features: [
      'أسقف فلات ومستويات متعددة وإضاءة مخفية راقية',
      'تركيب شاسيهات حديد مجلفن متينة ومقاومة للهبوط',
      'براويز جدارية (بانوهات) فوم كلاسيكية ومودرن',
      'ألواح بديل الرخام UV وبديل الخشب المقاوم للماء'
    ],
    materials: ['جبس بورد كناوف معتمد', 'شاسيهات أوميجا وحديد مجلفن تركي ثقيل', 'معجون تيب وجبس ممتاز'],
    duration: '4 - 10 أيام عمل',
    warranty: 'سلامة الهياكل ودقة التثبيت الفني ومقاومة الهبوط',
    startingPrice: 'يبدأ من 120,000 ل.س / م²'
  },
  {
    id: 'wallpaper',
    title: 'ورق جدران',
    shortDesc: 'توريد وتركيب أفخم أنواع ورق الحائط ثلاثي الأبعاد والورق الكوري والأوروبي الفاخر.',
    fullDesc: 'تشكيلة واسعة من ورق الجدران العصري والكلاسيكي وثلاثي الأبعاد (3D)، خامات عالية السماكة مقاومة للرطوبة وسهلة التنظيف بالماء، مع قص وتركيب احترافي بدون أي فواصل مرئية.',
    image: wallpaperImg,
    iconName: 'Layers',
    features: [
      'ورق حائط كوري عريض بدون فواصل واضحة',
      'خامات فينيل وفايبر جلاس مقاومة للرطوبة والخدش',
      'تصاميم غرف النوم والصالونات والمجالس ومداخل الفلل',
      'استخدام غراء ميثيلان ألماني أصلي عديم الرائحة'
    ],
    materials: ['ورق جدران كوري وألماني معتمد', 'غراء ميثيلان ألماني الأصلي', 'طبقة حماية عازلة'],
    duration: '1 - 3 أيام',
    warranty: 'تماسك ممتاز للورق وقص دقيق بدون فواصل ظاهرة',
    startingPrice: 'يبدأ من 75,000 ل.س / رول تركيب'
  },
  {
    id: 'wall-restoration',
    title: 'ترميم ومعالجة الجدران',
    shortDesc: 'علاج تشققات الجدران والانتفاخات والرطوبة وعزل الأسطح وتجديد اللياسة القديمة.',
    fullDesc: 'حلول جذرية لجميع مشاكل الجدران مثل التقشير، التطبيل، الرطوبة، تشققات المباني، والشروخ الشعرية والعميقة. نقوم بحقن الفواصل، العزل المائي الكيميائي، وإعادة التأسيس والمعجنة لتعود الحوائط كالجديدة تماماً.',
    image: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=800&q=80',
    iconName: 'Wrench',
    features: [
      'كشف مصادر الرطوبة والنش والرشح الداخلي ومعالجتها أولاً',
      'حقن وتعبئة الشروخ بمعجون مرن فايبر مش متطور',
      'عزل مائي إيبوكسي وأكريليكي مانع للرطوبة والأملاح والتمليح',
      'صنفرة ميكانيكية متطورة خالية من الغبار لتسوية السطح'
    ],
    materials: ['فايبر مش شبكي مقوى', 'معجون شروخ مرن', 'عوازل سيكا وإيبوكسي معتمد'],
    duration: '2 - 5 أيام',
    warranty: 'معالجة فنية جذرية للنش والرطوبة وتأسيس قوي',
    startingPrice: 'يبدأ من 40,000 ل.س / م²'
  },
  {
    id: 'decorative-finishes',
    title: 'أعمال الزينة والديكور',
    shortDesc: 'دهانات ستوكو رخامي، خيال، روعة، شامواه، تعتيق فاخر ولمسات ميتاليك ساحرة.',
    fullDesc: 'تنفيذ الدهانات الفنية المتخصصة التي تحول الجدران إلى لوحات معمارية خلابة. ستوكو إيطالي ملمع كبديل الرخام الطبيعي، تأثيرات القطيفة والشامواه المخملية، المؤثرات المعدنية والخرسانية الصناعية الحديثة (Microcement).',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80',
    iconName: 'Sparkles',
    features: [
      'ستوكو مارمو إيطالي عالي اللمعان كالمرايا',
      'دهانات شامواه ومخملية دافئة للصالونات وغرف المعيشة',
      'تأثيرات الإسمنت المودرن (كونكريت ستايل) للمقاهي والفلل',
      'طلاء ورنيش حماية مائي يمنح لمعاناً وحماية من الأوساخ'
    ],
    materials: ['ستوكو كابارول إيطالي أصلي', 'دهانات شامواه ومخملية', 'بودرة ميكا وبويات ميتاليك'],
    duration: '3 - 6 أيام',
    warranty: 'ثبات التأثير الديكوري واللمعة ومقاومة بهتان الألوان',
    startingPrice: 'يبدأ من 85,000 ل.س / م²'
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'فيلا فاخرة - صالون استقبال رئيسي',
    category: 'interior',
    categoryLabel: 'دهان داخلي',
    image: heroBanner,
    beforeImage: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80',
    location: 'دمشق - مشروع دمر (الجزيرة 16)',
    description: 'تنفيذ دهانات داخلية بدرجات الأوف وايت مع حائط ديكوري بارز وتطبيق دقيق للأسطح.',
    specs: ['دهان سوبر ديلوكس', 'إضاءة محيطية مخفية', 'صنفرة ناعمة 100%']
  },
  {
    id: 'gal-2',
    title: 'تصميم وتنفيذ سقف جبس بورد مع إضاءة مخفية',
    category: 'gypsum',
    categoryLabel: 'ديكور وجبس',
    image: gypsumImg,
    beforeImage: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=800&q=80',
    location: 'دمشق - المزة فيلات غربية',
    description: 'تركيب جبس بورد مستويين مع مخابئ ليد ستريب وبديل خشب عمودي خلف السرير.',
    specs: ['جبس كناوف أصلي', 'بديل خشب مقوى', 'ليد وورم 3000K']
  },
  {
    id: 'gal-3',
    title: 'واجهة فيلا مودرن بدهان بروفايل عازل',
    category: 'exterior',
    categoryLabel: 'دهان خارجي',
    image: exteriorImg,
    location: 'ريف دمشق - يعفور',
    description: 'تجديد دهانات الواجهة بالكامل باستخدام بروفايل خارجي عازل للحرارة والرطوبة والأمطار.',
    specs: ['بروفايل أكرليك خارجي', 'مقاوم للشمس', 'عزل مائي كامل']
  },
  {
    id: 'gal-4',
    title: 'جدار ديكوري مميز بورق جدران ثلاثي الأبعاد',
    category: 'wallpaper',
    categoryLabel: 'ورق جدران',
    image: wallpaperImg,
    location: 'دمشق - المالكي',
    description: 'تركيب ورق جدران كوري فاخر بنقشات بارزة مذهبة لغرفة الطعام الرئيسية.',
    specs: ['ورق جدران كوري 3D', 'غراء ألماني أصلي', 'مقاوم للرطوبة']
  },
  {
    id: 'gal-5',
    title: 'ستوكو رخامي إيطالي لصالون ضيوف فخم',
    category: 'decorative',
    categoryLabel: 'أعمال الزينة والديكور',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80',
    beforeImage: 'https://images.unsplash.com/photo-1594897030560-692131648a03?auto=format&fit=crop&w=800&q=80',
    location: 'اللاذقية - الكورنيش الجنوبي',
    description: 'تطبيق ستوكو رخامي بملمس ناعم كالمرايا مع عروق رمادية وذهبية مستوحاة من رخام كلكتا الطبيعي.',
    specs: ['ستوكو مارمو إيطالي', 'لمعان بلوري', 'طبقة شمع حماية']
  },
  {
    id: 'gal-6',
    title: 'معالجة رطوبة ونش وترميم شقة سكنية متكاملة',
    category: 'restoration',
    categoryLabel: 'ترميم ومعالجة الجدران',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
    beforeImage: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=800&q=80',
    location: 'دمشق - كفرسوسة',
    description: 'إزالة التكلسات واللياسة التالفة وعزل الجدران كيميائياً ومعالجة الشروخ ثم إعادة التأسيس والدهان.',
    specs: ['عزل كيميائي سيكا', 'فايبر مش مقوى', 'إعادة تأسيس شاملة']
  },
  {
    id: 'gal-7',
    title: 'بانوهات فوم كلاسيكية وبويات أوف وايت حريرية',
    category: 'gypsum',
    categoryLabel: 'ديكور وجبس',
    image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=800&q=80',
    location: 'حمص - حي الإنشاءات',
    description: 'تنسيق براويز فوم كورية مع مقاسات هندسية متوازنة ودهان نهائي متطابق بأعلى دقة.',
    specs: ['فوم كوري مضغوط', 'طلاء نصف لمعة', 'تشطيب كلاسيكي']
  },
  {
    id: 'gal-8',
    title: 'دهان صالون ومجلس عصري بدرجات الجريج والبيج',
    category: 'interior',
    categoryLabel: 'دهان داخلي',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&q=80',
    location: 'حلب - حي الشهباء الجديدة',
    description: 'تنسيق ألوان ناعمة تمنح اتساعاً وإضاءة للمجلس مع طلاء متناسق وأبواب خشبية.',
    specs: ['دهان سوبر مطفي', 'ألوان متناسقة', 'أرضيات محمية']
  }
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't-1',
    name: 'المهندس وسيم العلي',
    city: 'دمشق (المزة)',
    rating: 5,
    comment: 'ما شاء الله تبارك الله، قمة في الأخلاق والاحترافية. تم دهان الشقة بالكامل وتركيب جبس بورد في وقت قياسي وبجودة فاقت توقعاتي. عمالة ماهرة ونظافة بعد العمل.',
    service: 'دهان داخلي وجبس بورد',
    date: 'قبل أسبوعين'
  },
  {
    id: 't-2',
    name: 'الدكتور حسان النجار',
    city: 'دمشق (مشروع دمر)',
    rating: 5,
    comment: 'تعاملت مع السهلي للديكور لترميم جدران شقتي ومعالجة النش والرطوبة والتشققات، الشغل ممتاز جداً ومتقن والضمان أعطاني راحة بال تامة. أسعارهم منافسة ومحترمة بالليرة السورية.',
    service: 'ترميم ومعالجة الرطوبة',
    date: 'قبل شهر'
  },
  {
    id: 't-3',
    name: 'رامي الصباغ',
    city: 'ريف دمشق (يعفور)',
    rating: 5,
    comment: 'أشكرهم على التنسيق والسرعة. طلبت عرض سعر من التطبيق وتواصلوا معي خلال نصف ساعة وتمت المعاينة المجانية في نفس اليوم. دهان البروفايل الخارجي طلع خيالي ومقاوم للمطر.',
    service: 'دهان خارجي بروفايل',
    date: 'قبل 3 أسابيع'
  }
];

export const COLOR_PALETTES: ColorPaletteItem[] = [
  {
    name: 'أوف وايت ناعم (Soft Off-White)',
    code: 'JTN-1024',
    hex: '#F4F2EC',
    category: 'neutral',
    categoryName: 'محايدة ومشرقة',
    description: 'اللون الأكثر طلباً للصالات والمجالس، يمنح اتساعاً وإشراقاً طبيعياً مع أي نوع أثاث.'
  },
  {
    name: 'كلاسيك جريج (Classic Greige)',
    code: 'JTN-10341',
    hex: '#D7D0C5',
    category: 'modern',
    categoryName: 'مودرن معاصر',
    description: 'مزيج فاخر بين البيج والرمادي، يعطي فخامة عصرية وهدوءاً للجدران الرئيسية.'
  },
  {
    name: 'بيج كشميري دافئ (Warm Cashmere)',
    code: 'JZ-2041',
    hex: '#EADBC8',
    category: 'warm',
    categoryName: 'دافئة ومريحة',
    description: 'درجة دافئة مميزة تمنح شعوراً بالحميمية والراحة، مناسبة لغرف النوم والمجالس العائلية.'
  },
  {
    name: 'رمادي لؤلؤي (Pearl Grey)',
    code: 'JTN-9918',
    hex: '#E1E3E2',
    category: 'neutral',
    categoryName: 'محايدة ومشرقة',
    description: 'رمادي فاتح جداً بانعكاس لؤلؤي، مثالي مع الديكورات الحديثة والإنارة البيضاء والصفراء.'
  },
  {
    name: 'أزرق بترولي ملكي (Royal Petrol)',
    code: 'JZ-8830',
    hex: '#1B3B4B',
    category: 'luxury',
    categoryName: 'ألوان مميزة ولكنتات',
    description: 'لون لكنت (Accent Wall) فخم للجدران خلف التلفزيون أو خلف السرير أو مداخل الضيوف.'
  },
  {
    name: 'أخضر ميرمية هادئ (Sage Green)',
    code: 'JTN-7628',
    hex: '#B2B9A6',
    category: 'modern',
    categoryName: 'مودرن معاصر',
    description: 'تريند عصري مستوحى من الطبيعة، يبعث على الاسترخاء والتجدد.'
  },
  {
    name: 'رملي صحراوي أنيق (Desert Sand)',
    code: 'JZ-3012',
    hex: '#CDBCA2',
    category: 'warm',
    categoryName: 'دافئة ومريحة',
    description: 'يتماشى تماماً مع براويز الفوم البيضاء والأسقف الجبسية المعلقة.'
  },
  {
    name: 'فحمي مطفي فاخر (Matte Charcoal)',
    code: 'JTN-9913',
    hex: '#303236',
    category: 'luxury',
    categoryName: 'ألوان مميزة ولكنتات',
    description: 'لون جريء وفخم للمكاتب والشاشات الديكورية وبدائل الخشب الإضاءة المخفية.'
  }
];

export const FAQS = [
  {
    question: 'كيف يتم احتساب سعر الدهان أو الديكور؟',
    answer: 'يتم احتساب السعر عادة بالمتر المربع (م²) أو بالمقطوعية للمشاريع المتكاملة، بناءً على نوع الدهان (عادي، ديكوري، بروفايل خارجي)، وحالة الجدران (هل تحتاج معالجة وتأسيس جديد)، ونوع المواد المطلوبة (جوتن، الجزيرة، كناوف). كما نقدم خدمة المعاينة الميدانية المجانية لتحديد السعر بدقة.'
  },
  {
    question: 'هل تقدمون معاينة وفحص مجاني في الموقع؟',
    answer: 'نعم بكل تأكيد! نوفر فنيين ومهندسي ديكور لزيارة موقعك مجاناً لمعاينة الجدران ورفع المقاسات وتقديم الكتالوجات وعينات الألوان واقتراح أفضل الحلول المناسبة لميزانيتك.'
  },
  {
    question: 'كيف تضمنون جودة العمل وما هي معاييركم؟',
    answer: 'نلتزم بأعلى معايير الإتقان الفني واستخدام المواد الأصلية المعتمدة من أفضل الماركات (جوتن، أمية، كابارول، كناوف)، مع تأسيس ومعجنة صحيحة للأسطح قبل الدهان، وإشراف فني دقيق لضمان تشطيب متقن يدوم طويلاً.'
  },
  {
    question: 'هل تقومون بحماية وتغطية الأثاث والأرضيات؟',
    answer: 'نعم، هذه خطوة أساسية وأولوية لدينا قبل بدء أي عمل دهان. نقوم بتغطية وتغليف الأثاث، الأرضيات (سيراميك، باركيه، رخام)، النوافذ، والأفياش بأشرطة لاصقة وبلاستيك نايلون مقوى لمنع أي تلوث أو رذاذ دهان.'
  },
  {
    question: 'كم يستغرق دهان شقة أو فيلا بالكامل؟',
    answer: 'شقة متوسطة (3 إلى 4 غرف) تستغرق عادة من 3 إلى 5 أيام عمل. أما الفلل السكنية فتستغرق من 7 إلى 14 يوم عمل حسب حجم الأعمال والجبس بورد المطلوب، مع الالتزام التام بالجدول الزمني المحدد بالعقد.'
  }
];
