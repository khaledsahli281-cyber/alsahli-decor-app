/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeTab } from './components/HomeTab';
import { ServicesTab } from './components/ServicesTab';
import { GalleryTab } from './components/GalleryTab';
import { QuoteTab } from './components/QuoteTab';
import { ContactTab } from './components/ContactTab';
import { CostCalculatorModal } from './components/CostCalculatorModal';
import { ColorPaletteModal } from './components/ColorPaletteModal';
import { MyOrdersModal } from './components/MyOrdersModal';
import { OwnerDashboard } from './components/OwnerDashboard';
import { OwnerLoginModal } from './components/OwnerLoginModal';
import { NotificationsModal } from './components/NotificationsModal';
import { ImageViewerModal } from './components/ImageViewerModal';
import { QuoteRequest } from './data/decorData';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(null);
  const [calculatorOpen, setCalculatorOpen] = useState(false);
  const [colorsOpen, setColorsOpen] = useState(false);
  const [ordersOpen, setOrdersOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [ownerLoginOpen, setOwnerLoginOpen] = useState(false);
  const [isOwnerLoggedIn, setIsOwnerLoggedIn] = useState(false);
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);
  const [orders, setOrders] = useState<QuoteRequest[]>([]);
  const [viewerImage, setViewerImage] = useState<{ url: string; title?: string } | null>(null);

  // Sync orders with Server API and localStorage
  const syncServerOrders = async () => {
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const data = await res.json();
        if (data.orders && Array.isArray(data.orders)) {
          setOrders((prev) => {
            const map = new Map<string, QuoteRequest>();
            data.orders.forEach((o: QuoteRequest) => map.set(o.id, o));
            prev.forEach((o: QuoteRequest) => {
              if (!map.has(o.id)) map.set(o.id, o);
            });
            const merged = Array.from(map.values());
            try {
              localStorage.setItem('alsahli_orders', JSON.stringify(merged));
            } catch {
              // quota
            }
            return merged;
          });
        }
      }
    } catch {
      // offline or dev
    }
  };

  // Load orders from localStorage on start and start polling server
  useEffect(() => {
    try {
      const saved = localStorage.getItem('alsahli_orders');
      if (saved) {
        setOrders(JSON.parse(saved));
      }
      const ownerSession = sessionStorage.getItem('alsahli_owner_auth');
      if (ownerSession === 'true') {
        setIsOwnerLoggedIn(true);
      }
      // Secret Admin URL trigger (?admin or ?owner)
      if (window.location.search.includes('admin') || window.location.search.includes('owner')) {
        setOwnerLoginOpen(true);
      }
    } catch {
      // ignore
    }

    // Sync PIN & Settings from server
    fetch('/api/settings')
      .then((res) => res.json())
      .then((data) => {
        if (data?.settings?.pin) {
          localStorage.setItem('alsahli_owner_pin', data.settings.pin);
        }
      })
      .catch(() => {});

    syncServerOrders();
    const interval = setInterval(syncServerOrders, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleOrderSaved = (newOrder: QuoteRequest) => {
    setOrders((prev) => [newOrder, ...prev.filter(o => o.id !== newOrder.id)]);
    // Also trigger sound or notification
  };

  const handleClearOrders = () => {
    try {
      localStorage.removeItem('alsahli_my_order_ids');
    } catch {
      // ignore
    }
  };

  const handleSelectServiceFromHome = (serviceId: string) => {
    setSelectedServiceId(serviceId);
    setActiveTab('services');
  };

  const handleSelectServiceForQuote = (serviceId?: string) => {
    if (serviceId) {
      setSelectedServiceId(serviceId);
    }
    setActiveTab('quote');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleApplyCalculatorToQuote = (details: string, area: string) => {
    setActiveTab('quote');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Scroll to top on tab change
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOwnerLoginSuccess = () => {
    setIsOwnerLoggedIn(true);
    try {
      sessionStorage.setItem('alsahli_owner_auth', 'true');
    } catch {
      // ignore
    }
    setOwnerLoginOpen(false);
    handleTabChange('owner');
  };

  const handleExitOwner = () => {
    handleTabChange('home');
  };

  const handleLogoutOwner = () => {
    setIsOwnerLoggedIn(false);
    try {
      sessionStorage.removeItem('alsahli_owner_auth');
      localStorage.removeItem('alsahli_owner_auth');
    } catch {
      // ignore
    }
    handleTabChange('home');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start antialiased selection:bg-amber-500 selection:text-slate-950 font-['Cairo',sans-serif]">
      {/* Device wrapper container: If isPhoneFrame is true on md+ screens, wrap in phone mockup; otherwise full responsive */}
      <div className={`w-full transition-all duration-300 ${
        isPhoneFrame 
          ? 'max-w-md sm:my-4 sm:rounded-[40px] sm:border-[8px] sm:border-slate-800 sm:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden bg-slate-950 relative min-h-screen sm:min-h-[850px]'
          : 'max-w-4xl mx-auto'
      }`}>
        {/* Header */}
        <Header
          activeTab={activeTab}
          setActiveTab={handleTabChange}
          isPhoneFrame={isPhoneFrame}
          setIsPhoneFrame={setIsPhoneFrame}
          ordersCount={orders.length}
          onOpenOrders={() => setOrdersOpen(true)}
          onOpenNotifications={() => setNotificationsOpen(true)}
          onOpenCalculator={() => setCalculatorOpen(true)}
          onOpenColors={() => setColorsOpen(true)}
          isOwnerLoggedIn={isOwnerLoggedIn}
          onOpenOwnerLogin={() => setOwnerLoginOpen(true)}
        />

        {/* Tab Content */}
        <main className="p-3.5 sm:p-5">
          {activeTab === 'home' && (
            <HomeTab
              setActiveTab={handleTabChange}
              onSelectService={handleSelectServiceFromHome}
              onOpenCalculator={() => setCalculatorOpen(true)}
              onOpenColors={() => setColorsOpen(true)}
            />
          )}

          {activeTab === 'services' && (
            <ServicesTab
              onSelectServiceForQuote={handleSelectServiceForQuote}
              selectedServiceId={selectedServiceId}
            />
          )}

          {activeTab === 'gallery' && (
            <GalleryTab
              onSelectServiceForQuote={handleSelectServiceForQuote}
            />
          )}

          {activeTab === 'quote' && (
            <QuoteTab
              initialServiceId={selectedServiceId}
              onOrderSaved={handleOrderSaved}
              onOpenImage={(url, title) => setViewerImage({ url, title })}
            />
          )}

          {activeTab === 'contact' && (
            <ContactTab />
          )}

          {activeTab === 'owner' && (
            <OwnerDashboard
              onExit={handleExitOwner}
              onLogout={handleLogoutOwner}
              orders={orders}
              onUpdateOrder={setOrders}
              onOpenImage={(url, title) => setViewerImage({ url, title })}
            />
          )}
        </main>

        {/* Bottom Navigation (Customer tabs - only when not in owner dashboard) */}
        {activeTab !== 'owner' && (
          <BottomNav
            activeTab={activeTab}
            setActiveTab={handleTabChange}
          />
        )}

        {/* Modals */}
        <NotificationsModal
          isOpen={notificationsOpen}
          onClose={() => setNotificationsOpen(false)}
          orders={orders}
          onOpenImage={(imgUrl, title) => setViewerImage({ url: imgUrl, title })}
          isOwnerLoggedIn={isOwnerLoggedIn}
          onOpenOwnerLogin={() => setOwnerLoginOpen(true)}
        />

        <ImageViewerModal
          imageUrl={viewerImage?.url || null}
          title={viewerImage?.title}
          onClose={() => setViewerImage(null)}
        />

        <CostCalculatorModal
          isOpen={calculatorOpen}
          onClose={() => setCalculatorOpen(false)}
          onApplyToQuote={handleApplyCalculatorToQuote}
        />

        <ColorPaletteModal
          isOpen={colorsOpen}
          onClose={() => setColorsOpen(false)}
        />

        <MyOrdersModal
          isOpen={ordersOpen}
          onClose={() => setOrdersOpen(false)}
          orders={orders.filter((o) => {
            try {
              const myIds = JSON.parse(localStorage.getItem('alsahli_my_order_ids') || '[]');
              return Array.isArray(myIds) && myIds.includes(o.id);
            } catch {
              return false;
            }
          })}
          onClearOrders={handleClearOrders}
          onOpenImage={(url, title) => setViewerImage({ url, title })}
        />

        <OwnerLoginModal
          isOpen={ownerLoginOpen}
          onClose={() => setOwnerLoginOpen(false)}
          onSuccess={handleOwnerLoginSuccess}
        />
      </div>
    </div>
  );
}
