import React, { useState, useEffect } from 'react';
import { 
  Users, 
  DollarSign, 
  Settings, 
  Share2, 
  LogOut, 
  Phone, 
  MessageCircle, 
  Clock, 
  CheckCircle2, 
  Trash2, 
  Search, 
  Sparkles, 
  Copy, 
  Check, 
  Download, 
  ExternalLink,
  ShieldCheck,
  Save,
  RotateCcw,
  Eye,
  KeyRound,
  Layers,
  MapPin,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { QuoteRequest, COMPANY_INFO, SERVICES } from '../data/decorData';
import { normalizePin } from './OwnerLoginModal';

interface OwnerDashboardProps {
  onExit: () => void;
  onLogout?: () => void;
  orders: QuoteRequest[];
  onUpdateOrder: (updatedOrders: QuoteRequest[]) => void;
  onOpenImage?: (url: string, title?: string) => void;
}

export const OwnerDashboard: React.FC<OwnerDashboardProps> = ({
  onExit,
  onLogout,
  orders,
  onUpdateOrder,
  onOpenImage
}) => {
  const [activeTab, setActiveTab] = useState<'leads' | 'pricing' | 'settings' | 'share'>('leads');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [copiedLink, setCopiedLink] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');

  // Contact Info Settings State
  const [phone, setPhone] = useState(COMPANY_INFO.phone);
  const [whatsapp, setWhatsapp] = useState(COMPANY_INFO.whatsapp);
  const [email, setEmail] = useState(COMPANY_INFO.email);
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [pinMsg, setPinMsg] = useState('');

  // Prices State (persisted in localStorage)
  const defaultPrices: Record<string, number> = {
    'interior-paint': 35000,
    'exterior-paint': 55000,
    'gypsum-board': 120000,
    'wallpaper': 75000,
    'wall-restoration': 40000,
    'decorative-finishes': 85000,
  };

  const [prices, setPrices] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('alsahli_custom_prices');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return defaultPrices;
  });

  // Load custom contact settings if saved
  useEffect(() => {
    try {
      const savedContact = localStorage.getItem('alsahli_owner_contact');
      if (savedContact) {
        const parsed = JSON.parse(savedContact);
        if (parsed.phone) setPhone(parsed.phone);
        if (parsed.whatsapp) setWhatsapp(parsed.whatsapp);
        if (parsed.email) setEmail(parsed.email);
      }
    } catch {
      // ignore
    }
  }, []);

  const handlePriceChange = (serviceId: string, value: string) => {
    const num = parseInt(value.replace(/[^0-9]/g, '')) || 0;
    setPrices(prev => ({ ...prev, [serviceId]: num }));
  };

  const handleSavePrices = () => {
    try {
      localStorage.setItem('alsahli_custom_prices', JSON.stringify(prices));
      setSaveSuccessMsg('تم حفظ وتحديث الأسعار التقديرية بنجاح!');
      setTimeout(() => setSaveSuccessMsg(''), 3000);
    } catch {
      // ignore
    }
  };

  const handleResetPrices = () => {
    setPrices(defaultPrices);
    try {
      localStorage.removeItem('alsahli_custom_prices');
      setSaveSuccessMsg('تمت استعادة الأسعار الافتراضية.');
      setTimeout(() => setSaveSuccessMsg(''), 3000);
    } catch {
      // ignore
    }
  };

  const handleSaveContact = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = { phone, whatsapp, email };
      localStorage.setItem('alsahli_owner_contact', JSON.stringify(data));
      setSaveSuccessMsg('تم حفظ بيانات التواصل الرسمية بنجاح!');
      setTimeout(() => setSaveSuccessMsg(''), 3000);
    } catch {
      // ignore
    }
  };

  const handleChangePin = async (e: React.FormEvent) => {
    e.preventDefault();
    const storedPin = localStorage.getItem('alsahli_owner_pin') || '2026';
    const cleanCurrent = normalizePin(currentPin);
    const cleanStored = normalizePin(storedPin);

    if (cleanCurrent !== cleanStored && cleanCurrent !== '2026') {
      setPinMsg('الرمز الحالي غير صحيح! تأكد من كتابته بشكل دقيق.');
      return;
    }
    const cleanNew = normalizePin(newPin);
    if (cleanNew.length < 4) {
      setPinMsg('يجب أن يتكون الرمز الجديد من 4 خانات على الأقل');
      return;
    }

    // Save locally
    localStorage.setItem('alsahli_owner_pin', cleanNew);

    // Sync to backend server so it works across all devices
    try {
      await fetch('/api/settings/pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: cleanNew }),
      });
    } catch {
      // offline fallback
    }

    setCurrentPin('');
    setNewPin('');
    setPinMsg(`✅ تم تعيين وحفظ رمز الأمان الجديد بنجاح (${cleanNew})!`);
    setTimeout(() => setPinMsg(''), 5000);
  };

  // Orders Status Update
  const handleStatusChange = (orderId: string, newStatus: string) => {
    const updated = orders.map(ord => ord.id === orderId ? { ...ord, status: newStatus } : ord);
    onUpdateOrder(updated);
    try {
      localStorage.setItem('alsahli_orders', JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleDeleteOrder = (orderId: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذا الطلب نهائياً؟')) {
      const updated = orders.filter(ord => ord.id !== orderId);
      onUpdateOrder(updated);
      try {
        localStorage.setItem('alsahli_orders', JSON.stringify(updated));
      } catch {
        // ignore
      }
    }
  };

  // Filtering orders
  const filteredOrders = orders.filter(ord => {
    const matchSearch = 
      (ord.clientName && ord.clientName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (ord.phone && ord.phone.includes(searchTerm)) ||
      (ord.governorate && ord.governorate.includes(searchTerm)) ||
      (ord.serviceTitle && ord.serviceTitle.includes(searchTerm));
    
    const matchStatus = filterStatus === 'all' || (ord.status || 'new') === filterStatus;
    return matchSearch && matchStatus;
  });

  const sharedAppUrl = 'https://ais-pre-37nwxmk65pwm3u55obcebd-711257153436.us-west2.run.app';

  const handleCopyCleanUrl = () => {
    navigator.clipboard.writeText(sharedAppUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleShareToClients = () => {
    const text = `السلام عليكم ورحمة الله،\nيسر إدارة «السهلي للديكور» دعوتكم لطلب عروض الأسعار وحساب التكلفة ومعاينة الخدمات عبر تطبيقنا المباشر:\n${sharedAppUrl}`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="space-y-5 pb-24 text-right">
      {/* Top Banner: Owner Identity & Exit */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 text-slate-950 shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-slate-950 text-amber-400 flex items-center justify-center font-black shadow-md">
            VIP
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="font-black text-base sm:text-lg text-slate-950">
                لوحة تحكم وإدارة المالك
              </h2>
              <span className="text-[10px] font-bold bg-slate-950 text-amber-300 px-2 py-0.5 rounded-full">
                السهلي للديكور
              </span>
            </div>
            <p className="text-[11px] font-bold text-slate-900/80">
              إدارة طلبات الزبائن، والأسعار، وإعدادات المتجر
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Preview Customer View */}
          <button
            onClick={onExit}
            className="bg-slate-950 hover:bg-slate-900 active:scale-95 text-amber-400 font-bold text-xs py-2 px-2.5 sm:px-3 rounded-xl flex items-center gap-1.5 transition-all shadow-md"
            title="الخروج إلى واجهة الزبائن"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">واجهة الزبون</span>
          </button>

          {/* Logout & Lock */}
          {onLogout && (
            <button
              onClick={onLogout}
              className="bg-rose-950/80 hover:bg-rose-900 active:scale-95 text-rose-300 font-bold text-xs py-2 px-2.5 sm:px-3 rounded-xl flex items-center gap-1 transition-all shadow border border-rose-800/40"
              title="تسجيل الخروج وقفل لوحة المالك"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>قفل</span>
            </button>
          )}
        </div>
      </div>

      {saveSuccessMsg && (
        <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl text-emerald-400 text-xs font-bold text-center animate-fade-in flex items-center justify-center gap-1.5">
          <CheckCircle2 className="w-4 h-4" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {/* Owner Navigation Tabs */}
      <div className="grid grid-cols-4 gap-1.5 p-1 bg-slate-900 rounded-2xl border border-slate-800">
        <button
          onClick={() => setActiveTab('leads')}
          className={`py-2.5 px-1 rounded-xl text-xs font-black transition-all flex flex-col items-center justify-center gap-1 ${
            activeTab === 'leads'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-1">
            <Users className="w-3.5 h-3.5" />
            <span>الطلبات</span>
          </div>
          <span className="text-[10px] opacity-80">({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('pricing')}
          className={`py-2.5 px-1 rounded-xl text-xs font-black transition-all flex flex-col items-center justify-center gap-1 ${
            activeTab === 'pricing'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-1">
            <DollarSign className="w-3.5 h-3.5" />
            <span>الأسعار</span>
          </div>
          <span className="text-[10px] opacity-80">(ل.س)</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`py-2.5 px-1 rounded-xl text-xs font-black transition-all flex flex-col items-center justify-center gap-1 ${
            activeTab === 'settings'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-1">
            <Settings className="w-3.5 h-3.5" />
            <span>الإعدادات</span>
          </div>
          <span className="text-[10px] opacity-80">وكلمة السر</span>
        </button>

        <button
          onClick={() => setActiveTab('share')}
          className={`py-2.5 px-1 rounded-xl text-xs font-black transition-all flex flex-col items-center justify-center gap-1 ${
            activeTab === 'share'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-1">
            <Share2 className="w-3.5 h-3.5" />
            <span>النشر</span>
          </div>
          <span className="text-[10px] opacity-80">ورابط الزبائن</span>
        </button>
      </div>

      {/* TAB 1: CUSTOMER LEADS & QUOTE REQUESTS */}
      {activeTab === 'leads' && (
        <div className="space-y-4">
          {/* Search & Filter Header */}
          <div className="bg-slate-900 p-3.5 rounded-3xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-sm text-white flex items-center gap-2">
                <span>طلبات عروض الأسعار المستلمة من الزبائن</span>
                <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-mono">
                  {filteredOrders.length}
                </span>
              </h3>
            </div>

            {/* Search Input */}
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث باسم الزبون، رقم الهاتف، أو المحافظة..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-2xl py-2.5 pr-9 pl-3 text-xs text-white placeholder-slate-500 outline-none transition-all"
              />
              <Search className="w-4 h-4 text-slate-500 absolute top-3 right-3" />
            </div>

            {/* Status Filter Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 text-[11px]">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'new', label: 'جديد' },
                { id: 'inspecting', label: 'قيد المعاينة' },
                { id: 'agreed', label: 'تم الاتفاق' },
                { id: 'completed', label: 'مكتمل' }
              ].map(st => (
                <button
                  key={st.id}
                  onClick={() => setFilterStatus(st.id)}
                  className={`px-3 py-1 rounded-full whitespace-nowrap font-bold transition-all ${
                    filterStatus === st.id
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>
          </div>

          {/* Orders List */}
          {filteredOrders.length === 0 ? (
            <div className="p-8 text-center bg-slate-900/50 rounded-3xl border border-slate-800 space-y-3">
              <Users className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="text-xs text-slate-300 font-bold">لا توجد طلبات تطابق بحثك حالياً</p>
              <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                عندما يطلب أي زبون عرض سعر من التطبيق عبر نموذج «طلب سعر»، ستظهر بياناته هنا فوراً للتواصل معه.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredOrders.map((ord) => {
                const status = ord.status || 'new';
                return (
                  <div
                    key={ord.id}
                    className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all space-y-3 shadow-lg"
                  >
                    {/* Header */}
                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                        <span className="font-extrabold text-sm text-white">{ord.clientName}</span>
                        <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">
                          #{ord.id}
                        </span>
                      </div>

                      {/* Status Selector */}
                      <select
                        value={status}
                        onChange={(e) => handleStatusChange(ord.id, e.target.value)}
                        className={`text-[10px] font-bold py-1 px-2 rounded-xl outline-none border cursor-pointer ${
                          status === 'new'
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : status === 'inspecting'
                            ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                            : status === 'agreed'
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            : 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                        }`}
                      >
                        <option value="new" className="bg-slate-900 text-white">جديد 🟢</option>
                        <option value="inspecting" className="bg-slate-900 text-white">قيد المعاينة 🟡</option>
                        <option value="agreed" className="bg-slate-900 text-white">تم الاتفاق 🔵</option>
                        <option value="completed" className="bg-slate-900 text-white">مكتمل ومسلّم 🏁</option>
                        <option value="cancelled" className="bg-slate-900 text-white">ملغي ❌</option>
                      </select>
                    </div>

                    {/* Details Grid */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="bg-slate-950/60 p-2.5 rounded-2xl border border-slate-800/60">
                        <span className="text-[10px] text-slate-500 block mb-0.5">الخدمة المطلوبة:</span>
                        <span className="font-bold text-amber-400">{ord.serviceTitle}</span>
                      </div>

                      <div className="bg-slate-950/60 p-2.5 rounded-2xl border border-slate-800/60">
                        <span className="text-[10px] text-slate-500 block mb-0.5">المحافظة / الموقع:</span>
                        <span className="font-bold text-white flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          {ord.governorate || 'سوريا'}
                        </span>
                      </div>

                      <div className="bg-slate-950/60 p-2.5 rounded-2xl border border-slate-800/60">
                        <span className="text-[10px] text-slate-500 block mb-0.5">نوع العقار والمساحة:</span>
                        <span className="font-bold text-slate-200">{ord.propertyType} - {ord.areaEstimate}</span>
                      </div>

                      <div className="bg-slate-950/60 p-2.5 rounded-2xl border border-slate-800/60">
                        <span className="text-[10px] text-slate-500 block mb-0.5">تاريخ الإرسال:</span>
                        <span className="font-medium text-slate-400 text-[11px] flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {ord.createdAt}
                        </span>
                      </div>
                    </div>

                    {/* Notes if any */}
                    {ord.notes && (
                      <div className="p-2.5 bg-slate-950/80 rounded-2xl border border-slate-800/80 text-[11px] text-slate-300">
                        <span className="text-slate-500 block text-[10px] mb-0.5 font-bold">ملاحظات الزبون:</span>
                        <p className="leading-relaxed">{ord.notes}</p>
                      </div>
                    )}

                    {/* Images if attached */}
                    {ord.images && ord.images.length > 0 && (
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-slate-400 font-bold">صور مرفقة من الزبون ({ord.images.length}):</span>
                          <span className="text-[10px] text-amber-400 font-medium">اضغط لتكبير الصورة</span>
                        </div>
                        <div className="flex gap-2 overflow-x-auto py-1">
                          {ord.images.map((img, i) => (
                            <div
                              key={i}
                              onClick={() => onOpenImage && onOpenImage(img, `صورة ${i + 1} من ${ord.clientName}`)}
                              className="relative cursor-pointer group shrink-0 rounded-xl overflow-hidden border border-slate-700 hover:border-amber-400 transition-all"
                            >
                              <img
                                src={img}
                                alt="صورة العقار"
                                className="w-16 h-16 object-cover group-hover:scale-105 transition-transform"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Contact Buttons */}
                    <div className="flex items-center gap-2 pt-1 border-t border-slate-800/80">
                      {/* WhatsApp Button */}
                      <a
                        href={`https://wa.me/${ord.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                          `السلام عليكم ورحمة الله، أهلاً بك أخي ${ord.clientName} معك إدارة «السهلي للديكور» بخصوص طلبكم لعرض سعر ${ord.serviceTitle} رقم #${ord.id}. يسعدنا ترتيب موعد المعاينة المجانية في ${ord.governorate}.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-xs py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 shadow"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>واتساب الزبون</span>
                      </a>

                      {/* Direct Phone Call */}
                      <a
                        href={`tel:${ord.phone}`}
                        className="bg-slate-800 hover:bg-slate-750 active:scale-95 text-slate-200 font-bold text-xs py-2 px-3 rounded-xl transition-all border border-slate-700 flex items-center gap-1"
                        title="اتصال هاتفي"
                      >
                        <Phone className="w-3.5 h-3.5 text-amber-400" />
                        <span>اتصال ({ord.phone})</span>
                      </a>

                      {/* Delete */}
                      <button
                        onClick={() => handleDeleteOrder(ord.id)}
                        className="w-8 h-8 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 flex items-center justify-center shrink-0"
                        title="حذف الطلب"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PRICING MANAGEMENT */}
      {activeTab === 'pricing' && (
        <div className="bg-slate-900 p-4 sm:p-5 rounded-3xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="font-extrabold text-sm text-white">إدارة وضبط الأسعار التقديرية (ل.س)</h3>
              <p className="text-[11px] text-slate-400">تعديل سعر المتر المربع لكل خدمة بناءً على أسعار السوق السورية</p>
            </div>
            <button
              onClick={handleResetPrices}
              className="text-[11px] text-slate-400 hover:text-amber-400 flex items-center gap-1 underline"
            >
              <RotateCcw className="w-3 h-3" />
              <span>استعادة الافتراضي</span>
            </button>
          </div>

          <div className="space-y-3">
            {SERVICES.map((srv) => (
              <div
                key={srv.id}
                className="p-3 bg-slate-950/70 rounded-2xl border border-slate-800 flex items-center justify-between gap-3"
              >
                <div className="text-right flex-1">
                  <h4 className="font-bold text-xs text-white mb-0.5">{srv.title}</h4>
                  <p className="text-[10px] text-slate-400">{srv.shortDesc}</p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <input
                    type="text"
                    value={(prices[srv.id] || 0).toLocaleString()}
                    onChange={(e) => handlePriceChange(srv.id, e.target.value)}
                    className="w-24 text-center font-mono font-bold text-xs bg-slate-900 border border-slate-700 focus:border-amber-400 text-amber-300 py-1.5 px-2 rounded-xl outline-none"
                  />
                  <span className="text-[10px] text-slate-400">ل.س/م²</span>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={handleSavePrices}
            className="w-full bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs py-3 rounded-2xl transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>حفظ الأسعار وتحديث التطبيق</span>
          </button>
        </div>
      )}

      {/* TAB 3: OWNER SETTINGS & PIN */}
      {activeTab === 'settings' && (
        <div className="space-y-4">
          {/* Contact Info Form */}
          <div className="bg-slate-900 p-4 sm:p-5 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="font-extrabold text-sm text-white border-b border-slate-800 pb-2">
              تعديل بيانات التواصل الرسمية للسهلي للديكور
            </h3>

            <form onSubmit={handleSaveContact} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">رقم الهاتف للاتصال المباشر:</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2 px-3 text-xs text-white outline-none font-mono"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">رقم الواتساب مع رمز الدولة (بدون +):</label>
                <input
                  type="text"
                  value={whatsapp}
                  onChange={(e) => setWhatsapp(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2 px-3 text-xs text-white outline-none font-mono"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">البريد الإلكتروني الرسمي:</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2 px-3 text-xs text-white outline-none font-mono"
                  dir="ltr"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs py-2.5 rounded-xl transition-all shadow flex items-center justify-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>حفظ بيانات التواصل</span>
              </button>
            </form>
          </div>

          {/* Change Security PIN */}
          <div className="bg-slate-900 p-4 sm:p-5 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="font-extrabold text-sm text-white border-b border-slate-800 pb-2 flex items-center gap-1.5">
              <KeyRound className="w-4 h-4 text-amber-400" />
              <span>تغيير رمز PIN السري للمالك</span>
            </h3>

            {pinMsg && (
              <p className={`text-xs font-bold text-center ${pinMsg.includes('✅') ? 'text-emerald-400' : 'text-rose-400'}`}>
                {pinMsg}
              </p>
            )}

            <form onSubmit={handleChangePin} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">رمز الدخول السري الحالي للمالك:</label>
                <input
                  type="password"
                  value={currentPin}
                  onChange={(e) => setCurrentPin(e.target.value)}
                  placeholder="أدخل الرمز السري الحالي"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2 px-3 text-xs text-white outline-none text-center font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">الرمز السري الجديد (أرقام):</label>
                <input
                  type="text"
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value)}
                  placeholder="أدخل الرمز الجديد مثلاً: 7788"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2 px-3 text-xs text-white outline-none text-center font-mono tracking-widest text-base"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-bold text-xs py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5"
              >
                <span>تحديث وحفظ رمز الأمان</span>
              </button>
            </form>

            <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800/80 text-[10px] text-slate-400 text-center">
              💡 <span className="text-amber-400 font-bold">ملاحظة أمان للمالك:</span> الرمز الرئيسي الافتراضي <strong className="text-white font-mono">2026</strong> يظل فعالاً كرمز طوارئ احتياطي دائم في حال نسيان الرمز الجديد.
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SAFE SHARING & GOOGLE PLAY */}
      {activeTab === 'share' && (
        <div className="bg-slate-900 p-4 sm:p-5 rounded-3xl border border-slate-800 space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="font-extrabold text-sm text-white">الرابط المخصص للزبائن والأصدقاء (آمن 100%)</h3>
            <p className="text-[11px] text-slate-400">
              هذا هو الرابط الوحيد الذي يجب مشاركته؛ فهو يفتح واجهة الزبائن فقط ولا يتيح لأي شخص تعديل أي شيء!
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
            <span className="text-[10px] text-slate-500 font-mono block">رابط الزبائن المباشر:</span>
            <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 text-[11px] font-mono text-amber-400 break-all select-all">
              {sharedAppUrl}
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={handleCopyCleanUrl}
                className="bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-bold text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'تم نسخ الرابط!' : 'نسخ الرابط'}</span>
              </button>

              <button
                onClick={handleShareToClients}
                className="bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>إرسال بالواتساب</span>
              </button>
            </div>
          </div>

          {/* Explanation Warning */}
          <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-[11px] text-slate-300 space-y-1.5">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>ملاحظة هامة جداً بخصوص الروابط:</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-400 text-[10px] leading-relaxed pr-1">
              <li>
                <strong>رابط الزبائن (المذكور أعلاه):</strong> آمن للقراءة والطلب فقط، ولا تظهر فيه لوحة تحكم المالك إلا برمز PIN.
              </li>
              <li>
                <strong>رابط بيئة التطوير (AI Studio):</strong> هذا الرابط خاص بك كمالك فقط ولا ترسله لأصدقائك أبداً لأنه مخصص لكتابة الأوامر وتعديل البرمجة.
              </li>
            </ul>
          </div>

          {/* Android Native Project & Google Play Section */}
          <div className="p-4 bg-slate-950 rounded-2xl border border-amber-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-white flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                <span>مشروع Android Native أصلي (Kotlin + Compose)</span>
              </span>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded border border-amber-500/30">
                جاهز لـ Google Play
              </span>
            </div>

            <div className="space-y-1.5 text-[11px] text-slate-300 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">اسم التطبيق:</span>
                <span className="font-bold text-white">السهلي للديكور</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Package Name:</span>
                <span className="font-mono text-amber-400 font-bold">com.alsahli.decor</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">الإصدار:</span>
                <span className="text-slate-200">Version 1.0.0 (Code: 1)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">التقنية:</span>
                <span className="text-emerald-400 font-bold">100% Kotlin + Jetpack Compose</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Target SDK:</span>
                <span className="font-mono text-emerald-400 font-bold">API 36 (Android 16) - متوافق مع متطلبات 2026</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">صيغة النشر:</span>
                <span className="text-slate-200">Android App Bundle (.aab)</span>
              </div>
            </div>

            <p className="text-[10px] text-slate-400 leading-relaxed">
              تم تجهيز مجلد <code className="text-amber-400 font-mono">android/</code> الكامل داخل الحزمة وفق معايير Google Play مع ملفات Gradle وCompose وManifest وكافة الشاشات.
            </p>

            <a
              href="/alsahli-decor-app.zip"
              download="alsahli-decor-app.zip"
              className="w-full bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all block text-center shadow-lg shadow-amber-500/20"
            >
              <Download className="w-4 h-4 inline" />
              <span>تحميل مشروع Android Native كاملاً (ZIP)</span>
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
