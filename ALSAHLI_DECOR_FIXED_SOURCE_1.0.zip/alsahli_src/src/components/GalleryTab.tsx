import React, { useState } from 'react';
import { 
  Image as ImageIcon, 
  MapPin, 
  X, 
  Sliders, 
  Sparkles, 
  ArrowLeft, 
  Check, 
  ChevronRight, 
  ChevronLeft,
  Filter
} from 'lucide-react';
import { GALLERY_ITEMS, GalleryItem } from '../data/decorData';

interface GalleryTabProps {
  onSelectServiceForQuote: (serviceId?: string) => void;
}

export const GalleryTab: React.FC<GalleryTabProps> = ({ onSelectServiceForQuote }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);
  const [beforeAfterSlider, setBeforeAfterSlider] = useState<number>(50);

  const categories = [
    { id: 'all', label: 'الكل' },
    { id: 'beforeAfter', label: 'قبل وبعد 🔄' },
    { id: 'interior', label: 'دهان داخلي' },
    { id: 'gypsum', label: 'ديكور وجبس' },
    { id: 'exterior', label: 'دهان خارجي' },
    { id: 'wallpaper', label: 'ورق جدران' },
    { id: 'decorative', label: 'أعمال الزينة' },
  ];

  const filteredItems = GALLERY_ITEMS.filter((item) => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'beforeAfter') return Boolean(item.beforeImage);
    return item.category === activeCategory;
  });

  // Featured Before/After item
  const beforeAfterItem = GALLERY_ITEMS.find(item => item.beforeImage) || GALLERY_ITEMS[0];

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="text-right">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/25 text-sky-400 text-xs font-bold mb-1.5">
          <ImageIcon className="w-3.5 h-3.5" />
          <span>معرض المشاريع المنفذة</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white">
          نماذج حقيقية من إبداعاتنا
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-lg">
          استكشف مجموعة مختارة من أحدث أعمال الدهان الداخلي والخارجي والديكورات العصرية المنفذة لعملائنا.
        </p>
      </div>

      {/* Interactive Before & After Feature Slider */}
      {beforeAfterItem.beforeImage && (
        <div className="bg-slate-900 rounded-3xl border border-amber-500/30 p-4 shadow-xl text-right">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse"></span>
              <h3 className="text-sm font-extrabold text-white">
                مقارنة تفاعلية: قبل وبعد الترميم والدهان
              </h3>
            </div>
            <span className="text-[11px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full font-bold">
              اسحب المؤشر
            </span>
          </div>

          <div className="relative h-60 sm:h-72 w-full rounded-2xl overflow-hidden select-none border border-slate-800">
            {/* After Image (Background) */}
            <img
              src={beforeAfterItem.image}
              alt="بعد التنفيذ"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <span className="absolute top-3 left-3 bg-emerald-500 text-slate-950 text-[10px] font-black px-2 py-1 rounded-md shadow-md z-10">
              بعد الدهان والديكور ✨
            </span>

            {/* Before Image (Clipped) */}
            <div
              className="absolute inset-0 overflow-hidden"
              style={{ width: `${beforeAfterSlider}%` }}
            >
              <img
                src={beforeAfterItem.beforeImage}
                alt="قبل التنفيذ"
                className="absolute inset-0 w-full h-full object-cover max-w-none"
                style={{ width: '100%', height: '100%' }}
              />
              <span className="absolute top-3 right-3 bg-slate-950/90 text-slate-300 text-[10px] font-bold px-2 py-1 rounded-md shadow-md z-10">
                قبل العمل
              </span>
            </div>

            {/* Divider Line & Handle */}
            <div
              className="absolute top-0 bottom-0 w-1 bg-amber-400 cursor-ew-resize z-20 shadow-[0_0_10px_rgba(245,158,11,0.8)]"
              style={{ left: `${beforeAfterSlider}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow-lg font-bold">
                <Sliders className="w-4 h-4" />
              </div>
            </div>

            {/* Invisible Range Input for touch and mouse drag */}
            <input
              type="range"
              min="0"
              max="100"
              value={beforeAfterSlider}
              onChange={(e) => setBeforeAfterSlider(Number(e.target.value))}
              className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-30"
            />
          </div>

          <div className="flex items-center justify-between mt-3 text-xs text-slate-400">
            <span>{beforeAfterItem.title} - {beforeAfterItem.location}</span>
            <button
              onClick={() => onSelectServiceForQuote()}
              className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
            >
              <span>طلب تجديد مشابه</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`shrink-0 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeCategory === cat.id
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedItem(item)}
            className="group cursor-pointer bg-slate-900 rounded-3xl border border-slate-800 hover:border-amber-500/40 overflow-hidden shadow-lg transition-all duration-300 flex flex-col justify-between"
          >
            <div className="relative h-52 w-full overflow-hidden">
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />

              {/* Tag & Category */}
              <div className="absolute top-3 right-3 flex items-center gap-2">
                <span className="bg-slate-950/80 backdrop-blur-md text-amber-300 text-[10px] font-extrabold px-2.5 py-1 rounded-full border border-amber-500/30">
                  {item.categoryLabel}
                </span>
                {item.beforeImage && (
                  <span className="bg-emerald-500/90 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full">
                    قبل وبعد
                  </span>
                )}
              </div>

              {/* Location Badge */}
              <div className="absolute bottom-3 right-3 left-3 text-right">
                <span className="inline-flex items-center gap-1 text-[11px] text-slate-300 mb-1">
                  <MapPin className="w-3 h-3 text-amber-400" />
                  {item.location}
                </span>
                <h3 className="text-sm font-black text-white group-hover:text-amber-300 transition-colors">
                  {item.title}
                </h3>
              </div>
            </div>

            <div className="p-3.5 text-right space-y-2">
              <p className="text-xs text-slate-400 line-clamp-2">
                {item.description}
              </p>
              
              <div className="flex flex-wrap gap-1 pt-1">
                {item.specs.map((spec, i) => (
                  <span key={i} className="text-[10px] bg-slate-950 text-slate-300 px-2 py-0.5 rounded-md border border-slate-800">
                    {spec}
                  </span>
                ))}
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-slate-800/80 text-xs">
                <span className="text-amber-400 font-bold group-hover:underline flex items-center gap-1">
                  <span>مشاهدة التفاصيل</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </span>
                <span className="text-[11px] text-slate-500">
                  كود المشروع #{item.id}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox / Project Details Modal */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full max-h-[92vh] overflow-y-auto no-scrollbar shadow-2xl text-right">
            <div className="relative h-64 sm:h-72 w-full">
              <img
                src={selectedItem.image}
                alt={selectedItem.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-black/40" />
              
              <button
                onClick={() => setSelectedItem(null)}
                className="absolute top-3 left-3 w-8 h-8 rounded-full bg-slate-950/80 text-white flex items-center justify-center hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="absolute bottom-3 right-4">
                <span className="bg-amber-500 text-slate-950 text-xs font-black px-2.5 py-0.5 rounded-full mb-1 inline-block">
                  {selectedItem.categoryLabel}
                </span>
                <h3 className="text-lg font-black text-white">
                  {selectedItem.title}
                </h3>
              </div>
            </div>

            <div className="p-5 space-y-4">
              <div className="flex items-center gap-2 text-xs text-amber-400">
                <MapPin className="w-4 h-4" />
                <span>الموقع: {selectedItem.location}</span>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase mb-1">وصف العمل المنفذ</h4>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {selectedItem.description}
                </p>
              </div>

              {selectedItem.beforeImage && (
                <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
                  <h4 className="text-xs font-bold text-slate-300 mb-2">صورة الموقع قبل البدء:</h4>
                  <div className="h-36 rounded-xl overflow-hidden">
                    <img src={selectedItem.beforeImage} alt="قبل التنفيذ" className="w-full h-full object-cover" />
                  </div>
                </div>
              )}

              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">المواصفات والخامات المطبقة</h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedItem.specs.map((spec, i) => (
                    <span key={i} className="text-xs bg-slate-950 px-3 py-1 rounded-xl border border-slate-800 text-slate-200 flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-amber-400" />
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  onClick={() => {
                    const title = selectedItem.title;
                    setSelectedItem(null);
                    onSelectServiceForQuote();
                  }}
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs py-3 rounded-xl transition-all shadow-lg shadow-amber-500/20 text-center"
                >
                  اطلب تشطيباً مماثلاً لهذا المشروع
                </button>
                <button
                  onClick={() => setSelectedItem(null)}
                  className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
