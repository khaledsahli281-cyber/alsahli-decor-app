import React, { useState, useEffect } from 'react';
import { Lock, X, AlertCircle, ShieldCheck, Eye, EyeOff, KeyRound, CheckCircle2 } from 'lucide-react';

interface OwnerLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

// Convert Eastern Arabic numerals (٠-٩) to Western (0-9) and strip whitespace
export const normalizePin = (input: string): string => {
  if (!input) return '';
  return input
    .toString()
    .trim()
    .replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d).toString())
    .replace(/\s+/g, '');
};

export const OwnerLoginModal: React.FC<OwnerLoginModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Sync latest PIN from backend on open
  useEffect(() => {
    if (isOpen) {
      fetch('/api/settings')
        .then((res) => res.json())
        .then((data) => {
          if (data?.settings?.pin) {
            localStorage.setItem('alsahli_owner_pin', normalizePin(data.settings.pin));
          }
        })
        .catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const getStoredPin = (): string => {
    try {
      const stored = localStorage.getItem('alsahli_owner_pin');
      return stored ? normalizePin(stored) : '2026';
    } catch {
      return '2026';
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError('');

    const entered = normalizePin(pin);
    const correctPin = getStoredPin();

    // Verify against saved custom PIN OR fallback master code 2026
    if (entered === correctPin || entered === '2026') {
      setError('');
      setPin('');
      onSuccess();
    } else {
      setError('رمز الدخول السري غير صحيح، تأكد من كتابة الرمز بشكل صحيح أو استخدم الرمز الرئيسي');
    }
  };

  const handleKeyPress = (num: string) => {
    if (pin.length < 12) {
      setPin((prev) => prev + num);
      setError('');
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setError('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-amber-500/30 rounded-3xl max-w-sm w-full p-6 text-right space-y-4 shadow-2xl animate-scale-up">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-sm text-white">تسجيل دخول المالك</h3>
              <p className="text-[11px] text-slate-400">بوابة الإدارة المشفرة</p>
            </div>
          </div>
          <button
            onClick={() => {
              setPin('');
              setError('');
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* PIN Input Box with Show/Hide Toggle */}
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5 text-center">
              أدخل رمز الأمان للمالك:
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={pin}
                onChange={(e) => {
                  setPin(e.target.value);
                  setError('');
                }}
                placeholder="أدخل رمز الدخول (PIN)"
                className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 text-white font-mono text-center tracking-widest text-lg py-2.5 px-10 rounded-2xl outline-none shadow-inner"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-amber-400 p-1"
                title={showPassword ? 'إخفاء الرمز' : 'إظهار الرمز للتأكد'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {error && (
            <p className="text-xs text-rose-400 font-bold flex items-center justify-center gap-1.5 text-center">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </p>
          )}

          {/* Number Keypad for Easy Mobile Tap */}
          <div className="grid grid-cols-3 gap-2 max-w-[240px] mx-auto pt-1">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => handleKeyPress(n)}
                className="h-11 rounded-xl bg-slate-800/90 hover:bg-slate-750 active:scale-95 text-white font-black text-base transition-all border border-slate-700/60 shadow"
              >
                {n}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setPin('')}
              className="h-11 rounded-xl bg-slate-800/40 hover:bg-slate-800 active:scale-95 text-slate-400 text-xs font-bold transition-all border border-slate-800"
            >
              مسح
            </button>
            <button
              type="button"
              onClick={() => handleKeyPress('0')}
              className="h-11 rounded-xl bg-slate-800/90 hover:bg-slate-750 active:scale-95 text-white font-black text-base transition-all border border-slate-700/60 shadow"
            >
              0
            </button>
            <button
              type="button"
              onClick={handleDelete}
              className="h-11 rounded-xl bg-slate-800/40 hover:bg-slate-800 active:scale-95 text-slate-400 text-xs font-bold transition-all border border-slate-800"
            >
              ⌫
            </button>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={pin.trim().length === 0}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-black text-xs py-3 rounded-2xl transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 mt-2"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>تأكيد تسجيل الدخول</span>
          </button>
        </form>

        <div className="pt-1 text-center">
          <p className="text-[10px] text-slate-500">
            يمكنك إدخال الرمز من لوحة الأرقام أعلاه أو لوحة مفاتيح الهاتف مباشرة.
          </p>
        </div>
      </div>
    </div>
  );
};
