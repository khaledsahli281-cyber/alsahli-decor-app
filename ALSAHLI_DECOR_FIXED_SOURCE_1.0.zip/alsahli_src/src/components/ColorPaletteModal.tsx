import React, { useState } from 'react';
import { Palette, X, Copy, Check, Sparkles } from 'lucide-react';
import { COLOR_PALETTES, ColorPaletteItem } from '../data/decorData';

interface ColorPaletteModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ColorPaletteModal: React.FC<ColorPaletteModalProps> = ({
  isOpen,
  onClose
}) => {
  const [selectedColor, setSelectedColor] = useState<ColorPaletteItem>(COLOR_PALETTES[0]);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  if (!isOpen) return null;

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const filteredColors = COLOR_PALETTES.filter((c) => {
    if (activeCategory === 'all') return true;
    return c.category === activeCategory;
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full max-h-[92vh] overflow-y-auto no-scrollbar shadow-2xl text-right p-5 space-y-4 animate-scale-up">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-sm text-white">كتالوج ألوان 2026 الرائجة</h3>
              <p className="text-[11px] text-slate-400">تنسيقات وأكواد بويات جوتن والجزيرة المعتمدة</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Simulated Room Wall Preview */}
        <div className="relative rounded-2xl overflow-hidden border border-slate-800 p-4 transition-colors duration-500 shadow-inner flex flex-col justify-end h-44"
          style={{ backgroundColor: selectedColor.hex }}
        >
          {/* Subtle room shadows & floor simulation */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />
          <div className="absolute bottom-0 left-0 right-0 h-7 bg-amber-900/40 border-t border-amber-950/60 backdrop-blur-2xs" />

          {/* Color Details Card on Preview */}
          <div className="relative z-10 bg-slate-950/85 backdrop-blur-md p-3 rounded-xl border border-slate-700 text-right">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] text-amber-400 font-bold block">{selectedColor.categoryName}</span>
                <h4 className="text-xs font-black text-white">{selectedColor.name}</h4>
              </div>
              <button
                onClick={() => handleCopy(selectedColor.code)}
                className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[11px] font-mono px-2.5 py-1 rounded-lg border border-amber-500/30 flex items-center gap-1 transition-all"
              >
                {copiedCode === selectedColor.code ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">تم النسخ</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>{selectedColor.code}</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-[10px] text-slate-300 mt-1">
              {selectedColor.description}
            </p>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
          {[
            { id: 'all', label: 'الكل' },
            { id: 'neutral', label: 'محايدة ومشرقة' },
            { id: 'modern', label: 'مودرن' },
            { id: 'warm', label: 'دافئة' },
            { id: 'luxury', label: 'ألوان مميزة' }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`text-[11px] font-bold px-3 py-1 rounded-lg transition-all shrink-0 ${
                activeCategory === cat.id
                  ? 'bg-amber-500 text-slate-950'
                  : 'bg-slate-950 text-slate-400 border border-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Palette Swatches */}
        <div className="grid grid-cols-2 gap-2">
          {filteredColors.map((color) => {
            const isSelected = selectedColor.code === color.code;
            return (
              <div
                key={color.code}
                onClick={() => setSelectedColor(color)}
                className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center gap-2.5 ${
                  isSelected
                    ? 'bg-slate-950 border-amber-400 ring-2 ring-amber-400/20'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div
                  className="w-8 h-8 rounded-lg border border-slate-700 shadow-sm shrink-0"
                  style={{ backgroundColor: color.hex }}
                />
                <div className="overflow-hidden">
                  <h5 className="text-[11px] font-bold text-white truncate">
                    {color.name}
                  </h5>
                  <span className="text-[10px] text-amber-400 font-mono block">
                    {color.code}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Note */}
        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400">
          💡 يمكنك ذكر كود اللون المفضل عند إرسال طلب عرض السعر أو أثناء زيارة فني المعاينة لتطبيق عينة حية على حائطك مجاناً.
        </div>
      </div>
    </div>
  );
};
