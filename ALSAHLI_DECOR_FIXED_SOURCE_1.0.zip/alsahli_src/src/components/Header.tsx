import React, { useState, useEffect } from 'react';
import { Phone, MessageCircle, Paintbrush, ShieldCheck, Sparkles, Smartphone, Monitor, Share2, Bell } from 'lucide-react';
import { COMPANY_INFO } from '../data/decorData';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isPhoneFrame: boolean;
  setIsPhoneFrame: (val: boolean) => void;
  ordersCount: number;
  onOpenOrders: () => void;
  onOpenNotifications: () => void;
  onOpenCalculator: () => void;
  onOpenColors: () => void;
  isOwnerLoggedIn: boolean;
  onOpenOwnerLogin: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  isPhoneFrame,
  setIsPhoneFrame,
  ordersCount,
  onOpenOrders,
  onOpenNotifications,
  onOpenCalculator,
  onOpenColors,
  isOwnerLoggedIn,
  onOpenOwnerLogin
}) => {
  const [time, setTime] = useState('');
  const [vipTaps, setVipTaps] = useState(0);

  // Secret triple tap on VIP badge opens Owner PIN login
  const handleVipTap = () => {
    const next = vipTaps + 1;
    if (next >= 3) {
      setVipTaps(0);
      onOpenOwnerLogin();
    } else {
      setVipTaps(next);
      setTimeout(() => setVipTaps(0), 2000);
    }
  };

  const handleShareApp = async () => {
    // Always share the pure, clean customer URL (no admin params)
    const shareUrl = 'https://ais-pre-37nwxmk65pwm3u55obcebd-711257153436.us-west2.run.app';
    const shareText = 'تطبيق «السهلي للديكور» - خدمات الدهانات والجبس بورد وأعمال الترميم والمعاينة المجانية في سوريا:';
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'السهلي للديكور',
          text: shareText,
          url: shareUrl
        });
      } catch {
        // cancelled or unsupported
      }
    } else {
      const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareText}\n${shareUrl}`)}`;
      window.open(waUrl, '_blank');
    }
  };

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-amber-500/20 shadow-lg">
      {/* Android Top Status Bar Simulation */}
      <div className="bg-slate-950/80 px-4 py-1 flex items-center justify-between text-[11px] text-slate-400 select-none border-b border-slate-800/40">
        <span className="font-sans font-medium text-slate-300">{time || '10:30'}</span>
        <div className="flex items-center gap-1.5">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="text-[10px] text-emerald-400 font-medium">متواجدون لخدمتكم</span>
        </div>
        <div className="flex items-center gap-2 text-slate-400">
          <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M12 3c-4.97 0-9 4.03-9 9 0 2.12.74 4.07 1.97 5.61L12 22l7.03-4.39C20.26 16.07 21 14.12 21 12c0-4.97-4.03-9-9-9zm0 15c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"/></svg>
          <span className="font-sans text-[10px]">5G</span>
          <div className="w-4 h-2 border border-slate-400 rounded-sm p-0.5 flex items-center">
            <div className="w-full h-full bg-amber-400 rounded-2xs"></div>
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="px-4 py-2.5 flex items-center justify-between gap-3">
        {/* Brand & Logo */}
        <div 
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 cursor-pointer group select-none"
        >
          <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 p-0.5 shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Paintbrush className="w-5 h-5 text-amber-400 transform -rotate-12 group-hover:rotate-0 transition-transform" />
            </div>
            <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-slate-950 rounded-full flex items-center justify-center">
              <Sparkles className="w-2.5 h-2.5 text-white" />
            </span>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base sm:text-lg font-black tracking-tight text-white group-hover:text-amber-400 transition-colors">
                {COMPANY_INFO.name}
              </h1>
              <span
                onClick={handleVipTap}
                className="bg-amber-500/20 text-amber-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-amber-500/30 cursor-pointer select-none active:scale-95 transition-transform"
                title="VIP"
              >
                VIP
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium leading-none">
              دهانات • ديكور • تشطيب معتمد
            </p>
          </div>
        </div>

        {/* Action Shortcuts */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Notifications Bell (ONLY visible when owner is logged in) */}
          {isOwnerLoggedIn && (
            <button
              onClick={onOpenNotifications}
              className="relative flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/30 transition-all hover:scale-105 active:scale-95"
              title="صندوق إشعارات طلبات الزبائن"
            >
              <Bell className="w-4 h-4" />
              {ordersCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 text-slate-950 font-black text-[10px] rounded-full flex items-center justify-center animate-pulse">
                  {ordersCount}
                </span>
              )}
            </button>
          )}

          {/* Owner Dashboard Button (ONLY visible when owner is logged in) */}
          {isOwnerLoggedIn && (
            <button
              onClick={() => setActiveTab('owner')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-black transition-all ${
                activeTab === 'owner'
                  ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
              }`}
              title="لوحة تحكم المالك"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">المالك</span>
            </button>
          )}

          {/* Share App (Visible to everyone) */}
          <button
            onClick={handleShareApp}
            className="flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-sky-500/15 hover:bg-sky-500/25 text-sky-400 border border-sky-500/30 transition-all hover:scale-105 active:scale-95"
            title="مشاركة التطبيق مع الأصدقاء"
          >
            <Share2 className="w-4 h-4" />
          </button>

          {/* Quick WhatsApp */}
          <a
            href={`https://wa.me/${COMPANY_INFO.whatsapp}?text=${encodeURIComponent('السلام عليكم، أود الاستفسار عن خدمات الدهان والديكور لدى السهلي للديكور')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 transition-all hover:scale-105 active:scale-95"
            title="محادثة واتساب سريعة"
          >
            <MessageCircle className="w-4 h-4" />
          </a>

          {/* Quick Call */}
          <a
            href={`tel:${COMPANY_INFO.internationalPhone}`}
            className="flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/30 transition-all hover:scale-105 active:scale-95"
            title="اتصال هاتفي مباشر"
          >
            <Phone className="w-4 h-4" />
          </a>

          {/* Desktop Viewport Toggle (Only visible on large screens) */}
          <button
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-medium transition-colors"
            title={isPhoneFrame ? "عرض الشاشة الكاملة" : "عرض مظهر هاتف أندرويد"}
          >
            {isPhoneFrame ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[11px]">شاشة كاملة</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[11px]">مظهر الهاتف</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Sub Bar with Quick Badges & Tools */}
      <div className="px-4 py-1.5 bg-slate-950/60 border-t border-slate-800/60 flex items-center justify-between text-xs overflow-x-auto no-scrollbar gap-3">
        <div className="flex items-center gap-3 shrink-0 text-[11px] text-slate-300">
          <span className="flex items-center gap-1 text-amber-400 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            إتقان وجودة معتمدة
          </span>
          <span className="text-slate-600">•</span>
          <span className="text-slate-400">معاينة ورفع مقاسات مجاني</span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenCalculator}
            className="text-[11px] text-amber-300 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/25 transition-colors flex items-center gap-1"
          >
            <span>حاسبة التكلفة</span>
          </button>

          <button
            onClick={onOpenColors}
            className="text-[11px] text-sky-300 hover:text-sky-200 bg-sky-500/10 hover:bg-sky-500/20 px-2 py-0.5 rounded border border-sky-500/25 transition-colors flex items-center gap-1"
          >
            <span>كتالوج الألوان</span>
          </button>

          {ordersCount > 0 && (
            <button
              onClick={onOpenOrders}
              className="text-[11px] text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1 animate-pulse"
            >
              <span>طلباتي ({ordersCount})</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
