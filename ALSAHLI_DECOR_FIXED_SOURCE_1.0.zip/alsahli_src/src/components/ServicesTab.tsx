import React, { useState } from 'react';
import { 
  Paintbrush, 
  Building, 
  LayoutGrid, 
  Layers, 
  Wrench, 
  Sparkles, 
  ShieldCheck, 
  Clock, 
  Tag, 
  Check, 
  ArrowLeft, 
  X,
  Search,
  ChevronLeft
} from 'lucide-react';
import { SERVICES, ServiceItem } from '../data/decorData';

interface ServicesTabProps {
  onSelectServiceForQuote: (serviceId: string) => void;
  selectedServiceId?: string | null;
}

export const ServicesTab: React.FC<ServicesTabProps> = ({
  onSelectServiceForQuote,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeModalService, setActiveModalService] = useState<ServiceItem | null>(null);

  const getIcon = (name: string) => {
    switch (name) {
      case 'Paintbrush':
        return <Paintbrush className="w-5 h-5 text-amber-400" />;
      case 'Building':
        return <Building className="w-5 h-5 text-amber-400" />;
      case 'LayoutGrid':
        return <LayoutGrid className="w-5 h-5 text-amber-400" />;
      case 'Layers':
        return <Layers className="w-5 h-5 text-amber-400" />;
      case 'Wrench':
        return <Wrench className="w-5 h-5 text-amber-400" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-amber-400" />;
      default:
        return <Paintbrush className="w-5 h-5 text-amber-400" />;
    }
  };

  const filteredServices = SERVICES.filter(s => 
    s.title.includes(searchQuery) || 
    s.shortDesc.includes(searchQuery) ||
    s.fullDesc.includes(searchQuery)
  );

  return (
    <div className="space-y-5 pb-24">
      {/* Header */}
      <div className="text-right">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/25 text-amber-400 text-xs font-bold mb-1.5">
          <Layers className="w-3.5 h-3.5" />
          <span>خدماتنا المتخصصة</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white">
          أعمال الدهانات والديكورات والتشطيب
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-lg">
          نقدم باقة شاملة من 6 خدمات رئيسية بمعايير هندسية وجودة تنفيذ استثنائية وإتقان فني معتمد.
        </p>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="ابحث عن خدمة (مثل: دهان داخلي، جبس، ترميم...)"
          className="w-full bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-2xl py-3 pr-10 pl-4 text-xs text-slate-100 placeholder-slate-500 outline-none transition-all shadow-inner"
        />
        <Search className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5" />
        {searchQuery && (
          <button 
            onClick={() => setSearchQuery('')}
            className="absolute left-3 top-3 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* 6 Services Grid */}
      <div className="space-y-4">
        {filteredServices.map((service, index) => (
          <div
            key={service.id}
            className="group bg-slate-900/90 rounded-3xl border border-slate-800 hover:border-amber-500/40 overflow-hidden shadow-lg transition-all duration-300"
          >
            <div className="relative h-44 sm:h-52 w-full overflow-hidden">
              <img
                src={service.image}
                alt={service.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent" />
              
              {/* Badge & Number */}
              <div className="absolute top-3 right-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-xl bg-slate-950/80 backdrop-blur-md border border-slate-700 text-amber-400 text-xs font-black flex items-center justify-center">
                  {index + 1}
                </span>
                <span className="bg-amber-500 text-slate-950 text-[10px] font-black px-2.5 py-1 rounded-full shadow">
                  {service.startingPrice}
                </span>
              </div>

              {/* Title & Icon on Image bottom */}
              <div className="absolute bottom-3 right-3 left-3 text-right">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-8 h-8 rounded-xl bg-slate-950/80 backdrop-blur-md border border-amber-500/30 flex items-center justify-center">
                    {getIcon(service.iconName)}
                  </div>
                  <h3 className="text-lg font-black text-white">
                    {service.title}
                  </h3>
                </div>
              </div>
            </div>

            {/* Content Area */}
            <div className="p-4 text-right space-y-3">
              <p className="text-xs text-slate-300 leading-relaxed font-normal">
                {service.shortDesc}
              </p>

              {/* Highlights pills */}
              <div className="space-y-1.5 pt-1">
                {service.features.slice(0, 3).map((feat, fIdx) => (
                  <div key={fIdx} className="flex items-start gap-2 text-[11px] text-slate-300">
                    <Check className="w-3.5 h-3.5 text-amber-400 mt-0.5 shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>

              {/* Details & Guarantees */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-[11px]">
                <div className="bg-slate-950/50 p-2 rounded-xl border border-slate-800/80 flex items-center gap-2 text-slate-400">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="truncate">{service.warranty}</span>
                </div>
                <div className="bg-slate-950/50 p-2 rounded-xl border border-slate-800/80 flex items-center gap-2 text-slate-400">
                  <Clock className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                  <span className="truncate">{service.duration}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => onSelectServiceForQuote(service.id)}
                  className="bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 text-xs font-black py-2.5 px-3 rounded-xl transition-all shadow-md shadow-amber-500/15 flex items-center justify-center gap-1.5"
                >
                  <span>طلب عرض سعر</span>
                  <ArrowLeft className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => setActiveModalService(service)}
                  className="bg-slate-800 hover:bg-slate-750 active:scale-95 text-slate-200 text-xs font-bold py-2.5 px-3 rounded-xl border border-slate-700 transition-all flex items-center justify-center gap-1"
                >
                  <span>التفاصيل والمواد</span>
                  <ChevronLeft className="w-3.5 h-3.5 text-slate-400" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Service Detail Modal */}
      {activeModalService && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto no-scrollbar shadow-2xl text-right animate-scale-up">
            <div className="relative h-48 w-full">
              <img
                src={activeModalService.image}
                alt={activeModalService.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />
              <button
                onClick={() => setActiveModalService(null)}
                className="absolute top-3 left-3 w-8 h-8 rounded-full bg-slate-950/80 text-white flex items-center justify-center hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="absolute bottom-3 right-4">
                <span className="bg-amber-500 text-slate-950 text-xs font-black px-2.5 py-0.5 rounded-full mb-1 inline-block">
                  {activeModalService.startingPrice}
                </span>
                <h3 className="text-xl font-black text-white">
                  {activeModalService.title}
                </h3>
              </div>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase mb-1">وصف شامل للخدمة</h4>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {activeModalService.fullDesc}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-bold text-amber-400 uppercase mb-2 flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5" />
                  <span>المواد والخامات المستخدمة</span>
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {activeModalService.materials.map((mat, i) => (
                    <span key={i} className="text-xs bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                      {mat}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">مميزات ومواصفات التنفيذ</h4>
                <div className="space-y-1.5 text-xs text-slate-300">
                  {activeModalService.features.map((feat, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-amber-400 mt-0.5 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-1 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>معيار الجودة والإتقان:</span>
                  <span className="font-bold text-emerald-400">{activeModalService.warranty}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>مدة التنفيذ التقريبية:</span>
                  <span className="font-bold text-sky-400">{activeModalService.duration}</span>
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  onClick={() => {
                    const sid = activeModalService.id;
                    setActiveModalService(null);
                    onSelectServiceForQuote(sid);
                  }}
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs py-3 rounded-xl transition-all shadow-lg shadow-amber-500/20 text-center"
                >
                  اطلب هذه الخدمة الآن
                </button>
                <button
                  onClick={() => setActiveModalService(null)}
                  className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
