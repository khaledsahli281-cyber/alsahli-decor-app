import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Send, 
  Upload, 
  Image as ImageIcon, 
  Trash2, 
  CheckCircle2, 
  MessageCircle, 
  Phone, 
  Sparkles, 
  Building2, 
  Home, 
  MapPin, 
  AlertCircle,
  HelpCircle,
  ShieldCheck,
  Eye
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SERVICES, COMPANY_INFO, QuoteRequest } from '../data/decorData';
import { compressImage } from '../utils/imageCompressor';

interface QuoteTabProps {
  initialServiceId?: string | null;
  onOrderSaved?: (order: QuoteRequest) => void;
  onOpenImage?: (url: string, title?: string) => void;
}

export const QuoteTab: React.FC<QuoteTabProps> = ({ 
  initialServiceId,
  onOrderSaved,
  onOpenImage
}) => {
  const [clientName, setClientName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('دمشق');
  const [district, setDistrict] = useState('');
  const [serviceId, setServiceId] = useState(initialServiceId || SERVICES[0].id);
  const [propertyType, setPropertyType] = useState('فيلا');
  const [areaEstimate, setAreaEstimate] = useState('');
  const [details, setDetails] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [isCompressing, setIsCompressing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedOrder, setSubmittedOrder] = useState<QuoteRequest | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (initialServiceId) {
      setServiceId(initialServiceId);
    }
  }, [initialServiceId]);

  // Handle Image Upload with High-Quality Client-Side Compression
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsCompressing(true);
    try {
      for (const file of Array.from(files)) {
        if (!file.type.startsWith('image/')) continue;
        const compressedBase64 = await compressImage(file, 1200, 1200, 0.75);
        setImages((prev) => [...prev, compressedBase64]);
      }
    } catch (err) {
      console.error('Error compressing image:', err);
    } finally {
      setIsCompressing(false);
    }
  };

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const validate = () => {
    const newErrors: { [key: string]: string } = {};
    if (!clientName.trim()) {
      newErrors.clientName = 'يرجى كتابة الاسم الكريم';
    }
    if (!phone.trim()) {
      newErrors.phone = 'يرجى كتابة رقم الجوال';
    } else if (phone.length < 9) {
      newErrors.phone = 'يرجى التأكد من صحة رقم الجوال';
    }
    if (!details.trim()) {
      newErrors.details = 'يرجى كتابة تفاصيل العمل أو ما ترغب بتنفيذه';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const selectedService = SERVICES.find((s) => s.id === serviceId) || SERVICES[0];

  const generateWhatsAppMessage = (orderId: string) => {
    const lines = [
      `*طلب عرض سعر جديد - السهلي للديكور*`,
      `*رقم الطلب:* #${orderId}`,
      `--------------------------`,
      `👤 *الاسم:* ${clientName}`,
      `📱 *الجوال:* ${phone}`,
      `📍 *المدينة والحي:* ${city} - ${district || 'غير محدد'}`,
      `🏠 *نوع العقار:* ${propertyType}`,
      `🎨 *الخدمة المطلوبة:* ${selectedService.title}`,
      `📐 *المساحة / الحجم التقريبي:* ${areaEstimate || 'معاينة في الموقع'}`,
      `📝 *تفاصيل العمل:*`,
      `${details}`,
      `📸 *عدد الصور المرفقة:* ${images.length} صور تم إرفاقها بالتطبيق`,
      `--------------------------`,
      `أرجو إفادتي بالسعر التقريبي وتحديد موعد للمعاينة المجانية وشكراً.`
    ];
    return encodeURIComponent(lines.join('\n'));
  };

  const handleSubmit = (actionType: 'whatsapp' | 'save') => {
    if (!validate()) {
      return;
    }

    setIsSubmitting(true);

    const orderId = `SAHLI-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOrder: QuoteRequest = {
      id: orderId,
      createdAt: new Date().toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      clientName,
      phone,
      city: `${city} - ${district || ''}`,
      governorate: city,
      serviceId,
      serviceTitle: selectedService.title,
      propertyType,
      areaEstimate: areaEstimate || 'غير محدد',
      details,
      notes: details,
      images,
      status: 'new'
    };

    // Save to local storage
    try {
      const existing = JSON.parse(localStorage.getItem('alsahli_orders') || '[]');
      localStorage.setItem('alsahli_orders', JSON.stringify([newOrder, ...existing]));

      // Save to user private orders list to ensure strict customer privacy
      const myOrderIds = JSON.parse(localStorage.getItem('alsahli_my_order_ids') || '[]');
      if (!myOrderIds.includes(orderId)) {
        localStorage.setItem('alsahli_my_order_ids', JSON.stringify([orderId, ...myOrderIds]));
      }
    } catch {
      // fallback
    }

    // Save to Server API so Owner sees it in real-time
    try {
      fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder)
      }).catch((e) => console.log('API sync skipped:', e));
    } catch {
      // ignore
    }

    if (onOrderSaved) {
      onOrderSaved(newOrder);
    }

    // Trigger confetti celebration
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }

    setSubmittedOrder(newOrder);
    setIsSubmitting(false);

    if (actionType === 'whatsapp') {
      const msg = generateWhatsAppMessage(orderId);
      window.open(`https://wa.me/${COMPANY_INFO.whatsapp}?text=${msg}`, '_blank');
    }
  };

  const resetForm = () => {
    setClientName('');
    setPhone('');
    setDistrict('');
    setAreaEstimate('');
    setDetails('');
    setImages([]);
    setSubmittedOrder(null);
    setErrors({});
  };

  return (
    <div className="space-y-6 pb-24 text-right">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/25 text-amber-400 text-xs font-bold mb-1.5">
          <FileText className="w-3.5 h-3.5" />
          <span>طلب فوري ودقيق</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white">
          اطلب عرض سعر مجاني
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-lg">
          أدخل بياناتك وتفاصيل مشروعك وسنقوم بدراسة طلبك وتقديم أفضل تسعيرة ومعاينة مجانية بأسرع وقت.
        </p>
      </div>

      {/* Trust banner */}
      <div className="p-3 bg-slate-900/80 rounded-2xl border border-slate-800 flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>معاينة ورفع مقاسات مجانية 100% بدون أي التزام</span>
        </div>
        <span className="text-[11px] text-amber-400 font-bold">خصم للمساحات الكبيرة</span>
      </div>

      {/* Main Form */}
      <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-5 space-y-4 shadow-xl">
        {/* Step 1: Personal Info */}
        <div className="space-y-3">
          <h3 className="text-xs font-black text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold">1</span>
            <span>البيانات الأساسية للتواصل</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                الاسم الكريم <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="مثال: خالد السهلي"
                className={`w-full bg-slate-950 border ${
                  errors.clientName ? 'border-rose-500' : 'border-slate-800 focus:border-amber-500'
                } rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-500 outline-none transition-all`}
              />
              {errors.clientName && (
                <p className="text-[10px] text-rose-400 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {errors.clientName}
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                رقم الجوال / الواتساب <span className="text-rose-400">*</span>
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="09XXXXXXXX"
                dir="ltr"
                className={`w-full bg-slate-950 border ${
                  errors.phone ? 'border-rose-500' : 'border-slate-800 focus:border-amber-500'
                } rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-500 outline-none transition-all text-right`}
              />
              {errors.phone && (
                <p className="text-[10px] text-rose-400 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {errors.phone}
                </p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                المحافظة / المدينة
              </label>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2.5 px-3 text-xs text-white outline-none"
              >
                <option value="دمشق">دمشق</option>
                <option value="ريف دمشق">ريف دمشق</option>
                <option value="حلب">حلب</option>
                <option value="حمص">حمص</option>
                <option value="اللاذقية">اللاذقية</option>
                <option value="طرطوس">طرطوس</option>
                <option value="حماة">حماة</option>
                <option value="السويداء">السويداء</option>
                <option value="درعا">درعا</option>
                <option value="القنيطرة">القنيطرة</option>
                <option value="محافظة أخرى">محافظة أخرى</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                المنطقة / الحي
              </label>
              <input
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="مثال: المزة / مشروع دمر / كفرسوسة / جرمانا"
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Step 2: Service Selection */}
        <div className="space-y-3 pt-3 border-t border-slate-800">
          <h3 className="text-xs font-black text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold">2</span>
            <span>نوع الخدمة المطلوبة</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {SERVICES.map((s) => (
              <div
                key={s.id}
                onClick={() => setServiceId(s.id)}
                className={`p-2.5 rounded-xl border cursor-pointer transition-all text-right flex flex-col justify-between ${
                  serviceId === s.id
                    ? 'bg-amber-500/15 border-amber-500 text-white shadow-md shadow-amber-500/10'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                    serviceId === s.id ? 'border-amber-400 bg-amber-400' : 'border-slate-600'
                  }`}>
                    {serviceId === s.id && <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                  </span>
                  <span className="text-[10px] text-amber-400 font-bold">{s.startingPrice}</span>
                </div>
                <span className="text-xs font-bold block">{s.title}</span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                نوع العقار
              </label>
              <select
                value={propertyType}
                onChange={(e) => setPropertyType(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2.5 px-3 text-xs text-white outline-none"
              >
                <option value="فيلا كاملة">فيلا سكنية</option>
                <option value="شقة سكنية">شقة سكنية</option>
                <option value="دور كامل">دور كامل</option>
                <option value="مجلس / ملحق">مجلس أو ملحق</option>
                <option value="مكتب / مقر شركة">مكتب أو مقر شركة</option>
                <option value="محل تجاري / كافيه">محل تجاري أو كافيه</option>
                <option value="واجهة مبنى">واجهة مبنى / عمارة</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                المساحة التقريبية (م² أو غرف)
              </label>
              <input
                type="text"
                value={areaEstimate}
                onChange={(e) => setAreaEstimate(e.target.value)}
                placeholder="مثال: 250 م² أو 4 غرف وصالة"
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2.5 px-3 text-xs text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Step 3: Work Details */}
        <div className="space-y-3 pt-3 border-t border-slate-800">
          <h3 className="text-xs font-black text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold">3</span>
            <span>تفاصيل العمل والمواصفات المطلوبة</span>
          </h3>

          <div>
            <textarea
              rows={4}
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              placeholder="اكتب هنا تفاصيل العمل مثل: ألوان الدهان المطلوبة، حالة الجدران، هل يوجد تشققات أو رطوبة، نوع الجبس بورد أو الإضاءة، والموعد المفضل للبدء..."
              className={`w-full bg-slate-950 border ${
                errors.details ? 'border-rose-500' : 'border-slate-800 focus:border-amber-500'
              } rounded-xl p-3 text-xs text-white placeholder-slate-500 outline-none transition-all leading-relaxed`}
            />
            {errors.details && (
              <p className="text-[10px] text-rose-400 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.details}
              </p>
            )}
          </div>
        </div>

        {/* Step 4: Attach Photos */}
        <div className="space-y-3 pt-3 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold">4</span>
              <span>إرفاق صور للمكان (اختياري)</span>
            </h3>
            <span className="text-[11px] text-slate-400">تساعدنا لتقدير السعر بدقة</span>
          </div>

          {/* Upload Button & Drop Area */}
          <label className="border-2 border-dashed border-slate-700 hover:border-amber-500/60 bg-slate-950/60 hover:bg-slate-950 p-4 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all group">
            <div className="w-10 h-10 rounded-full bg-amber-500/15 group-hover:bg-amber-500/25 text-amber-400 flex items-center justify-center mb-2 transition-colors">
              <Upload className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-white group-hover:text-amber-400 transition-colors">
              اضغط هنا لاختيار صور من هاتفك
            </span>
            <span className="text-[11px] text-slate-400 mt-0.5">
              يمكنك تصوير الجدران أو اختيار أكثر من صورة (JPG, PNG)
            </span>
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </label>

          {/* Uploaded Images Preview */}
          {images.length > 0 && (
            <div>
              <span className="text-[11px] text-slate-400 block mb-2">
                الصور المرفقة ({images.length}):
              </span>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {images.map((img, idx) => (
                  <div key={idx} className="relative group rounded-xl overflow-hidden h-20 border border-slate-700 bg-slate-950">
                    <img src={img} alt="مرفق" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => removeImage(idx)}
                      className="absolute top-1 left-1 w-6 h-6 rounded-md bg-rose-600/90 text-white flex items-center justify-center hover:bg-rose-700 transition-colors shadow"
                      title="حذف الصورة"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Submit Buttons */}
        <div className="pt-4 space-y-2.5">
          {/* Primary Option: Send via WhatsApp */}
          <button
            type="button"
            disabled={isSubmitting}
            onClick={() => handleSubmit('whatsapp')}
            className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 active:scale-98 text-slate-950 font-black text-sm py-3.5 px-4 rounded-2xl transition-all shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-5 h-5 text-slate-950" />
            <span>إرسال فوري ومباشر عبر الواتساب</span>
          </button>

          {/* Secondary Option: Record and Save in App */}
          <button
            type="button"
            disabled={isSubmitting}
            onClick={() => handleSubmit('save')}
            className="w-full bg-slate-800 hover:bg-slate-750 active:scale-98 text-slate-200 border border-slate-700 font-bold text-xs py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4 text-amber-400" />
            <span>تسجيل وحفظ الطلب في التطبيق</span>
          </button>
        </div>
      </div>

      {/* Success Modal */}
      {submittedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl animate-scale-up">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/10">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <span className="text-[11px] font-bold text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                تم استلام طلبك بنجاح
              </span>
              <h3 className="text-xl font-black text-white mt-1.5">
                شكراً لاختيارك «السهلي للديكور»
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                تم إنشاء رقم مرجعي لطلبك وسيقوم فريقنا الفني بالتواصل معك خلال ساعات للمعاينة وتقديم أفضل عرض.
              </p>
            </div>

            {/* Order Summary Card */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-right space-y-2 text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-slate-800 text-slate-300">
                <span>رقم الطلب:</span>
                <span className="font-mono font-bold text-amber-400">#{submittedOrder.id}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>الخدمة:</span>
                <span className="font-bold text-white">{submittedOrder.serviceTitle}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>العميل:</span>
                <span className="font-medium text-white">{submittedOrder.clientName}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>المدينة والحي:</span>
                <span className="font-medium text-white">{submittedOrder.city}</span>
              </div>
            </div>

            {/* Attached Images Gallery Preview */}
            {submittedOrder.images && submittedOrder.images.length > 0 && (
              <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-2xl text-right space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-400 text-xs flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4" />
                    <span>الصور المرفقة بطلبك ({submittedOrder.images.length} صور)</span>
                  </span>
                  <span className="text-[10px] text-slate-500">انقر للمشاهدة والتكبير</span>
                </div>
                <div className="grid grid-cols-3 gap-2 pt-1">
                  {submittedOrder.images.map((imgUrl, imgIdx) => (
                    <div
                      key={imgIdx}
                      onClick={() => onOpenImage && onOpenImage(imgUrl, `صورة مرفقة - طلب #${submittedOrder.id}`)}
                      className="relative aspect-square rounded-xl overflow-hidden border border-slate-800 group cursor-pointer hover:border-amber-500 transition-all shadow"
                    >
                      <img
                        src={imgUrl}
                        alt={`صورة ${imgIdx + 1}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                        <Eye className="w-4 h-4 text-white drop-shadow" />
                      </div>
                    </div>
                  ))}
                </div>
                <p className="text-[11px] text-slate-400 pt-1 leading-relaxed">
                  ✅ تم رفع وحفظ الصور بنجاح في قاعدة بيانات التطبيق وسجل طلباتك.
                </p>
              </div>
            )}

            {/* Actions */}
            <div className="space-y-2 pt-1">
              <a
                href={`https://wa.me/${COMPANY_INFO.whatsapp}?text=${generateWhatsAppMessage(submittedOrder.id)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
              >
                <MessageCircle className="w-4 h-4" />
                <span>فتح المحادثة على واتساب لمتابعة الطلب</span>
              </a>

              <a
                href={`tel:${COMPANY_INFO.internationalPhone}`}
                className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 border border-slate-700"
              >
                <Phone className="w-4 h-4 text-amber-400" />
                <span>اتصال هاتفي مباشر للتنسيق الفوري</span>
              </a>

              <button
                onClick={resetForm}
                className="w-full text-slate-400 hover:text-white text-xs py-2"
              >
                تقديم طلب عرض سعر جديد
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
