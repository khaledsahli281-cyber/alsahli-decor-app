import React from 'react';
import { 
  Bell, 
  X, 
  Clock, 
  Phone, 
  MessageCircle, 
  MapPin, 
  Image as ImageIcon, 
  CheckCheck, 
  ExternalLink,
  AlertCircle,
  Lock,
  ShieldCheck
} from 'lucide-react';
import { QuoteRequest } from '../data/decorData';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: QuoteRequest[];
  onOpenImage: (imgUrl: string, title?: string) => void;
  isOwnerLoggedIn: boolean;
  onOpenOwnerLogin: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  orders,
  onOpenImage,
  isOwnerLoggedIn,
  onOpenOwnerLogin
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl text-right animate-scale-up overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="relative w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center">
              <Bell className="w-5 h-5" />
              {isOwnerLoggedIn && orders.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 text-slate-950 font-black text-[10px] rounded-full flex items-center justify-center animate-pulse">
                  {orders.length}
                </span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-sm sm:text-base text-white">
                  صندوق إشعارات طلبات الزبائن
                </h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                  إدارة المالك
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                منطقة محمية خاصة بإدارة السهلي للديكور
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body: If NOT logged in as Owner, show privacy lock screen */}
        {!isOwnerLoggedIn ? (
          <div className="p-6 text-center space-y-4 my-auto">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto shadow-lg shadow-amber-500/10">
              <Lock className="w-8 h-8" />
            </div>

            <div className="space-y-1.5 max-w-sm mx-auto">
              <h4 className="text-base font-black text-white">
                هذه المنطقة مخصصة لإدارة المتجر فقط
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                حفاظاً على خصوصية الزبائن وتفاصيل عقاراتهم وأرقام هواتفهم، يلزم إدخال رمز الدخول السري للمالك لعرض محتوى صندوق الإشعارات.
              </p>
            </div>

            <button
              onClick={() => {
                onClose();
                onOpenOwnerLogin();
              }}
              className="w-full max-w-xs mx-auto bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs py-3 px-4 rounded-2xl transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>تسجيل دخول المالك (PIN)</span>
            </button>
          </div>
        ) : (
          /* When Owner is authenticated: Show live notifications and orders */
          <div className="p-4 sm:p-5 overflow-y-auto no-scrollbar space-y-3.5 flex-1">
            {orders.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-slate-800/60 text-slate-500 flex items-center justify-center mx-auto">
                  <Bell className="w-7 h-7" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-bold text-slate-300">لا توجد إشعارات جديدة حالياً</p>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    بمجرد أن يرسل أي زبون طلب عرض سعر أو يرفق صوراً لجدرانه، ستصلك الإشعارات وتظهر فوراً هنا.
                  </p>
                </div>
              </div>
            ) : (
              orders.map((ord) => {
                const hasImages = ord.images && ord.images.length > 0;
                return (
                  <div
                    key={ord.id}
                    className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-amber-500/40 transition-all space-y-3 shadow-md"
                  >
                    {/* Top line: Name & Time */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                        <span className="font-extrabold text-sm text-white">{ord.clientName}</span>
                        <span className="text-[10px] bg-slate-800 text-amber-400 font-mono font-bold px-1.5 py-0.5 rounded">
                          #{ord.id}
                        </span>
                      </div>

                      <span className="text-[10px] text-slate-400 flex items-center gap-1 font-medium">
                        <Clock className="w-3 h-3 text-slate-500" />
                        {ord.createdAt}
                      </span>
                    </div>

                    {/* Summary row */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-2 rounded-xl bg-slate-900 border border-slate-800/80">
                        <span className="text-[10px] text-slate-500 block">الخدمة:</span>
                        <span className="font-bold text-amber-400">{ord.serviceTitle}</span>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-900 border border-slate-800/80">
                        <span className="text-[10px] text-slate-500 block">المحافظة:</span>
                        <span className="font-bold text-white flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          {ord.governorate || ord.city || 'سوريا'}
                        </span>
                      </div>
                    </div>

                    {/* Details / Notes */}
                    {ord.details && (
                      <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800 text-[11px] text-slate-300">
                        <span className="text-slate-500 text-[10px] block font-bold mb-0.5">تفاصيل العمل:</span>
                        <p className="line-clamp-2 leading-relaxed">{ord.details}</p>
                      </div>
                    )}

                    {/* ATTACHED IMAGES SECTION */}
                    {hasImages ? (
                      <div className="p-2.5 rounded-xl bg-slate-900/90 border border-amber-500/30 space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-amber-400 flex items-center gap-1.5">
                            <ImageIcon className="w-3.5 h-3.5" />
                            <span>الصور المرفقة من الزبون ({ord.images.length}):</span>
                          </span>
                          <span className="text-[10px] text-slate-400">انقر على أي صورة لتكبيرها</span>
                        </div>

                        <div className="flex gap-2 overflow-x-auto pb-1 pt-0.5">
                          {ord.images.map((img, i) => (
                            <div
                              key={i}
                              onClick={() => onOpenImage(img, `صورة ${i + 1} من الزبون ${ord.clientName}`)}
                              className="relative group cursor-pointer shrink-0 rounded-xl overflow-hidden border border-slate-700 hover:border-amber-400 transition-all"
                            >
                              <img
                                src={img}
                                alt={`صورة ${i + 1}`}
                                className="w-20 h-20 object-cover group-hover:scale-105 transition-transform"
                              />
                              <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <ExternalLink className="w-4 h-4 text-white" />
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="p-2 rounded-xl bg-slate-900/50 border border-slate-800/60 text-[11px] text-slate-400 flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-slate-500" />
                        <span>لم يرفق الزبون صوراً داخل النموذج (يمكن طلبها منه عبر الواتساب).</span>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/80">
                      <a
                        href={`https://wa.me/${ord.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                          `السلام عليكم ورحمة الله، أهلاً بك أخي ${ord.clientName} معك إدارة «السهلي للديكور» بخصوص طلبك رقم #${ord.id}. رأينا طلبك لـ (${ord.serviceTitle}) ويسعدنا تقديم التفاصيل وتحديد موعد المعاينة المجانية.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-black text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>محادثة واتساب فورية</span>
                      </a>

                      <a
                        href={`tel:${ord.phone}`}
                        className="bg-slate-800 hover:bg-slate-750 active:scale-95 text-slate-200 font-bold text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all border border-slate-700"
                      >
                        <Phone className="w-3.5 h-3.5 text-amber-400" />
                        <span>اتصال ({ord.phone})</span>
                      </a>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* Footer */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs">
          <span className="text-[11px] text-slate-400">
            {isOwnerLoggedIn ? (
              <>إجمالي الإشعارات: <strong className="text-white">{orders.length}</strong> طلب</>
            ) : (
              'حماية وتشفير بيانات العملاء'
            )}
          </span>
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-4 py-1.5 rounded-xl transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
