import React from 'react';
import { FileText, X, MessageCircle, Phone, Clock, Trash2, Image as ImageIcon, Eye } from 'lucide-react';
import { QuoteRequest, COMPANY_INFO } from '../data/decorData';

interface MyOrdersModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: QuoteRequest[];
  onClearOrders: () => void;
  onOpenImage?: (url: string, title?: string) => void;
}

export const MyOrdersModal: React.FC<MyOrdersModalProps> = ({
  isOpen,
  onClose,
  orders,
  onClearOrders,
  onOpenImage
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full max-h-[90vh] overflow-y-auto no-scrollbar shadow-2xl text-right p-5 space-y-4 animate-scale-up">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-sm text-white">سجل طلباتي الخاصة</h3>
              <p className="text-[11px] text-slate-400">عروض الأسعار والصور المحفوظة على جهازك</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Orders list */}
        {orders.length === 0 ? (
          <div className="py-10 text-center space-y-2">
            <FileText className="w-12 h-12 text-slate-600 mx-auto" />
            <p className="text-xs text-slate-400 font-bold">لا توجد لديك طلبات محفوظة حالياً</p>
            <p className="text-[11px] text-slate-500">
              عند إرسال طلب عرض سعر، سيتم حفظه مع صوره هنا بشكل خاص لمتابعته في أي وقت.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map((ord) => (
              <div key={ord.id} className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-black text-amber-400">
                    #{ord.id}
                  </span>
                  <span className="text-[10px] text-slate-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {ord.createdAt}
                  </span>
                </div>

                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-500">الخدمة:</span>
                    <span className="font-bold text-white">{ord.serviceTitle}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-500">العميل:</span>
                    <span>{ord.clientName} ({ord.phone})</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-500">الموقع:</span>
                    <span>{ord.city}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-500">نوع العقار والمساحة:</span>
                    <span>{ord.propertyType} - {ord.areaEstimate}</span>
                  </div>
                  {ord.details && (
                    <div className="pt-1 text-slate-400 text-[11px] bg-slate-900/60 p-2 rounded-xl border border-slate-800/60">
                      <span className="text-slate-500 block mb-0.5 font-bold">التفاصيل:</span>
                      {ord.details}
                    </div>
                  )}
                </div>

                {/* Attached Images Preview Grid */}
                {ord.images && ord.images.length > 0 && (
                  <div className="pt-2 border-t border-slate-900 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-amber-400 flex items-center gap-1">
                        <ImageIcon className="w-3.5 h-3.5" />
                        <span>الصور المرفقة بالطلب ({ord.images.length})</span>
                      </span>
                      <span className="text-[10px] text-slate-500">انقر للتكبير والمشاهدة</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {ord.images.map((imgUrl, imgIdx) => (
                        <div
                          key={imgIdx}
                          onClick={() => onOpenImage && onOpenImage(imgUrl, `صورة مرفقة - طلب #${ord.id}`)}
                          className="relative aspect-square rounded-xl overflow-hidden border border-slate-800 group cursor-pointer hover:border-amber-500/60 transition-all"
                        >
                          <img
                            src={imgUrl}
                            alt={`صورة ${imgIdx + 1}`}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                            <Eye className="w-4 h-4 text-white drop-shadow" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Follow up actions */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center gap-2">
                  <a
                    href={`https://wa.me/${COMPANY_INFO.whatsapp}?text=${encodeURIComponent(`السلام عليكم، أود متابعة طلبي رقم #${ord.id} باسم ${ord.clientName}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[11px] font-bold py-1.5 px-2 rounded-lg border border-emerald-500/30 flex items-center justify-center gap-1"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>متابعة على واتساب</span>
                  </a>

                  <a
                    href={`tel:${COMPANY_INFO.internationalPhone}`}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-bold p-1.5 rounded-lg border border-slate-700 flex items-center justify-center"
                    title="اتصال"
                  >
                    <Phone className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}

            <button
              onClick={onClearOrders}
              className="w-full text-center text-[11px] text-rose-400 hover:text-rose-300 flex items-center justify-center gap-1 py-2"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>مسح سجل طلباتي من هذا الهاتف</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
