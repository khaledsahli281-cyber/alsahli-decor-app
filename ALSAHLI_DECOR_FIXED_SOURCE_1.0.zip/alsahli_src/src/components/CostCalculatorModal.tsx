import React, { useState } from 'react';
import { Calculator, X, Sparkles, ArrowLeft, Check, ShieldCheck } from 'lucide-react';

interface CostCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyToQuote: (details: string, area: string) => void;
}

export const CostCalculatorModal: React.FC<CostCalculatorModalProps> = ({
  isOpen,
  onClose,
  onApplyToQuote
}) => {
  const [serviceType, setServiceType] = useState('interior');
  const [area, setArea] = useState<number>(150);
  const [paintQuality, setPaintQuality] = useState<'standard' | 'premium' | 'luxury'>('premium');
  const [needsRestoration, setNeedsRestoration] = useState(false);

  if (!isOpen) return null;

  // Base price per m² in Syrian Pounds (SYP / ل.س)
  let baseRate = 35000;
  if (serviceType === 'interior') baseRate = 35000;
  if (serviceType === 'exterior') baseRate = 55000;
  if (serviceType === 'gypsum') baseRate = 120000;
  if (serviceType === 'wallpaper') baseRate = 75000;
  if (serviceType === 'decorative') baseRate = 85000;

  // Quality multiplier
  let qualityMultiplier = 1.0;
  if (paintQuality === 'standard') qualityMultiplier = 0.85;
  if (paintQuality === 'luxury') qualityMultiplier = 1.35;

  // Restoration add-on in Syrian Pounds
  const restorationAddon = needsRestoration ? 15000 : 0;

  const pricePerMeter = Math.round((baseRate * qualityMultiplier) + restorationAddon);
  const totalMin = Math.round(area * pricePerMeter * 0.95);
  const totalMax = Math.round(area * pricePerMeter * 1.1);

  // Estimated days
  const estimatedDays = Math.max(2, Math.ceil(area / 60));

  const handleApply = () => {
    const serviceNames: { [k: string]: string } = {
      interior: 'دهان داخلي',
      exterior: 'دهان خارجي بروفايل',
      gypsum: 'ديكور وجبس بورد',
      wallpaper: 'ورق جدران',
      decorative: 'أعمال زينة وستوكو ديكوري'
    };
    const qualNames = {
      standard: 'اقتصادي بجودة جيدة',
      premium: 'جوتن أو دهانات أمية ديلوكس (الأكثر طلباً)',
      luxury: 'دهانات كابارول وستوكو إيطالي VIP'
    };

    const summary = `تقدير حاسبة التكلفة:\n- نوع العمل: ${serviceNames[serviceType]}\n- جودة المواد: ${qualNames[paintQuality]}\n- معالجة شقوق وترميم: ${needsRestoration ? 'نعم مطلوب' : 'غير مطلوب'}\n- التكلفة التقريبية المتوقعة: بين ${totalMin.toLocaleString()} و ${totalMax.toLocaleString()} ليرة سورية`;

    onApplyToQuote(summary, `${area} م² تقريباً`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full max-h-[92vh] overflow-y-auto no-scrollbar shadow-2xl text-right p-5 space-y-4 animate-scale-up">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-sm text-white">حاسبة التكلفة التقديرية</h3>
              <p className="text-[11px] text-slate-400">حساب سعر الدهان والجبس بالمتر المربع</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 1. Service Type */}
        <div>
          <label className="block text-xs font-bold text-slate-300 mb-1.5">
            نوع الخدمة المطلوبة:
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'interior', label: 'دهان داخلي' },
              { id: 'exterior', label: 'دهان خارجي بروفايل' },
              { id: 'gypsum', label: 'جبس بورد وأسقف' },
              { id: 'decorative', label: 'ستوكو وديكور فني' },
            ].map((st) => (
              <button
                key={st.id}
                type="button"
                onClick={() => setServiceType(st.id)}
                className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all text-center ${
                  serviceType === st.id
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'bg-slate-950 text-slate-300 border border-slate-800 hover:border-slate-700'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        </div>

        {/* 2. Area Slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-xs">
            <span className="font-bold text-slate-300">المساحة الإجمالية للجدران:</span>
            <span className="font-extrabold text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded-lg border border-amber-500/20 font-mono">
              {area} م²
            </span>
          </div>
          <input
            type="range"
            min="30"
            max="1200"
            step="10"
            value={area}
            onChange={(e) => setArea(Number(e.target.value))}
            className="w-full accent-amber-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>30 م² (غرفة واحدة)</span>
            <span>200 م² (شقة)</span>
            <span>600+ م² (فيلا كاملة)</span>
          </div>
        </div>

        {/* 3. Paint Quality Tier */}
        <div>
          <label className="block text-xs font-bold text-slate-300 mb-1.5">
            فئة وماركة الدهانات:
          </label>
          <div className="grid grid-cols-3 gap-1.5 text-center">
            {[
              { id: 'standard', title: 'اقتصادي', sub: 'جودة قياسية' },
              { id: 'premium', title: 'الأكثر طلباً', sub: 'جوتن / أمية ديلوكس' },
              { id: 'luxury', title: 'VIP فاخر', sub: 'كابارول / ستوكو' },
            ].map((tier) => (
              <div
                key={tier.id}
                onClick={() => setPaintQuality(tier.id as any)}
                className={`p-2 rounded-xl border cursor-pointer transition-all ${
                  paintQuality === tier.id
                    ? 'bg-amber-500/15 border-amber-500 text-white'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold">{tier.title}</div>
                <div className="text-[9px] text-slate-400 mt-0.5">{tier.sub}</div>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Restoration Checkbox */}
        <label className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
          <input
            type="checkbox"
            checked={needsRestoration}
            onChange={(e) => setNeedsRestoration(e.target.checked)}
            className="w-4 h-4 accent-amber-500 rounded"
          />
          <span className="text-xs text-slate-300">
            الجدران بها تشققات أو رطوبة تحتاج معالجة وتأسيس معجون إضافي
          </span>
        </label>

        {/* 5. Calculation Result Box */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border border-amber-500/40 space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>التكلفة التقديرية الشاملة للمواد واليد:</span>
            <span className="text-amber-400 font-bold">~{pricePerMeter.toLocaleString()} ل.س / م²</span>
          </div>

          <div className="text-center py-2 bg-slate-950/70 rounded-xl border border-slate-800">
            <span className="text-xl sm:text-2xl font-black text-amber-400 font-mono">
              {totalMin.toLocaleString()} - {totalMax.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-slate-300 mr-1.5">ليرة سورية (ل.س)</span>
            <span className="block text-[10px] text-slate-500 mt-0.5">
              السعر يشمل المواد الأصلية والمصنعية والتغليف وإتقان التنفيذ
            </span>
          </div>

          <div className="flex justify-between text-xs text-slate-400 pt-1">
            <span>مدة التنفيذ التقريبية:</span>
            <span className="font-bold text-white">{estimatedDays} - {estimatedDays + 2} أيام عمل</span>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2 pt-1">
          <button
            onClick={handleApply}
            className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs py-3 rounded-xl transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-1.5"
          >
            <span>نقل هذه البيانات إلى نموذج طلب السعر</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
          <p className="text-[10px] text-slate-500 text-center">
            * هذا السعر تقديري ويتم تثبيت السعر النهائي بدقة عند المعاينة المجانية في الموقع.
          </p>
        </div>
      </div>
    </div>
  );
};
