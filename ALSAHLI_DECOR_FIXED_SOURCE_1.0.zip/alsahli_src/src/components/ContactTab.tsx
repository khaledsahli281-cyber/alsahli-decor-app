import React, { useState } from 'react';
import { 
  PhoneCall, 
  MessageCircle, 
  Mail, 
  MapPin, 
  Clock, 
  Send, 
  CheckCircle2, 
  ChevronDown, 
  ShieldCheck, 
  Sparkles,
  Award
} from 'lucide-react';
import { COMPANY_INFO, FAQS } from '../data/decorData';

export const ContactTab: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [quickMsg, setQuickMsg] = useState({ name: '', phone: '', message: '' });
  const [msgSent, setMsgSent] = useState(false);

  const handleSendQuickMsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickMsg.name || !quickMsg.phone) return;

    const text = encodeURIComponent(
      `*استفسار من تطبيق السهلي للديكور*\n\n` +
      `👤 *الاسم:* ${quickMsg.name}\n` +
      `📱 *الهاتف:* ${quickMsg.phone}\n` +
      `💬 *الرسالة:* ${quickMsg.message || 'أرغب بمعلومات إضافية'}`
    );

    window.open(`https://wa.me/${COMPANY_INFO.whatsapp}?text=${text}`, '_blank');
    setMsgSent(true);
    setQuickMsg({ name: '', phone: '', message: '' });
  };

  return (
    <div className="space-y-6 pb-24 text-right">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 text-xs font-bold mb-1.5">
          <PhoneCall className="w-3.5 h-3.5" />
          <span>قنوات التواصل الرسمية</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white">
          تواصل مع «السهلي للديكور»
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-lg">
          نسعد باستقبال اتصالاتكم واستفساراتكم على مدار الأسبوع لحجز مواعيد المعاينة المجانية وتقديم الاستشارات الفنية.
        </p>
      </div>

      {/* Main Direct Channels Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* WhatsApp Direct Card */}
        <a
          href={`https://wa.me/${COMPANY_INFO.whatsapp}?text=${encodeURIComponent('السلام عليكم، أود الاستفسار عن خدمات الدهانات والديكور لدى السهلي')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="group p-5 rounded-3xl bg-gradient-to-br from-emerald-950/80 via-slate-900 to-slate-950 border border-emerald-500/40 hover:border-emerald-400 transition-all shadow-xl flex items-center justify-between"
        >
          <div className="space-y-1">
            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-extrabold px-2 py-0.5 rounded-full inline-block">
              الرد فوري
            </span>
            <h3 className="text-base font-black text-white group-hover:text-emerald-300 transition-colors">
              محادثة واتساب مباشرة
            </h3>
            <p className="text-xs text-slate-400 font-mono" dir="ltr">
              {COMPANY_INFO.phone}
            </p>
            <p className="text-[11px] text-slate-500">
              أرسل صور موقعك واحصل على تسعير فوري
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/30 group-hover:scale-110 transition-transform">
            <MessageCircle className="w-6 h-6 stroke-[2.5]" />
          </div>
        </a>

        {/* Direct Call Card */}
        <a
          href={`tel:${COMPANY_INFO.internationalPhone}`}
          className="group p-5 rounded-3xl bg-gradient-to-br from-amber-950/60 via-slate-900 to-slate-950 border border-amber-500/40 hover:border-amber-400 transition-all shadow-xl flex items-center justify-between"
        >
          <div className="space-y-1">
            <span className="text-[10px] bg-amber-500/20 text-amber-300 font-extrabold px-2 py-0.5 rounded-full inline-block">
              مكالمة هاتفية
            </span>
            <h3 className="text-base font-black text-white group-hover:text-amber-300 transition-colors">
              اتصال هاتفي مباشر
            </h3>
            <p className="text-xs text-slate-400 font-mono" dir="ltr">
              {COMPANY_INFO.phone}
            </p>
            <p className="text-[11px] text-slate-500">
              تحدث مباشرة مع المشرف الفني
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-500/30 group-hover:scale-110 transition-transform">
            <PhoneCall className="w-6 h-6 stroke-[2.5]" />
          </div>
        </a>
      </div>

      {/* Info & Coverage Grid */}
      <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-5 space-y-4 shadow-xl">
        <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>معلومات التواجد والتغطية</span>
        </h3>

        <div className="space-y-3 text-xs text-slate-300">
          <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-white text-xs mb-0.5">منطقة التغطية والمعاينة:</h4>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                {COMPANY_INFO.address}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <div className="w-9 h-9 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-white text-xs mb-0.5">أوقات العمل الرسمية:</h4>
              <p className="text-slate-400 text-[11px]">
                {COMPANY_INFO.workingHours} (طيلة أيام الأسبوع)
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center shrink-0">
              <Mail className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-white text-xs mb-0.5">البريد الإلكتروني وحساب التواصل:</h4>
              <a 
                href={`mailto:${COMPANY_INFO.email}`}
                className="text-amber-400 hover:text-amber-300 text-xs font-mono block hover:underline font-bold"
                dir="ltr"
              >
                {COMPANY_INFO.email}
              </a>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono font-bold border border-slate-700">
                  {COMPANY_INFO.handle}
                </span>
                <span className="text-[11px] text-slate-400">حساب السهلي للديكور</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Message Form */}
      <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-5 space-y-3 shadow-xl">
        <h3 className="text-xs font-black text-amber-400 uppercase tracking-wider">
          إرسال استفسار أو طلب معاينة سريع
        </h3>

        {msgSent ? (
          <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <p className="text-xs font-bold text-emerald-300">
              تم توجيه رسالتك عبر الواتساب بنجاح!
            </p>
            <button
              onClick={() => setMsgSent(false)}
              className="text-[11px] text-slate-400 underline"
            >
              إرسال استفسار آخر
            </button>
          </div>
        ) : (
          <form onSubmit={handleSendQuickMsg} className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                required
                value={quickMsg.name}
                onChange={(e) => setQuickMsg({ ...quickMsg, name: e.target.value })}
                placeholder="الاسم"
                className="bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2 px-3 text-xs text-white placeholder-slate-500 outline-none"
              />
              <input
                type="tel"
                required
                value={quickMsg.phone}
                onChange={(e) => setQuickMsg({ ...quickMsg, phone: e.target.value })}
                placeholder="رقم الجوال"
                dir="ltr"
                className="bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl py-2 px-3 text-xs text-white placeholder-slate-500 outline-none text-right"
              />
            </div>

            <textarea
              rows={3}
              value={quickMsg.message}
              onChange={(e) => setQuickMsg({ ...quickMsg, message: e.target.value })}
              placeholder="اكتب استفسارك هنا..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl p-3 text-xs text-white placeholder-slate-500 outline-none"
            />

            <button
              type="submit"
              className="w-full bg-amber-500 hover:bg-amber-400 active:scale-98 text-slate-950 font-black text-xs py-2.5 rounded-xl transition-all shadow-md shadow-amber-500/10 flex items-center justify-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>إرسال الاستفسار عبر الواتساب</span>
            </button>
          </form>
        )}
      </div>

      {/* Frequently Asked Questions (FAQ) */}
      <div className="space-y-3">
        <div className="text-right">
          <h3 className="text-base font-extrabold text-white">الأسئلة الشائعة</h3>
          <p className="text-xs text-slate-400">إجابات على أكثر الاستفسارات التي تهم عملاءنا</p>
        </div>

        <div className="space-y-2">
          {FAQS.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-4 flex items-center justify-between text-right text-xs font-bold text-white hover:text-amber-400 transition-colors"
                >
                  <span className="flex-1 pr-1">{faq.question}</span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transform transition-transform ${
                    isOpen ? 'rotate-180 text-amber-400' : ''
                  }`} />
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 pt-1 border-t border-slate-800/60 text-xs text-slate-300 leading-relaxed bg-slate-950/40">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
