import React, { useState } from 'react';
import { 
  FileText, 
  Layers, 
  Image as ImageIcon, 
  PhoneCall, 
  CheckCircle2, 
  Star, 
  ArrowLeft, 
  Sparkles, 
  Clock, 
  ShieldCheck, 
  Calculator, 
  Palette, 
  ChevronLeft,
  Award,
  Users,
  Share2,
  Copy,
  Smartphone,
  Check
} from 'lucide-react';
import { COMPANY_INFO, SERVICES, GALLERY_ITEMS, TESTIMONIALS } from '../data/decorData';

interface HomeTabProps {
  setActiveTab: (tab: string) => void;
  onSelectService: (serviceId: string) => void;
  onOpenCalculator: () => void;
  onOpenColors: () => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  setActiveTab,
  onSelectService,
  onOpenCalculator,
  onOpenColors
}) => {
  const heroImage = SERVICES[0].image;
  const [copied, setCopied] = useState(false);
  const [showInstallGuide, setShowInstallGuide] = useState(false);

  const handleShareWhatsApp = () => {
    const shareUrl = window.location.origin;
    const shareText = `أهلاً بك! جرّب تطبيق «السهلي للديكور» لخدمات الدهانات والجبس بورد وأعمال الترميم والمعاينة المجانية في سوريا:\n${shareUrl}`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`, '_blank');
  };

  const handleCopyAppUrl = () => {
    navigator.clipboard.writeText(window.location.origin);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* 1. Welcome Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl">
        <div className="relative h-64 sm:h-80 w-full overflow-hidden">
          <img
            src={heroImage}
            alt="السهلي للديكور والدهانات"
            className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-slate-950/20" />
          
          {/* Top Floating Badge */}
          <div className="absolute top-4 right-4 bg-slate-950/80 backdrop-blur-md border border-amber-500/30 text-amber-300 text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-lg">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-bold">أحدث تصاميم وتشطيبات 2026</span>
          </div>

          {/* Hero Content */}
          <div className="absolute bottom-4 right-4 left-4 text-right">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="bg-amber-500 text-slate-950 text-[11px] font-black px-2 py-0.5 rounded shadow">
                {COMPANY_INFO.name}
              </span>
              <span className="text-xs text-slate-300 flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                تقييم 4.9 من أكثر من 1,000 عميل
              </span>
            </div>
            
            <h2 className="text-xl sm:text-2xl font-black text-white leading-tight mb-2">
              حوّل منزلك إلى تحفة فنية بأيدي أمهر معلمي الدهان والديكور
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 line-clamp-2 max-w-xl">
              تنفيذ احترافي للدهانات الداخلية والخارجية والجبس بورد وبدائل الخشب والرخام بإتقان هندسي فني ومعاينة مجانية في موقعك.
            </p>
          </div>
        </div>
      </div>

      {/* 2. Primary 4 Action Buttons Requested By User */}
      <div className="bg-slate-900/90 p-4 rounded-3xl border border-slate-800 shadow-xl backdrop-blur-sm">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>الوصول السريع للخدمات</span>
        </h3>

        <div className="grid grid-cols-2 gap-3">
          {/* Button 1: اطلب عرض سعر */}
          <button
            onClick={() => setActiveTab('quote')}
            className="group relative overflow-hidden bg-gradient-to-br from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 p-4 rounded-2xl flex flex-col items-start justify-between shadow-lg shadow-amber-500/20 active:scale-95 transition-all text-right"
          >
            <div className="w-full flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-slate-950/15 flex items-center justify-center">
                <FileText className="w-5 h-5 text-slate-950" />
              </div>
              <span className="text-[10px] bg-slate-950 text-amber-300 font-bold px-2 py-0.5 rounded-full">
                مجاناً
              </span>
            </div>
            <div>
              <span className="font-extrabold text-base text-slate-950 block leading-tight">
                اطلب عرض سعر
              </span>
              <span className="text-[11px] text-slate-900 font-medium block mt-0.5">
                حساب التكلفة ومعاينة فورية
              </span>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-950/80 absolute bottom-3 left-3 transform group-hover:-translate-x-1 transition-transform" />
          </button>

          {/* Button 2: خدماتنا */}
          <button
            onClick={() => setActiveTab('services')}
            className="group relative overflow-hidden bg-gradient-to-br from-slate-800 to-slate-850 hover:from-slate-750 hover:to-slate-800 border border-slate-700/80 text-white p-4 rounded-2xl flex flex-col items-start justify-between shadow-lg active:scale-95 transition-all text-right"
          >
            <div className="w-full flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center">
                <Layers className="w-5 h-5 text-amber-400" />
              </div>
              <span className="text-[10px] bg-slate-700 text-slate-300 font-medium px-2 py-0.5 rounded-full">
                6 تخصصات
              </span>
            </div>
            <div>
              <span className="font-extrabold text-base text-white block leading-tight">
                خدماتنا
              </span>
              <span className="text-[11px] text-slate-400 font-medium block mt-0.5">
                دهانات، جبس، ورق جدران
              </span>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-400 absolute bottom-3 left-3 transform group-hover:-translate-x-1 transition-transform" />
          </button>

          {/* Button 3: معرض أعمالنا */}
          <button
            onClick={() => setActiveTab('gallery')}
            className="group relative overflow-hidden bg-gradient-to-br from-slate-800 to-slate-850 hover:from-slate-750 hover:to-slate-800 border border-slate-700/80 text-white p-4 rounded-2xl flex flex-col items-start justify-between shadow-lg active:scale-95 transition-all text-right"
          >
            <div className="w-full flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center">
                <ImageIcon className="w-5 h-5 text-sky-400" />
              </div>
              <span className="text-[10px] bg-sky-500/20 text-sky-300 font-medium px-2 py-0.5 rounded-full">
                صور واقعية
              </span>
            </div>
            <div>
              <span className="font-extrabold text-base text-white block leading-tight">
                معرض أعمالنا
              </span>
              <span className="text-[11px] text-slate-400 font-medium block mt-0.5">
                أحدث المشاريع وقبل وبعد
              </span>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-400 absolute bottom-3 left-3 transform group-hover:-translate-x-1 transition-transform" />
          </button>

          {/* Button 4: تواصل معنا */}
          <button
            onClick={() => setActiveTab('contact')}
            className="group relative overflow-hidden bg-gradient-to-br from-emerald-950/60 to-slate-900 hover:from-emerald-900/60 hover:to-slate-850 border border-emerald-500/30 text-white p-4 rounded-2xl flex flex-col items-start justify-between shadow-lg active:scale-95 transition-all text-right"
          >
            <div className="w-full flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
                <PhoneCall className="w-5 h-5 text-emerald-400" />
              </div>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-medium px-2 py-0.5 rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                متاح الآن
              </span>
            </div>
            <div>
              <span className="font-extrabold text-base text-white block leading-tight">
                تواصل معنا
              </span>
              <span className="text-[11px] text-slate-400 font-medium block mt-0.5">
                واتساب، اتصال مباشر
              </span>
            </div>
            <ArrowLeft className="w-4 h-4 text-emerald-400 absolute bottom-3 left-3 transform group-hover:-translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      {/* 2.5 Quick Share & Install on Phone Card */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-slate-900 via-sky-950/40 to-slate-900 border border-sky-500/30 shadow-lg text-right space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
            <h3 className="font-extrabold text-xs sm:text-sm text-white">
              تثبيت التطبيق على هاتفك ومشاركته
            </h3>
          </div>
          <span className="text-[10px] bg-sky-500/15 text-sky-300 font-bold px-2 py-0.5 rounded-full border border-sky-500/25">
            للتجربة والاختبار
          </span>
        </div>

        <p className="text-[11px] text-slate-300 leading-relaxed">
          يمكنك حفظ هذا التطبيق مباشرة كأيقونة على شاشة جوالك، ومشاركته بضغطة زر مع أصدقائك عبر الواتساب لتجربته معاً:
        </p>

        <div className="grid grid-cols-2 gap-2">
          {/* Share WhatsApp */}
          <button
            onClick={handleShareWhatsApp}
            className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-md shadow-emerald-500/15"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>إرسال عبر الواتساب</span>
          </button>

          {/* Copy Link */}
          <button
            onClick={handleCopyAppUrl}
            className="bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-bold text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all active:scale-95"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">تم نسخ الرابط!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-amber-400" />
                <span>نسخ رابط التطبيق</span>
              </>
            )}
          </button>
        </div>

        {/* Toggle Install Guide */}
        <button
          onClick={() => setShowInstallGuide(!showInstallGuide)}
          className="w-full text-center text-[11px] text-sky-400 hover:text-sky-300 underline pt-0.5 block"
        >
          {showInstallGuide ? 'إخفاء طريقة التثبيت على الجوال ▲' : 'كيف أضيف التطبيق لشاشة هاتفي بدون متجر؟ ▼'}
        </button>

        {showInstallGuide && (
          <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800/80 space-y-1.5 text-[11px] text-slate-300 animate-fade-in">
            <div className="flex items-start gap-2">
              <span className="w-4 h-4 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">1</span>
              <span>افتح هذا الرابط في متصفح <strong>Google Chrome</strong> على جوالك.</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="w-4 h-4 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">2</span>
              <span>اضغط على خيارات المتصفح (النقاط الثلاث <strong>⋮</strong> في زاوية الشاشة).</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="w-4 h-4 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">3</span>
              <span>اختر <strong>«إضافة إلى الشاشة الرئيسية»</strong> أو <strong>«تثبيت التطبيق»</strong>.</span>
            </div>
            <p className="text-[10px] text-emerald-400 pt-1 border-t border-slate-800 font-medium">
              ✨ سيعمل التطبيق الآن كبرنامج مستقل على هاتفك بكامل الشاشة وبأيقونة السهلي للديكور!
            </p>
          </div>
        )}
      </div>

      {/* 3. Value Props & Trust Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="bg-slate-900/70 p-3 rounded-2xl border border-slate-800 text-center flex flex-col items-center">
          <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-1.5">
            <Award className="w-5 h-5" />
          </div>
          <span className="text-base font-black text-white">{COMPANY_INFO.experienceYears}</span>
          <span className="text-[11px] text-slate-400">في سوق الدهانات</span>
        </div>

        <div className="bg-slate-900/70 p-3 rounded-2xl border border-slate-800 text-center flex flex-col items-center">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-1.5">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <span className="text-base font-black text-white">إتقان وجودة</span>
          <span className="text-[11px] text-slate-400">معايير فنية عالية</span>
        </div>

        <div className="bg-slate-900/70 p-3 rounded-2xl border border-slate-800 text-center flex flex-col items-center">
          <div className="w-9 h-9 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center mb-1.5">
            <Users className="w-5 h-5" />
          </div>
          <span className="text-base font-black text-white">{COMPANY_INFO.completedProjects}</span>
          <span className="text-[11px] text-slate-400">مشروع تم تسليمه</span>
        </div>

        <div className="bg-slate-900/70 p-3 rounded-2xl border border-slate-800 text-center flex flex-col items-center">
          <div className="w-9 h-9 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center mb-1.5">
            <Clock className="w-5 h-5" />
          </div>
          <span className="text-base font-black text-white">دقة المواعيد</span>
          <span className="text-[11px] text-slate-400">تسليم حسب العقد</span>
        </div>
      </div>

      {/* 4. Interactive Smart Tools (Paint Calculator + Colors) */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-amber-500/20 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400"></span>
            <h3 className="font-extrabold text-sm text-white">أدوات مساعدة لعملائنا</h3>
          </div>
          <span className="text-[11px] text-amber-400 font-medium">خدمة حصرية</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Tool 1: Paint Calculator */}
          <div 
            onClick={onOpenCalculator}
            className="p-3.5 rounded-2xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 hover:border-amber-500/40 cursor-pointer transition-all flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center">
                <Calculator className="w-5 h-5" />
              </div>
              <div className="text-right">
                <h4 className="font-bold text-xs text-white group-hover:text-amber-300 transition-colors">
                  حاسبة تكلفة الدهان التقديرية
                </h4>
                <p className="text-[11px] text-slate-400">
                  احسب بالمتر المربع التكلفة والكميات فوراً
                </p>
              </div>
            </div>
            <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:text-amber-400 group-hover:-translate-x-1 transition-all" />
          </div>

          {/* Tool 2: Color Palette */}
          <div 
            onClick={onOpenColors}
            className="p-3.5 rounded-2xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 hover:border-sky-500/40 cursor-pointer transition-all flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-sky-500/15 text-sky-400 flex items-center justify-center">
                <Palette className="w-5 h-5" />
              </div>
              <div className="text-right">
                <h4 className="font-bold text-xs text-white group-hover:text-sky-300 transition-colors">
                  كتالوج ألوان 2026 الرائجة
                </h4>
                <p className="text-[11px] text-slate-400">
                  أشهر درجات الجريج والأوف وايت وأكوادها
                </p>
              </div>
            </div>
            <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:text-sky-400 group-hover:-translate-x-1 transition-all" />
          </div>
        </div>
      </div>

      {/* 5. Services Spotlight */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <div>
            <h3 className="text-base font-extrabold text-white">خدماتنا المعتمدة</h3>
            <p className="text-xs text-slate-400">تشكيلة شاملة لكل ما يحتاجه منزلك أو منشأتك</p>
          </div>
          <button
            onClick={() => setActiveTab('services')}
            className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
          >
            <span>عرض الكل</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              onClick={() => onSelectService(service.id)}
              className="group cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 overflow-hidden shadow-md transition-all hover:scale-[1.02] flex flex-col justify-between"
            >
              <div className="relative h-28 w-full overflow-hidden">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />
                <span className="absolute bottom-2 right-2 text-white font-black text-xs">
                  {service.title}
                </span>
              </div>
              <div className="p-2.5 text-right flex-1 flex flex-col justify-between">
                <p className="text-[11px] text-slate-400 line-clamp-2 mb-2 leading-relaxed">
                  {service.shortDesc}
                </p>
                <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                  <span className="text-[10px] text-amber-400 font-bold">
                    {service.startingPrice}
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium group-hover:text-amber-300 transition-colors flex items-center">
                    طلب الخدمة
                    <ChevronLeft className="w-3 h-3 inline mr-0.5" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 6. Recent Gallery Teaser */}
      <div className="bg-slate-900/60 p-4 rounded-3xl border border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-base font-extrabold text-white">من أعمالنا الأخيرة</h3>
            <p className="text-xs text-slate-400">صور حية من مواقع العمل في دمشق ومختلف المحافظات السورية</p>
          </div>
          <button
            onClick={() => setActiveTab('gallery')}
            className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
          >
            <span>المعرض كامل</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {GALLERY_ITEMS.slice(0, 2).map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveTab('gallery')}
              className="group cursor-pointer relative h-36 rounded-2xl overflow-hidden border border-slate-800"
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <div className="absolute bottom-2.5 right-2.5 left-2.5 text-right">
                <span className="bg-amber-500/90 text-slate-950 text-[9px] font-extrabold px-1.5 py-0.5 rounded">
                  {item.categoryLabel}
                </span>
                <h4 className="text-xs font-bold text-white truncate mt-1">
                  {item.title}
                </h4>
                <p className="text-[10px] text-slate-400 truncate">
                  {item.location}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 7. Why Choose Us Checklist */}
      <div className="bg-gradient-to-br from-amber-500/10 via-slate-900 to-slate-900 p-4 rounded-3xl border border-amber-500/20">
        <h3 className="font-extrabold text-sm text-white mb-2.5 flex items-center gap-1.5">
          <CheckCircle2 className="w-4 h-4 text-amber-400" />
          <span>لماذا يفضل العملاء «السهلي للديكور»؟</span>
        </h3>
        <div className="space-y-2 text-xs text-slate-300">
          <div className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0"></span>
            <span>استخدام بويات أصلية 100% من جوتن وأمية مع فواتير وإثبات مطابقة المواد.</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0"></span>
            <span>معلمون وفنيون متخصصون بخبرة تفوق 15 عاماً في الديكورات المعمارية الدقيقة.</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0"></span>
            <span>تغليف كامل للأرضيات والأثاث وتنظيف شامل بعد إتمام كافة الأعمال.</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0"></span>
            <span>معاينة ورفع مقاسات مجانية مع تقديم نماذج وعينات على الجدار قبل البدء.</span>
          </div>
        </div>
      </div>

      {/* 8. Testimonials Section */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <div>
            <h3 className="text-base font-extrabold text-white">آراء عملائنا الكرام</h3>
            <p className="text-xs text-slate-400">تقييمات حقيقية من عملائنا في مختلف المناطق</p>
          </div>
        </div>

        <div className="space-y-3">
          {TESTIMONIALS.map((t) => (
            <div key={t.id} className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-right">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <span className="text-[10px] text-slate-500">{t.date}</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed mb-2 font-normal">
                "{t.comment}"
              </p>
              <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-[11px]">
                <span className="font-bold text-white">{t.name} - <span className="text-slate-400 font-normal">{t.city}</span></span>
                <span className="text-amber-400/90 bg-amber-500/10 px-2 py-0.5 rounded text-[10px]">
                  {t.service}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 9. Direct Call-To-Action Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 text-slate-950 text-center shadow-xl shadow-amber-500/20">
        <h3 className="text-lg font-black mb-1">جاهز لتجديد ديكور منزلك؟</h3>
        <p className="text-xs text-slate-900 font-medium mb-4 max-w-sm mx-auto">
          أرسل طلبك الآن واحصل على معاينة فورية وخصم خاص على أعمال المساحات الكبيرة!
        </p>
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => setActiveTab('quote')}
            className="bg-slate-950 text-white font-extrabold text-xs px-5 py-2.5 rounded-xl hover:bg-slate-900 transition-transform active:scale-95 shadow-md"
          >
            اطلب عرض سعر الآن
          </button>
          <a
            href={`https://wa.me/${COMPANY_INFO.whatsapp}?text=${encodeURIComponent('السلام عليكم، أود حجز موعد معاينة مجانية لدهانات وديكور')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white/90 hover:bg-white text-slate-950 font-bold text-xs px-4 py-2.5 rounded-xl transition-transform active:scale-95 shadow-md flex items-center gap-1"
          >
            واتساب سريع
          </a>
        </div>
      </div>
    </div>
  );
};
