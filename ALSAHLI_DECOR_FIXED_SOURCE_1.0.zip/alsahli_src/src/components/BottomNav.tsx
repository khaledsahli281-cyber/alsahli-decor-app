import React from 'react';
import { Home, Layers, Image as ImageIcon, PhoneCall, FileText } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'services', label: 'خدماتنا', icon: Layers },
    { id: 'quote', label: 'طلب سعر', icon: FileText, isCenter: true },
    { id: 'gallery', label: 'المعرض', icon: ImageIcon },
    { id: 'contact', label: 'تواصل معنا', icon: PhoneCall },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-lg border-t border-slate-800/80 shadow-[0_-8px_20px_rgba(0,0,0,0.5)]">
      {/* Android System Nav Line */}
      <div className="w-28 h-1 bg-slate-600/40 rounded-full mx-auto my-1"></div>

      <div className="max-w-md mx-auto px-3 pb-2 pt-0.5 flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          if (tab.isCenter) {
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="relative -top-3 flex flex-col items-center group focus:outline-none"
              >
                <div className={`w-13 h-13 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-300 transform group-hover:scale-105 active:scale-95 ${
                  isActive
                    ? 'bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-300 text-slate-950 shadow-amber-500/40 ring-4 ring-amber-500/30'
                    : 'bg-gradient-to-tr from-amber-600 to-amber-500 text-slate-950 shadow-amber-600/30 ring-2 ring-slate-900'
                }`}>
                  <Icon className="w-6 h-6 stroke-[2.5]" />
                </div>
                <span className={`text-[11px] font-bold mt-1 transition-colors ${
                  isActive ? 'text-amber-400 font-extrabold' : 'text-slate-300'
                }`}>
                  {tab.label}
                </span>
                <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
                </span>
              </button>
            );
          }

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center py-1 px-2.5 rounded-xl transition-all duration-200 select-none ${
                isActive
                  ? 'text-amber-400'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className={`p-1 rounded-lg transition-all ${
                isActive ? 'bg-amber-500/15' : 'bg-transparent'
              }`}>
                <Icon className={`w-5 h-5 transition-transform duration-200 ${
                  isActive ? 'scale-110 stroke-[2.4]' : 'stroke-[1.8]'
                }`} />
              </div>
              <span className={`text-[11px] mt-0.5 tracking-tight ${
                isActive ? 'font-bold text-amber-400' : 'font-medium'
              }`}>
                {tab.label}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-0.5 animate-fade-in" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
