import React from 'react';
import { X, ZoomIn, Download, ExternalLink } from 'lucide-react';

interface ImageViewerModalProps {
  imageUrl: string | null;
  title?: string;
  onClose: () => void;
}

export const ImageViewerModal: React.FC<ImageViewerModalProps> = ({
  imageUrl,
  title,
  onClose
}) => {
  if (!imageUrl) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-center p-3 sm:p-6 animate-fade-in">
      {/* Top Header */}
      <div className="w-full max-w-2xl flex items-center justify-between pb-3 text-white">
        <div className="text-right">
          <h3 className="font-bold text-sm sm:text-base text-amber-400">
            {title || 'معاينة صورة العقار المرفقة من الزبون'}
          </h3>
          <p className="text-[11px] text-slate-400">انقر خارج الصورة أو على زر الإغلاق للعودة</p>
        </div>

        <div className="flex items-center gap-2">
          <a
            href={imageUrl}
            download="customer-wall-photo.jpg"
            className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-all"
            title="تحميل الصورة"
          >
            <Download className="w-4 h-4" />
          </a>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center transition-all"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Image Container */}
      <div className="relative max-w-2xl w-full max-h-[80vh] flex items-center justify-center overflow-hidden rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl p-1">
        <img
          src={imageUrl}
          alt={title || 'صورة الجدار'}
          className="max-h-[75vh] w-auto object-contain rounded-xl"
        />
      </div>
    </div>
  );
};
