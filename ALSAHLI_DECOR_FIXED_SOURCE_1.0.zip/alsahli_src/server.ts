import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

// Support JSON body up to 20MB for compressed photos
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// In-memory + disk persistent storage for orders
const ORDERS_FILE = path.resolve(process.cwd(), 'data_orders.json');
const SETTINGS_FILE = path.resolve(process.cwd(), 'data_settings.json');

function loadSettings(): Record<string, any> {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      return JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf-8'));
    }
  } catch (err) {
    console.error('Error loading settings:', err);
  }
  return { pin: '2026' };
}

function saveSettings(settings: Record<string, any>) {
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving settings:', err);
  }
}

let inMemorySettings = loadSettings();

function loadOrders(): any[] {
  try {
    if (fs.existsSync(ORDERS_FILE)) {
      const data = fs.readFileSync(ORDERS_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error loading orders:', err);
  }
  return [];
}

function saveOrders(orders: any[]) {
  try {
    fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving orders:', err);
  }
}

let inMemoryOrders = loadOrders();

// API: Get all orders
app.get('/api/orders', (_req, res) => {
  res.json({ success: true, orders: inMemoryOrders });
});

// API: Create new order
app.post('/api/orders', (req, res) => {
  const newOrder = req.body;
  if (!newOrder || !newOrder.id) {
    return res.status(400).json({ success: false, error: 'Invalid order data' });
  }

  // Prepend to top
  inMemoryOrders = [newOrder, ...inMemoryOrders.filter(o => o.id !== newOrder.id)];
  saveOrders(inMemoryOrders);

  res.json({ success: true, order: newOrder });
});

// API: Update order status
app.patch('/api/orders/:id', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  inMemoryOrders = inMemoryOrders.map(o => o.id === id ? { ...o, status } : o);
  saveOrders(inMemoryOrders);

  res.json({ success: true });
});

// API: Delete order
app.delete('/api/orders/:id', (req, res) => {
  const { id } = req.params;
  inMemoryOrders = inMemoryOrders.filter(o => o.id !== id);
  saveOrders(inMemoryOrders);

  res.json({ success: true });
});

// API: Get owner settings (PIN, etc.)
app.get('/api/settings', (_req, res) => {
  res.json({ success: true, settings: inMemorySettings });
});

// API: Update owner PIN
app.post('/api/settings/pin', (req, res) => {
  const { pin } = req.body;
  if (!pin) {
    return res.status(400).json({ success: false, error: 'PIN is required' });
  }
  const cleanPin = pin.toString().trim();
  inMemorySettings.pin = cleanPin;
  saveSettings(inMemorySettings);
  console.log('Owner PIN updated successfully:', cleanPin);
  res.json({ success: true, pin: cleanPin });
});

async function startServer() {
  if (!isProd) {
    // Vite middleware in dev
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
