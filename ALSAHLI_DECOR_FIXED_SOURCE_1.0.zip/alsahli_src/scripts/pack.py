import os
import zipfile

def create_archive():
    output_filename = './public/alsahli-decor-app.zip'
    base_dir = '.'
    
    # Exclude node_modules, .git, etc.
    excludes = {'node_modules', '.git', '.cache', '__pycache__'}
    
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(base_dir):
            dirs[:] = [d for d in dirs if d not in excludes]
            for file in files:
                if file.endswith('.zip') or file.endswith('.tar.gz'):
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, base_dir)
                zipf.write(file_path, arcname)

    print(f"Archive created at {output_filename}, size: {os.path.getsize(output_filename)} bytes")

if __name__ == '__main__':
    create_archive()
