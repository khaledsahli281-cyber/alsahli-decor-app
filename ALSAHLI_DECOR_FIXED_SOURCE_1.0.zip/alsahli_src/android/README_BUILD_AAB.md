# دليل بناء وتصدير حزمة تطبيق أندرويد (AAB) لمتجر Google Play
## تطبيق: السهلي للديكور (com.alsahli.decor)

تم بناء وتحديث هذا التطبيق كـ **تطبيق أندرويد أصلي (100% Native Android)** وفق أحدث متطلبات Google Play:
- لغة: **Kotlin** (v1.9.24)
- واجهات المستخدم: **Jetpack Compose + Material 3**
- اسم الحزمة الثابت المعتمد: `com.alsahli.decor`
- الإصدار: `Version Code: 1` | `Version Name: "1.0.0"`
- المستهدف: `compileSdk = 36` | `targetSdk = 36` (متوافق مع Android 16 وأحدث شروط متجر Google Play لعام 2026)
- محرك البناء: Gradle 8.7 مع Android Gradle Plugin 8.5.2

---

### خطوة بخطوة: بناء حزمة AAB المعتمدة لـ Google Play عبر Android Studio

1. **فتح المشروع:**
   - افتح برنامج **Android Studio** (نسخة Iguana / Koala / Ladybug أو أحدث).
   - اختر **Open** ثم حدد مجلد `android` الموجود في هذا المشروع.
   - سيتعرف Android Studio تلقائياً على ملفات Gradle وCompose ويبدأ تحميل الحزم (Gradle Sync).

2. **بناء حزمة Android App Bundle (AAB):**
   - من القائمة العلوية في Android Studio، اضغط على:
     `Build` ➡️ `Generate Signed Bundle / APK...`
   - اختر **Android App Bundle** ثم اضغط **Next**.
   - اختر مفتاح التوقيع (Keystore) الخاص بك، أو اضغط **Create New** لإنشاء مفتاح جديد خاص بك.
   - اختر نمط البناء: **release**.
   - اضغط **Create**.

3. **الحصول على الملف النهائي:**
   - ستجد ملف الـ AAB الموقّع والجاهز للرفع في المسار التالي:
     `android/app/release/app-release.aab`
   - هذا هو الملف الرسمي المطلوب رفعه على لوحة تحكم **Google Play Console** في مسار الإنتاج (Production).

---

### بناء APK للتثبيت المباشر على الهاتف (Debug / Release APK):
إذا أردت تجربة التطبيق فوراً على هاتفك دون رفعه لجوجل بلاي:
- من القائمة: `Build` ➡️ `Build Bundle(s) / APK(s)` ➡️ `Build APK(s)`
- ستجد الملف في: `android/app/build/outputs/apk/debug/app-debug.apk`
- أرسل الملف لهاتفك وثبته فوراً.
