package com.alsahli.decor.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.alsahli.decor.data.DecorRepository
import com.alsahli.decor.ui.theme.*

@Composable
fun OwnerDashboardScreen(
    onExit: () -> Unit,
    onLogout: () -> Unit,
    onOpenImage: (String, String) -> Unit
) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf("leads") } // "leads", "settings"
    var orders by remember { mutableStateOf(DecorRepository.getAllOrders(context)) }

    var currentPinInput by remember { mutableStateOf("") }
    var newPinInput by remember { mutableStateOf("") }
    var pinMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .padding(16.dp),
        horizontalAlignment = Alignment.End
    ) {
        // Top Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Amber500)
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = onExit,
                        colors = ButtonDefaults.buttonColors(containerColor = Slate950),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("واجهة الزبون", color = Amber400, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    Button(
                        onClick = onLogout,
                        colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("قفل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "لوحة تحكم وإدارة المالك",
                        color = Slate950,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "متابعة طلبات الزبائن والأسعار والإعدادات",
                        color = Slate900,
                        fontSize = 10.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (activeTab == "leads") Amber500 else Slate900)
                    .border(1.dp, Slate800, RoundedCornerShape(12.dp))
                    .clickable { activeTab = "leads" }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "طلبات الزبائن (${orders.size})",
                    color = if (activeTab == "leads") Slate950 else Slate300,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (activeTab == "settings") Amber500 else Slate900)
                    .border(1.dp, Slate800, RoundedCornerShape(12.dp))
                    .clickable { activeTab = "settings" }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "إعدادات الأمان والـ PIN",
                    color = if (activeTab == "settings") Slate950 else Slate300,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (activeTab == "leads") {
            if (orders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد طلبات زبائن مسجلة حالياً",
                        color = Slate400,
                        fontSize = 13.sp
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    orders.forEach { ord ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(Slate900)
                                .border(1.dp, Slate800, RoundedCornerShape(18.dp))
                                .padding(14.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.End) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "#${ord.id}",
                                        color = Amber400,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = ord.createdAt,
                                        color = Slate400,
                                        fontSize = 10.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = "${ord.clientName} (${ord.phone})",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )

                                Text(
                                    text = "${ord.serviceTitle} • ${ord.city} • ${ord.areaEstimate}",
                                    color = Slate300,
                                    fontSize = 11.sp
                                )

                                if (ord.details.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "التفاصيل: ${ord.details}",
                                        color = Slate400,
                                        fontSize = 10.sp,
                                        textAlign = TextAlign.Right
                                    )
                                }

                                // Attached photos for owner review
                                if (ord.images.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "الصور المرفقة من الزبون (${ord.images.size} صور):",
                                        color = Amber300,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        ord.images.forEachIndexed { i, uri ->
                                            Box(
                                                modifier = Modifier
                                                    .size(65.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .border(1.dp, Slate700, RoundedCornerShape(8.dp))
                                                    .clickable { onOpenImage(uri, "صورة ${i + 1} لطلب #${ord.id}") }
                                            ) {
                                                AsyncImage(
                                                    model = uri,
                                                    contentDescription = "صورة الزبون",
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Fast Contact Actions
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                                data = Uri.parse("https://wa.me/${ord.phone.replace("+", "").replace(" ", "")}?text=" + Uri.encode("السلام عليكم أستاذ ${ord.clientName}، بخصوص طلبك للديكور رقم #${ord.id}"))
                                            }
                                            context.startActivity(intent)
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("واتساب", color = Slate950, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                                data = Uri.parse("tel:${ord.phone}")
                                            }
                                            context.startActivity(intent)
                                        },
                                        modifier = Modifier.weight(1f),
                                        border = BorderStroke(1.dp, Amber500),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("اتصال", color = Amber400, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // SETTINGS TAB
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.End
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Slate900)
                        .border(1.dp, Slate800, RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "تغيير رمز PIN السري للمالك",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = currentPinInput,
                            onValueChange = { currentPinInput = it },
                            label = { Text("رمز PIN الحالي", color = Slate400) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Amber500,
                                unfocusedBorderColor = Slate700,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newPinInput,
                            onValueChange = { newPinInput = it },
                            label = { Text("رمز PIN الجديد (4 أرقام أو أكثر)", color = Slate400) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Amber500,
                                unfocusedBorderColor = Slate700,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        if (pinMessage.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = pinMessage,
                                color = if (pinMessage.contains("✅")) Emerald400 else Rose400,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                if (!DecorRepository.verifyOwnerPin(context, currentPinInput)) {
                                    pinMessage = "الرمز الحالي غير صحيح!"
                                    return@Button
                                }
                                if (newPinInput.trim().length < 4) {
                                    pinMessage = "يجب أن يتكون الرمز الجديد من 4 خانات على الأقل"
                                    return@Button
                                }
                                val cleanNew = DecorRepository.normalizeDigits(newPinInput)
                                DecorRepository.setOwnerPin(context, cleanNew)
                                pinMessage = "✅ تم تعيين الرمز الجديد بنجاح ($cleanNew)"
                                currentPinInput = ""
                                newPinInput = ""
                                Toast.makeText(context, "تم حفظ رمز الأمان الجديد", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Amber500),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("حفظ رمز الأمان الجديد", color = Slate950, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "💡 ملاحظة أمان: الرمز الافتراضي يُستخدم عند أول تشغيل فقط، وبعد تغييره لا يبقى هناك رمز طوارئ ثابت.",
                            color = Slate400,
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
