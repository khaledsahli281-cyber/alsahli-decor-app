package com.alsahli.decor.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.alsahli.decor.data.DecorRepository
import com.alsahli.decor.ui.theme.*

@Composable
fun HomeScreen(
    onNavigateTab: (String) -> Unit,
    onOpenCalculator: () -> Unit,
    onOpenColors: () -> Unit,
    onOpenMyOrders: () -> Unit,
    onSelectService: (String) -> Unit,
    onOpenImage: (String, String) -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .verticalScroll(scrollState)
            .padding(bottom = 90.dp)
    ) {
        // Hero Section
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Slate900)
                .border(1.dp, Amber500.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                .padding(18.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.End
            ) {
                // Top Tag
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Amber500.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "الريادة في الإتقان السوري",
                        color = Amber400,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = Amber400,
                        modifier = Modifier.size(13.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "حوّل منزلك أو منشأتك إلى تحفة فنية فاخرة",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 19.sp,
                    lineHeight = 27.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "تنفيذ هندسي عالي الدقة للدهانات الإيطالية والحديثة، ديكورات الجبس بورد المتطورة، والترميم المتكامل في دمشق وكافة المحافظات السورية.",
                    color = Slate300,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onNavigateTab("quote") },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Amber500),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "طلب عرض سعر مجاني",
                            color = Slate950,
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }

                    OutlinedButton(
                        onClick = { onNavigateTab("services") },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        border = BorderStroke(1.dp, Slate700),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "استعراض الخدمات",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Quick Feature Cards (Calculator, Colors, My Orders)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Calculator
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Slate900)
                    .border(1.dp, Slate800, RoundedCornerShape(16.dp))
                    .clickable { onOpenCalculator() }
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Calculate,
                        contentDescription = "حاسبة التكلفة",
                        tint = Amber400,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "حاسبة التكلفة",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "تقدير فوري (ل.س)",
                        color = Slate400,
                        fontSize = 9.sp
                    )
                }
            }

            // Color Palette
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Slate900)
                    .border(1.dp, Slate800, RoundedCornerShape(16.dp))
                    .clickable { onOpenColors() }
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Palette,
                        contentDescription = "كتالوج الألوان",
                        tint = Emerald400,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "كتالوج الألوان",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "ألوان ملكية 2026",
                        color = Slate400,
                        fontSize = 9.sp
                    )
                }
            }

            // My Private Orders
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Slate900)
                    .border(1.dp, Slate800, RoundedCornerShape(16.dp))
                    .clickable { onOpenMyOrders() }
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FolderShared,
                        contentDescription = "طلباتي وصوري",
                        tint = Sky400,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "سجل طلباتي",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "صورك وبياناتك الخاصة",
                        color = Slate400,
                        fontSize = 9.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Before & After Featured Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { onNavigateTab("gallery") }) {
                    Text(
                        text = "عرض الكل",
                        color = Amber400,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "نماذج من أعمالنا (قبل وبعد)",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )
            }

            val featuredProj = DecorRepository.BEFORE_AFTER_PROJECTS.first()
            var showAfter by remember { mutableStateOf(true) }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Slate900)
                    .border(1.dp, Slate800, RoundedCornerShape(20.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                val img = if (showAfter) featuredProj.afterImage else featuredProj.beforeImage
                                onOpenImage(img, featuredProj.title)
                            }
                    ) {
                        AsyncImage(
                            model = if (showAfter) featuredProj.afterImage else featuredProj.beforeImage,
                            contentDescription = featuredProj.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Toggle Badge
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Slate950.copy(alpha = 0.85f))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "قبل التنفيذ",
                                color = if (!showAfter) Amber400 else Slate400,
                                fontWeight = if (!showAfter) FontWeight.Black else FontWeight.Normal,
                                fontSize = 10.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (!showAfter) Amber500.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { showAfter = false }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                            Text(
                                text = "بعد التنفيذ الفاخر",
                                color = if (showAfter) Emerald400 else Slate400,
                                fontWeight = if (showAfter) FontWeight.Black else FontWeight.Normal,
                                fontSize = 10.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (showAfter) Emerald500.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { showAfter = true }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = featuredProj.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    Text(
                        text = featuredProj.description,
                        color = Slate400,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Direct Call Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Emerald500.copy(alpha = 0.12f))
                .border(1.dp, Emerald500.copy(alpha = 0.3f), RoundedCornerShape(18.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            data = Uri.parse("https://wa.me/${DecorRepository.WHATSAPP_NUMBER}?text=" + Uri.encode("السلام عليكم، أود حجز موعد معاينة مجانية لمنزلي"))
                        }
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "واتساب مباشر",
                        color = Slate950,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "معاينة هندسية مجانية 100%",
                        color = Emerald400,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "نصل لموقعك ونرفع المقاسات بدقة بدون التزام",
                        color = Slate300,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
