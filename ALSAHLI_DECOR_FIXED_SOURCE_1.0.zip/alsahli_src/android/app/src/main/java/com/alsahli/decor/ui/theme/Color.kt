package com.alsahli.decor.ui.theme

import androidx.compose.ui.graphics.Color

val Amber500 = Color(0xFFF59E0B)
val Amber400 = Color(0xFFFBBF24)
val Amber600 = Color(0xFFD97706)
val AmberGold = Color(0xFFFFC107)

val Slate950 = Color(0xFF020617)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate100 = Color(0xFFF1F5F9)

val Emerald500 = Color(0xFF10B981)
val Emerald400 = Color(0xFF34D399)
val Emerald600 = Color(0xFF059669)

val Rose500 = Color(0xFFF43F5E)
val Rose400 = Color(0xFFFB7185)
val Sky400 = Color(0xFF38BDF8)
