package com.alsahli.decor.model

data class DecorService(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val priceUnit: String,
    val estimatedPriceSyp: Long,
    val iconName: String,
    val badge: String,
    val features: List<String>,
    val executionTime: String,
    val warranty: String
)

data class BeforeAfterProject(
    val id: String,
    val title: String,
    val category: String, // "دهانات داخلية", "جبس بورد", "ديكورات واجهات", "ورق جدران"
    val location: String,
    val area: String,
    val description: String,
    val beforeImage: String,
    val afterImage: String,
    val details: List<String>
)

data class QuoteRequest(
    val id: String,
    val createdAt: String,
    val clientName: String,
    val phone: String,
    val city: String,
    val serviceId: String,
    val serviceTitle: String,
    val propertyType: String,
    val areaEstimate: String,
    val details: String,
    val images: List<String> = emptyList(),
    val status: String = "new" // "new", "in_progress", "done"
)

data class ColorPaletteItem(
    val name: String,
    val code: String,
    val hexColor: Long,
    val finish: String,
    val category: String,
    val bestFor: String
)

data class GovernoratePricing(
    val name: String,
    val visitCost: String,
    val transportSurcharge: String,
    val isMainBase: Boolean = false
)
