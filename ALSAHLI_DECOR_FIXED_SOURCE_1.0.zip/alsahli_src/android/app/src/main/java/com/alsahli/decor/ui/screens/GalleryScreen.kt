package com.alsahli.decor.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.alsahli.decor.data.DecorRepository
import com.alsahli.decor.ui.theme.*

@Composable
fun GalleryScreen(
    onOpenImage: (String, String) -> Unit,
    onSelectServiceForQuote: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    var selectedCategory by remember { mutableStateOf("الكل") }

    val categories = listOf("الكل", "دهانات داخلية", "جبس بورد", "ديكورات واجهات", "ورق جدران")

    val filteredProjects = remember(selectedCategory) {
        if (selectedCategory == "الكل") {
            DecorRepository.BEFORE_AFTER_PROJECTS
        } else {
            DecorRepository.BEFORE_AFTER_PROJECTS.filter { it.category == selectedCategory }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 90.dp),
        horizontalAlignment = Alignment.End
    ) {
        Text(
            text = "معرض الأعمال ومقارنة قبل وبعد",
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 18.sp
        )

        Text(
            text = "شاهد الفرق الحقيقي الذي نصنعه في المساحات السكنية والتجارية قبل وبعد استلام العمل.",
            color = Slate400,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Categories Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { cat ->
                val active = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (active) Amber500 else Slate900)
                        .border(1.dp, if (active) Amber500 else Slate800, RoundedCornerShape(10.dp))
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = cat,
                        color = if (active) Slate950 else Slate300,
                        fontWeight = if (active) FontWeight.Black else FontWeight.Normal,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Projects Cards
        filteredProjects.forEach { proj ->
            var isShowingAfter by remember { mutableStateOf(true) }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Slate900)
                    .border(1.dp, Slate800, RoundedCornerShape(22.dp))
                    .padding(14.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    // Photo Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable {
                                val current = if (isShowingAfter) proj.afterImage else proj.beforeImage
                                onOpenImage(current, proj.title)
                            }
                    ) {
                        AsyncImage(
                            model = if (isShowingAfter) proj.afterImage else proj.beforeImage,
                            contentDescription = proj.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Mode switcher
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Slate950.copy(alpha = 0.85f))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "قبل التنفيذ",
                                color = if (!isShowingAfter) Amber400 else Slate400,
                                fontWeight = if (!isShowingAfter) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 10.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (!isShowingAfter) Amber500.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { isShowingAfter = false }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                            Text(
                                text = "بعد التنفيذ",
                                color = if (isShowingAfter) Emerald400 else Slate400,
                                fontWeight = if (isShowingAfter) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 10.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isShowingAfter) Emerald500.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { isShowingAfter = true }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = proj.title,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )

                    Text(
                        text = "${proj.location} • ${proj.area}",
                        color = Amber300,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = proj.description,
                        color = Slate300,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}
