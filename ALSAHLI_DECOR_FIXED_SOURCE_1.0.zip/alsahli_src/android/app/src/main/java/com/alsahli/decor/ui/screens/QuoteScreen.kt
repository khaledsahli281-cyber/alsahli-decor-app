package com.alsahli.decor.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.alsahli.decor.data.DecorRepository
import com.alsahli.decor.model.QuoteRequest
import com.alsahli.decor.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuoteScreen(
    initialServiceId: String? = null,
    onOpenImage: (String, String) -> Unit,
    onOrderSubmittedSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var clientName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("دمشق") }
    var district by remember { mutableStateOf("") }
    var serviceId by remember { mutableStateOf(initialServiceId ?: DecorRepository.SERVICES.first().id) }
    var propertyType by remember { mutableStateOf("شقة سكنية") }
    var areaEstimate by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    val attachedImages = remember { mutableStateListOf<String>() }

    var submittedOrder by remember { mutableStateOf<QuoteRequest?>(null) }
    var errorMessage by remember { mutableStateOf("") }

    // Multi-Image Picker from Android Gallery
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        uris.forEach { uri ->
            val uriStr = uri.toString()
            if (!attachedImages.contains(uriStr)) {
                attachedImages.add(uriStr)
            }
        }
    }

    val selectedService = DecorRepository.SERVICES.find { it.id == serviceId } ?: DecorRepository.SERVICES.first()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 90.dp),
        horizontalAlignment = Alignment.End
    ) {
        if (submittedOrder != null) {
            val order = submittedOrder!!
            // SUCCESS CONFIRMATION SCREEN WITH PHOTO GALLERY
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Slate900)
                    .border(1.dp, Emerald500.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Emerald500.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "تم بنجاح",
                            tint = Emerald400,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "تم تسجيل طلبك وحفظ صورك بنجاح!",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 17.sp,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "رقم الطلب الخاص بك: #${order.id}",
                        color = Amber400,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Attached Images Preview in Confirmation
                    if (order.images.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Slate950)
                                .border(1.dp, Slate800, RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = "الصور المحفوظة بالطلب (${order.images.size} صور):",
                                color = Amber400,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "انقر على أي صورة لمشاهدتها وتكبيرها بملء الشاشة",
                                color = Slate400,
                                fontSize = 10.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                order.images.forEachIndexed { idx, imgUri ->
                                    Box(
                                        modifier = Modifier
                                            .size(80.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .border(1.dp, Slate700, RoundedCornerShape(12.dp))
                                            .clickable {
                                                onOpenImage(imgUri, "صورة ${idx + 1} - طلب #${order.id}")
                                            }
                                    ) {
                                        AsyncImage(
                                            model = imgUri,
                                            contentDescription = "صورة مرفقة",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(4.dp)
                                                .size(20.dp)
                                                .clip(CircleShape)
                                                .background(Slate950.copy(alpha = 0.7f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Visibility,
                                                contentDescription = "معاينة",
                                                tint = Color.White,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                    }

                    // Open WhatsApp Action
                    Button(
                        onClick = {
                            val waMsg = buildWhatsAppMessage(order)
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                data = Uri.parse("https://wa.me/${DecorRepository.WHATSAPP_NUMBER}?text=" + Uri.encode(waMsg))
                            }
                            context.startActivity(intent)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = null,
                            tint = Slate950,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "فتح محادثة واتساب لإتمام المعاينة",
                            color = Slate950,
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            submittedOrder = null
                            attachedImages.clear()
                            details = ""
                            areaEstimate = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, Slate700),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            text = "تقديم طلب عرض سعر جديد",
                            color = Slate300,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        } else {
            // MAIN INPUT FORM
            Text(
                text = "طلب عرض سعر ومعاينة مجانية",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 18.sp
            )

            Text(
                text = "أدخل بياناتك وسنقوم بدراسة طلبك وتحديد موعد معاينة ميدانية مجانية بدون أي التزام.",
                color = Slate400,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                textAlign = TextAlign.Right
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Form Fields
            OutlinedTextField(
                value = clientName,
                onValueChange = { clientName = it; errorMessage = "" },
                label = { Text("الاسم الكريم *", color = Slate400) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Amber500,
                    unfocusedBorderColor = Slate700,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it; errorMessage = "" },
                label = { Text("رقم الجوال / الواتساب *", color = Slate400) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Amber500,
                    unfocusedBorderColor = Slate700,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = district,
                    onValueChange = { district = it },
                    label = { Text("الحي / المنطقة", color = Slate400) },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Amber500,
                        unfocusedBorderColor = Slate700,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("المحافظة", color = Slate400) },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Amber500,
                        unfocusedBorderColor = Slate700,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = areaEstimate,
                onValueChange = { areaEstimate = it },
                label = { Text("المساحة التقريبية (متر مربع)", color = Slate400) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Amber500,
                    unfocusedBorderColor = Slate700,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = details,
                onValueChange = { details = it; errorMessage = "" },
                label = { Text("تفاصيل ما ترغب بتنفيذه *", color = Slate400) },
                minLines = 3,
                maxLines = 5,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Amber500,
                    unfocusedBorderColor = Slate700,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Photo Attachment Section (NATIVE ANDROID MULTI-PICKER)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Slate900)
                    .border(1.dp, Slate800, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = Amber500.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = "إضافة صور",
                                tint = Amber400,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "اختيار صور من الهاتف",
                                color = Amber400,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        Text(
                            text = "صور الموقع والمخطط (${attachedImages.size})",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    if (attachedImages.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            attachedImages.forEachIndexed { index, imgUri ->
                                Box(
                                    modifier = Modifier
                                        .size(80.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(1.dp, Amber500.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                ) {
                                    AsyncImage(
                                        model = imgUri,
                                        contentDescription = "صورة مرفقة",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clickable {
                                                onOpenImage(imgUri, "صورة مرفقة ${index + 1}")
                                            }
                                    )

                                    // Delete button
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(3.dp)
                                            .size(22.dp)
                                            .clip(CircleShape)
                                            .background(Rose500)
                                            .clickable { attachedImages.removeAt(index) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "حذف",
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "يمكنك إرفاق صور للجدران أو الأسقف أو صور أفكار ترغب بتنفيذها لحفظها بالطلب.",
                            color = Slate400,
                            fontSize = 10.sp,
                            textAlign = TextAlign.Right
                        )
                    }
                }
            }

            if (errorMessage.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = errorMessage,
                    color = Rose400,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Submit Buttons
            Button(
                onClick = {
                    if (clientName.isBlank()) {
                        errorMessage = "يرجى كتابة الاسم الكريم"
                        return@Button
                    }
                    if (phone.isBlank() || phone.length < 8) {
                        errorMessage = "يرجى كتابة رقم جوال صحيح"
                        return@Button
                    }
                    if (details.isBlank()) {
                        errorMessage = "يرجى توضيح تفاصيل العمل المطلوب"
                        return@Button
                    }

                    val dateStr = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("ar")).format(Date())
                    val orderId = "SAHLI-${(1000..9999).random()}"

                    val newOrder = QuoteRequest(
                        id = orderId,
                        createdAt = dateStr,
                        clientName = clientName,
                        phone = phone,
                        city = "$city - $district",
                        serviceId = selectedService.id,
                        serviceTitle = selectedService.title,
                        propertyType = propertyType,
                        areaEstimate = if (areaEstimate.isNotBlank()) "$areaEstimate م²" else "معاينة بالوقع",
                        details = details,
                        images = attachedImages.toList(),
                        status = "new"
                    )

                    // Save strictly to user's private orders
                    DecorRepository.saveUserOrder(context, newOrder)
                    submittedOrder = newOrder
                    onOrderSubmittedSuccess()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Amber500),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = "إرسال وحفظ الطلب والصور",
                    color = Slate950,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
            }
        }
    }
}

private fun buildWhatsAppMessage(order: QuoteRequest): String {
    return """
        *طلب عرض سعر جديد - السهلي للديكور*
        *رقم الطلب:* #${order.id}
        --------------------------
        👤 *الاسم:* ${order.clientName}
        📱 *الجوال:* ${order.phone}
        📍 *الموقع:* ${order.city}
        🎨 *الخدمة:* ${order.serviceTitle}
        📐 *المساحة:* ${order.areaEstimate}
        📝 *تفاصيل العمل:*
        ${order.details}
        📸 *الصور المرفقة:* تم حفظ (${order.images.size}) صور في تفاصيل الطلب داخل التطبيق وسأرسلها هنا أيضاً.
        --------------------------
        يرجى إفادتي بالسعر وتحديد موعد المعاينة المجانية وشكراً.
    """.trimIndent()
}
