package com.alsahli.decor.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alsahli.decor.data.DecorRepository
import com.alsahli.decor.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun ServicesScreen(
    onSelectServiceForQuote: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    val formatter = NumberFormat.getNumberInstance(Locale.US)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 90.dp),
        horizontalAlignment = Alignment.End
    ) {
        Text(
            text = "خدمات الدهان والديكور والتشطيب",
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 18.sp
        )

        Text(
            text = "نقدم خدمات متكاملة بأعلى معايير الحرفية السورية والضمان الكتابي مع أسعار مدروسة وشفافة.",
            color = Slate400,
            fontSize = 11.sp,
            lineHeight = 16.sp,
            textAlign = TextAlign.Right
        )

        Spacer(modifier = Modifier.height(16.dp))

        DecorRepository.SERVICES.forEach { service ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Slate900)
                    .border(1.dp, Slate800, RoundedCornerShape(22.dp))
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.End
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Amber500.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = service.badge,
                                color = Amber400,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        }

                        Text(
                            text = service.title,
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = service.subtitle,
                        color = Amber300,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = service.description,
                        color = Slate300,
                        fontSize = 11.sp,
                        lineHeight = 17.sp,
                        textAlign = TextAlign.Right
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Features
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Slate950)
                            .padding(10.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        service.features.forEach { feature ->
                            Row(
                                modifier = Modifier.padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = feature,
                                    color = Slate300,
                                    fontSize = 10.sp
                                )
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Emerald400,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Price & Action
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { onSelectServiceForQuote(service.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = Amber500),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "طلب عرض سعر",
                                color = Slate950,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Row(
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(
                                    text = "ل.س",
                                    color = Slate400,
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = formatter.format(service.estimatedPriceSyp),
                                    color = Amber400,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "يبدأ من",
                                    color = Slate400,
                                    fontSize = 10.sp
                                )
                            }
                            Text(
                                text = service.priceUnit,
                                color = Slate500,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
