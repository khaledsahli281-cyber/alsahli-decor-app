package com.alsahli.decor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alsahli.decor.ui.theme.*

data class NavItem(
    val id: String,
    val title: String,
    val icon: ImageVector
)

@Composable
fun AppBottomNav(
    activeTab: String,
    onTabSelected: (String) -> Unit
) {
    val items = listOf(
        NavItem("home", "الرئيسية", Icons.Default.Home),
        NavItem("services", "الخدمات", Icons.Default.FormatPaint),
        NavItem("gallery", "المعرض", Icons.Default.PhotoLibrary),
        NavItem("quote", "عرض سعر", Icons.Default.Description),
        NavItem("contact", "تواصل معنا", Icons.Default.Phone)
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Slate950)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Slate900)
                .border(1.dp, Slate800, RoundedCornerShape(20.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { item ->
                val selected = activeTab == item.id
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (selected) Amber500 else Slate900)
                        .clickable { onTabSelected(item.id) }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title,
                        tint = if (selected) Slate950 else Slate400,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = item.title,
                        color = if (selected) Slate950 else Slate400,
                        fontWeight = if (selected) FontWeight.Black else FontWeight.Normal,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
