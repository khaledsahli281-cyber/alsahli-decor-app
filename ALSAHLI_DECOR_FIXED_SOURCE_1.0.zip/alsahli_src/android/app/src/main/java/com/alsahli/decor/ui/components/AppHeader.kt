package com.alsahli.decor.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alsahli.decor.data.DecorRepository
import com.alsahli.decor.ui.theme.*

@Composable
fun AppHeader(
    isOwnerLoggedIn: Boolean,
    ordersCount: Int,
    onOpenOwnerDashboard: () -> Unit,
    onOpenOwnerLogin: () -> Unit,
    onOpenOrders: () -> Unit
) {
    val context = LocalContext.current
    var vipTapCount by remember { mutableStateOf(0) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Slate950)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Logo & Title
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Amber500.copy(alpha = 0.15f))
                    .border(1.dp, Amber500.copy(alpha = 0.3f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.FormatPaint,
                    contentDescription = "شعار السهلي للديكور",
                    tint = Amber400,
                    modifier = Modifier.size(22.dp)
                )
            }

            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = DecorRepository.COMPANY_NAME,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    )

                    // Secret triple-tap VIP badge to open Owner PIN dialog
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Amber500.copy(alpha = 0.2f))
                            .border(0.8.dp, Amber500.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .clickable {
                                vipTapCount++
                                if (vipTapCount >= 3) {
                                    vipTapCount = 0
                                    onOpenOwnerLogin()
                                }
                            }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "VIP",
                            color = Amber300,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }

                Text(
                    text = "دهانات • ديكور • تشطيب راقي معتمد",
                    color = Slate400,
                    fontSize = 10.sp
                )
            }
        }

        // Action Buttons
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Owner shortcut if logged in
            if (isOwnerLoggedIn) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Amber500)
                        .clickable { onOpenOwnerDashboard() }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "المالك",
                        color = Slate950,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp
                    )
                }
            }

            // Share App
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Sky400.copy(alpha = 0.15f))
                    .border(1.dp, Sky400.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                    .clickable {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "تطبيق «السهلي للديكور» - خدمات الدهانات والجبس بورد وأعمال الترميم والمعاينة المجانية في سوريا:\nhttps://ais-pre-37nwxmk65pwm3u55obcebd-711257153436.us-west2.run.app"
                            )
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة التطبيق"))
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "مشاركة التطبيق",
                    tint = Sky400,
                    modifier = Modifier.size(17.dp)
                )
            }

            // WhatsApp Quick
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Emerald500.copy(alpha = 0.15f))
                    .border(1.dp, Emerald500.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                    .clickable {
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            data = Uri.parse("https://wa.me/${DecorRepository.WHATSAPP_NUMBER}?text=" + Uri.encode("السلام عليكم، أود الاستفسار عن خدمات الدهان والديكور لدى السهلي للديكور"))
                        }
                        context.startActivity(intent)
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Chat,
                    contentDescription = "محادثة واتساب",
                    tint = Emerald400,
                    modifier = Modifier.size(17.dp)
                )
            }

            // Phone Quick
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Amber500.copy(alpha = 0.15f))
                    .border(1.dp, Amber500.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                    .clickable {
                        val intent = Intent(Intent.ACTION_DIAL).apply {
                            data = Uri.parse("tel:${DecorRepository.PHONE_NUMBER}")
                        }
                        context.startActivity(intent)
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = "اتصال هاتفي",
                    tint = Amber400,
                    modifier = Modifier.size(17.dp)
                )
            }
        }
    }
}

val Amber300 = Color(0xFFFCD34D)
