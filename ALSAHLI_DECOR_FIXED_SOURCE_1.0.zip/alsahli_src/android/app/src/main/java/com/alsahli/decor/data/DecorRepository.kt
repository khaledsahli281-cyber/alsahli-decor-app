package com.alsahli.decor.data

import android.content.Context
import android.content.SharedPreferences
import com.alsahli.decor.model.*
import org.json.JSONArray
import org.json.JSONObject

object DecorRepository {
    const val COMPANY_NAME = "السهلي للديكور"
    const val OWNER_TITLE = "م/ خالد السهلي - استشارات وتنفيذ ديكور"
    const val PHONE_NUMBER = "+963951528628"
    const val WHATSAPP_NUMBER = "963951528628"
    const val EMAIL = "khaledsahli281@gmail.com"
    const val ADDRESS = "سوريا - دمشق وريفها (مع إمكانية التنفيذ في حمص، حماة، واللاذقية)"
    const val WORKING_HOURS = "يومياً من الساعة 8:00 صباحاً حتى 9:00 مساءً"
    const val DEFAULT_PIN = "2026"

    val SERVICES = listOf(
        DecorService(
            id = "interior-paint",
            title = "دهانات داخلية فاخرة",
            subtitle = "ألوان مطفية، حريرية، وديكورية راقية",
            description = "تنفيذ أرقى الدهانات الداخلية السكنية والتجارية مع معالجة الرطوبة والتشققات، تأسيس معجون متعدد الطبقات، ودهان بماركات إيطالية ومحلية نخب أول.",
            priceUnit = "للمتر المربع مع المواد",
            estimatedPriceSyp = 45000,
            iconName = "brush",
            badge = "الأكثر طلباً",
            features = listOf(
                "صنفرة ميكانيكية متطورة بدون غبار",
                "عزل مائي ومعالجة الرطوبة بجهاز كشف حديث",
                "ألوان كمبيوتر متدرجة بأحدث الكتالوجات العالمية",
                "ضمان 5 سنوات على ثبات الألوان وعدم التقشير"
            ),
            executionTime = "3 - 7 أيام للشقة المتوسطة",
            warranty = "5 سنوات ضمان كتابي"
        ),
        DecorService(
            id = "gypsum-board",
            title = "جبس بورد وأسقف مستعارة",
            subtitle = "إضاءة مخفية، سبوتات، وتصاميم مودرن وكلاسيك",
            description = "تصميم وتنفيذ أحدث ديكورات الجبس بورد للأسقف والجدران وشاشات التلفزيون (TV Unit) بألواح مقاومة للرطوبة والحريق مع شاسيهات حديد ثقيل معتمد.",
            priceUnit = "للمتر المربع شامل الشاسيه والتركيب",
            estimatedPriceSyp = 95000,
            iconName = "layers",
            badge = "تصاميم 2026",
            features = listOf(
                "ألواح جبس خضراء مقاومة للرطوبة للمطابخ والحمامات",
                "تأسيس مجاري الليد بروفايل والسبوت لايت بدقة ملليمترية",
                "تسليح حديد أوميغا وزوايا سماكة أصلية لمنع الهبوط",
                "معجون مفاصل فرنسي أصلي مع شاش فايبر ضد التشققات"
            ),
            executionTime = "4 - 10 أيام حسب المساحة",
            warranty = "10 سنوات ضمان عدم هبوط"
        ),
        DecorService(
            id = "exterior-facades",
            title = "دهانات وواجهات خارجية",
            subtitle = "مقاومة للعوامل الجوية، ترافرتينو، ورخام صناعي",
            description = "حماية وتجميل واجهات الفلل والأبنية بأقوى مواد العزل والدهان الخارجي، بروفايل، مونوكوش، غرانيت سائل، وتعتيق حجري مقاوم للشمس والأمطار.",
            priceUnit = "للمتر المربع مع السقالات والمواد",
            estimatedPriceSyp = 65000,
            iconName = "home",
            badge = "مقاوم للشمس والمطر",
            features = listOf(
                "غسيل ضغط عالي للواجهات وتفريغ الشقوق العميقة",
                "طبقات سيلر مائي ومطاطي عازل للأمطار والحرارة",
                "دهان أكريليكي صلب لا يتأثر بأشعة الشمس فوق البنفسجية",
                "توفير سقالات معدنية وفريق عمل مدرّب على الأبراج والفلل"
            ),
            executionTime = "7 - 20 يوماً حسب ارتفاع المبنى",
            warranty = "7 سنوات ضد التشقق والبهتان"
        ),
        DecorService(
            id = "wallpaper-3d",
            title = "ورق جدران وفوم وبديل رخام",
            subtitle = "أحدث الموديلات الكورية والأوروبية والبدائل العصرية",
            description = "توريد وتركيب أحدث تصاميم ورق الجدران ثلاثي الأبعاد، بديل الرخام (PVC Marble)، بديل الخشب (WPC Louvers)، وبانوهات الفوم الكلاسيكية الفاخرة.",
            priceUnit = "للرول أو اللوح شامل المواد والتركيب",
            estimatedPriceSyp = 140000,
            iconName = "palette",
            badge = "فخامة فورية",
            features = listOf(
                "غراء إيطالي أصلي بدون رائحة ومقاوم للعفن",
                "مطابقة رسومات دقيقة بدون ظهور أي فواصل بين الرولات",
                "بديل خشب ورخام مقاوم للماء والخدش وسهل التنظيف",
                "تركيب سريع ونظيف خلال يوم واحد للغرفة"
            ),
            executionTime = "1 - 3 أيام",
            warranty = "3 سنوات على الالتصاق والمظهر"
        ),
        DecorService(
            id = "restoration-prep",
            title = "ترميم وصيانة شاملة للشقق",
            subtitle = "إعادة الشقق القديمة إلى حالة الفخامة الكاملة",
            description = "أعمال التجديد المتكاملة: تكسير وإعادة تلييس، عزل كامل للأسطح والحمامات، تغيير سيراميك، وصيانة دهانات كاملة لتسليم الشقة على المفتاح.",
            priceUnit = "تسعير مقطوع بعد المعاينة الميدانية",
            estimatedPriceSyp = 3500000,
            iconName = "sparkles",
            badge = "على المفتاح",
            features = listOf(
                "معاينة هندسية وكشف مجاني قبل البدء",
                "جدول زمني صارم للتسليم مع بند جزائي عن كل يوم تأخير",
                "فريق متكامل (كهربائي، سباك، معلم دهان، جباصين)",
                "تنظيف شامل وتسليم الشقة معطرة وجاهزة للسكن فوراً"
            ),
            executionTime = "15 - 30 يوماً للشقة الكاملة",
            warranty = "ضمان شامل لمدة سنتين"
        ),
        DecorService(
            id = "thermal-water-insulation",
            title = "عزل مائي وحراري للأسطح",
            subtitle = "رول زفتي، بولي يوريثان، ومطاط إيبوكسي",
            description = "حلول نهائية وجذرية لتسريب مياه الأمطار والرطوبة وحرارة الصيف القاسية باستخدام أفضل المواد العازلة المعتمدة مع تجربة الإغراق المائي للتأكد.",
            priceUnit = "للمتر المربع مع الاختبار المائي",
            estimatedPriceSyp = 55000,
            iconName = "shield",
            badge = "حل جذري للرطوبة",
            features = listOf(
                "عزل إيبوكسي ومطاطي مرن لا يتشقق مع تمدد الباطون",
                "طبقات حماية حجرية فوق العازل لضمان عدم تلفه",
                "فحص مائي لمدة 48 ساعة قبل التسليم للتأكد من صفر تسريب",
                "تخفيض فاتورة التكييف والتدفئة بنسبة تصل إلى 35%"
            ),
            executionTime = "2 - 5 أيام",
            warranty = "10 سنوات ضمان عدم تسريب"
        )
    )

    val BEFORE_AFTER_PROJECTS = listOf(
        BeforeAfterProject(
            id = "proj-1",
            title = "تجديد صالون فيلا فاخرة (مالكي - دمشق)",
            category = "دهانات داخلية",
            location = "دمشق - المالكي",
            area = "85 متر مربع",
            description = "تحويل صالون قديم متصدع الجدران إلى تحفة كلاسيكية راقية مع تأسيس معجون إيطالي ودهان لؤلؤي بيج وإطارات فوم ملكية.",
            beforeImage = "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80",
            afterImage = "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=800&q=80",
            details = listOf("معالجة رطوبة بأساس إيبوكسي", "معجون 3 طبقات وصنفرة ليزرية", "دهان سوبر فيلفت حريري", "إطارات بانوهات فوم دقيقة")
        ),
        BeforeAfterProject(
            id = "proj-2",
            title = "سقف جبس بورد مع ليد بروفايل (مشروع دمر)",
            category = "جبس بورد",
            location = "دمشق - مشروع دمر الجزيرة 16",
            area = "60 متر مربع",
            description = "تصميم مودرن انسيابي مع دمج إضاءة الليد بروفايل المخفية ومسارات الماجنتيك لايت مع فتحات تكييف مخفية بدون أي تشوه بصري.",
            beforeImage = "https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=800&q=80",
            afterImage = "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&q=80",
            details = listOf("جبس بورد كناوف أخضر 12.5 مم", "شاسيه حديد C & U سماكة 0.6", "إنارة ليد دافئة 3000K", "معجون فواصل فايبر جلاس")
        ),
        BeforeAfterProject(
            id = "proj-3",
            title = "تجديد واجهة فيلا حديثة (يعفور)",
            category = "ديكورات واجهات",
            location = "ريف دمشق - يعفور",
            area = "320 متر مربع",
            description = "إعادة تشطيب واجهة فيلا بتطبيق مونوكوش ترافرتينو إيطالي مقاوم للأشعة فوق البنفسجية ومياه الشتاء مع إضاءة جدارية ليلية ساحرة.",
            beforeImage = "https://images.unsplash.com/photo-1590381105924-c72589b9ef3f?auto=format&fit=crop&w=800&q=80",
            afterImage = "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80",
            details = listOf("غسيل كيميائي للواجهة", "سيلر عازل للمياه", "ترافرتينو مقاوم للشمس 7 سنوات", "إضاءة ليلية ضد الماء IP67")
        ),
        BeforeAfterProject(
            id = "proj-4",
            title = "ديكور جدار تلفزيون بديل رخام وخشب (المزة)",
            category = "ورق جدران",
            location = "دمشق - المزة فيلات غربية",
            area = "18 متر مربع",
            description = "تركيب لوح بديل رخام إسباني لامع مع شرائح بديل خشب رمادي داكن وإضاءة ليد شريطية ومخارج كابلات مخفية تماماً.",
            beforeImage = "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80",
            afterImage = "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80",
            details = listOf("بديل رخام سماكة 3 مم ضد الخدش", "بديل خشب فحم كوري", "إخفاء أسلاك التلفاز والرسيفر", "تنفيذ في يوم عمل واحد فقط")
        )
    )

    val COLOR_PALETTES = listOf(
        ColorPaletteItem("أوف وايت ملكي (Royal Off-White)", "SL-101", 0xFFFBFBF8, "حريري ناعم", "ألوان أساسية", "صالات ومجالس وممرات"),
        ColorPaletteItem("بيج دمشقي دافئ (Warm Beige)", "SL-102", 0xFFF5EBE1, "نصف لمعة", "كلاسيكي هادئ", "غرف نوم ومعيشة عائلية"),
        ColorPaletteItem("رمادي لؤلؤي عصري (Pearl Grey)", "SL-103", 0xFFE2E4E6, "مطفأ مات", "مودرن راقي", "صالات عصرية ومكاتب عمل"),
        ColorPaletteItem("عاجي كريمي فخم (Cream Ivory)", "SL-104", 0xFFFFFDD0, "حريري فاخر", "كلاسيكي", "صالونات الضيافة مع الجبس الذهبي"),
        ColorPaletteItem("كشمير هادئ (Soft Cashmere)", "SL-105", 0xFFDFD7CF, "مات مخملي", "غرف استرخاء", "غرف النوم الرئيسية"),
        ColorPaletteItem("بترولي ملكي مميز (Royal Petrol)", "SL-106", 0xFF1D3557, "مات ديكوري", "جدار مميز (Accent)", "جدار خلفية السرير أو التلفاز")
    )

    val GOVERNORATES = listOf(
        GovernoratePricing("دمشق (كافة الأحياء)", "مجانية 100%", "بدون أجور انتقال", isMainBase = true),
        GovernoratePricing("ريف دمشق (صحنايا، جرمانا، قدسيا، يعفور، قطنا، النبك)", "مجانية عند الاتفاق", "رمزية للمواقع البعيدة", isMainBase = true),
        GovernoratePricing("حمص والمنطقة الوسطى", "تنسيق مسبق", "تضاف حسب حجم المشروع", isMainBase = false),
        GovernoratePricing("اللاذقية وطرطوس والساحل", "تنسيق مسبق", "تضاف للمشاريع الكبيرة والفلل", isMainBase = false)
    )

    // Local Persistence for User's Private Orders & Owner Settings
    private const val PREFS_NAME = "alsahli_decor_prefs"
    private const val KEY_MY_ORDERS = "my_private_orders_v2"
    private const val KEY_ALL_ORDERS = "all_orders_cache_v2"
    private const val KEY_OWNER_PIN = "owner_pin_code"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // Save user's private order strictly on their device
    fun saveUserOrder(context: Context, order: QuoteRequest) {
        val prefs = getPrefs(context)
        val list = getUserOrders(context).toMutableList()
        list.removeAll { it.id == order.id }
        list.add(0, order)

        val jsonArr = JSONArray()
        list.forEach { ord ->
            val obj = JSONObject()
            obj.put("id", ord.id)
            obj.put("createdAt", ord.createdAt)
            obj.put("clientName", ord.clientName)
            obj.put("phone", ord.phone)
            obj.put("city", ord.city)
            obj.put("serviceId", ord.serviceId)
            obj.put("serviceTitle", ord.serviceTitle)
            obj.put("propertyType", ord.propertyType)
            obj.put("areaEstimate", ord.areaEstimate)
            obj.put("details", ord.details)
            obj.put("status", ord.status)
            val imgArr = JSONArray()
            ord.images.forEach { imgArr.put(it) }
            obj.put("images", imgArr)
            jsonArr.put(obj)
        }
        prefs.edit().putString(KEY_MY_ORDERS, jsonArr.toString()).apply()

        // Also add to all orders pool for owner review
        saveToAllOrders(context, order)
    }

    fun getUserOrders(context: Context): List<QuoteRequest> {
        val prefs = getPrefs(context)
        val raw = prefs.getString(KEY_MY_ORDERS, null) ?: return emptyList()
        return parseOrdersJson(raw)
    }

    fun clearUserOrders(context: Context) {
        getPrefs(context).edit().remove(KEY_MY_ORDERS).apply()
    }

    // All Orders for Owner
    fun getAllOrders(context: Context): List<QuoteRequest> {
        val prefs = getPrefs(context)
        val raw = prefs.getString(KEY_ALL_ORDERS, null) ?: return getUserOrders(context)
        return parseOrdersJson(raw)
    }

    fun saveToAllOrders(context: Context, order: QuoteRequest) {
        val prefs = getPrefs(context)
        val list = getAllOrders(context).toMutableList()
        list.removeAll { it.id == order.id }
        list.add(0, order)

        val jsonArr = JSONArray()
        list.forEach { ord ->
            val obj = JSONObject()
            obj.put("id", ord.id)
            obj.put("createdAt", ord.createdAt)
            obj.put("clientName", ord.clientName)
            obj.put("phone", ord.phone)
            obj.put("city", ord.city)
            obj.put("serviceId", ord.serviceId)
            obj.put("serviceTitle", ord.serviceTitle)
            obj.put("propertyType", ord.propertyType)
            obj.put("areaEstimate", ord.areaEstimate)
            obj.put("details", ord.details)
            obj.put("status", ord.status)
            val imgArr = JSONArray()
            ord.images.forEach { imgArr.put(it) }
            obj.put("images", imgArr)
            jsonArr.put(obj)
        }
        prefs.edit().putString(KEY_ALL_ORDERS, jsonArr.toString()).apply()
    }

    fun updateOrderStatus(context: Context, orderId: String, newStatus: String) {
        val prefs = getPrefs(context)
        val list = getAllOrders(context).map {
            if (it.id == orderId) it.copy(status = newStatus) else it
        }
        val jsonArr = JSONArray()
        list.forEach { ord ->
            val obj = JSONObject()
            obj.put("id", ord.id)
            obj.put("createdAt", ord.createdAt)
            obj.put("clientName", ord.clientName)
            obj.put("phone", ord.phone)
            obj.put("city", ord.city)
            obj.put("serviceId", ord.serviceId)
            obj.put("serviceTitle", ord.serviceTitle)
            obj.put("propertyType", ord.propertyType)
            obj.put("areaEstimate", ord.areaEstimate)
            obj.put("details", ord.details)
            obj.put("status", ord.status)
            val imgArr = JSONArray()
            ord.images.forEach { imgArr.put(it) }
            obj.put("images", imgArr)
            jsonArr.put(obj)
        }
        prefs.edit().putString(KEY_ALL_ORDERS, jsonArr.toString()).apply()
    }

    private fun parseOrdersJson(raw: String): List<QuoteRequest> {
        val list = mutableListOf<QuoteRequest>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val images = mutableListOf<String>()
                if (obj.has("images")) {
                    val imgArr = obj.getJSONArray("images")
                    for (j in 0 until imgArr.length()) {
                        images.add(imgArr.getString(j))
                    }
                }
                list.add(
                    QuoteRequest(
                        id = obj.optString("id", "ORD"),
                        createdAt = obj.optString("createdAt", ""),
                        clientName = obj.optString("clientName", ""),
                        phone = obj.optString("phone", ""),
                        city = obj.optString("city", ""),
                        serviceId = obj.optString("serviceId", ""),
                        serviceTitle = obj.optString("serviceTitle", ""),
                        propertyType = obj.optString("propertyType", ""),
                        areaEstimate = obj.optString("areaEstimate", ""),
                        details = obj.optString("details", ""),
                        images = images,
                        status = obj.optString("status", "new")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    // Owner PIN check & change
    fun getOwnerPin(context: Context): String {
        return getPrefs(context).getString(KEY_OWNER_PIN, DEFAULT_PIN) ?: DEFAULT_PIN
    }

    fun setOwnerPin(context: Context, newPin: String) {
        getPrefs(context).edit().putString(KEY_OWNER_PIN, newPin).apply()
    }

    fun verifyOwnerPin(context: Context, inputPin: String): Boolean {
        val clean = normalizeDigits(inputPin)
        val current = normalizeDigits(getOwnerPin(context))
        return clean.isNotEmpty() && clean == current
    }

    fun normalizeDigits(input: String): String {
        return input.trim()
            .replace('٠', '0')
            .replace('١', '1')
            .replace('٢', '2')
            .replace('٣', '3')
            .replace('٤', '4')
            .replace('٥', '5')
            .replace('٦', '6')
            .replace('٧', '7')
            .replace('٨', '8')
            .replace('٩', '9')
            .replace(" ", "")
    }
}
