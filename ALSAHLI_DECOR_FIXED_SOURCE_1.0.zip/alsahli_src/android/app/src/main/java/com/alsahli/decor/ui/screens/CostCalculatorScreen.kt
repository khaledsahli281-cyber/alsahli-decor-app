package com.alsahli.decor.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alsahli.decor.data.DecorRepository
import com.alsahli.decor.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun CostCalculatorScreen(
    onClose: () -> Unit,
    onApplyToQuote: (String, Long) -> Unit
) {
    val formatter = NumberFormat.getNumberInstance(Locale.US)

    var selectedServiceId by remember { mutableStateOf(DecorRepository.SERVICES.first().id) }
    var areaMeters by remember { mutableStateOf(80f) }
    var qualityTier by remember { mutableStateOf("فاخر (نخب أول)") }

    val service = DecorRepository.SERVICES.find { it.id == selectedServiceId } ?: DecorRepository.SERVICES.first()

    val multiplier = when (qualityTier) {
        "اقتصادي نظيف" -> 0.85
        "فاخر (نخب أول)" -> 1.0
        "ملكي إيطالي VIP" -> 1.35
        else -> 1.0
    }

    val totalEstimateSyp = (service.estimatedPriceSyp * areaMeters * multiplier).toLong()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.End
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Slate900)
                    .clickable { onClose() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إغلاق",
                    tint = Color.White
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "حاسبة التكلفة التقديرية (ل.س)",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 17.sp
                )
                Text(
                    text = "احسب التكلفة التقريبية لمشروعك فوراً",
                    color = Slate400,
                    fontSize = 10.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Service Selection
        Text(
            text = "اختر نوع الخدمة:",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        DecorRepository.SERVICES.forEach { srv ->
            val isSel = selectedServiceId == srv.id
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSel) Amber500.copy(alpha = 0.2f) else Slate900)
                    .border(1.dp, if (isSel) Amber500 else Slate800, RoundedCornerShape(12.dp))
                    .clickable { selectedServiceId = srv.id }
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${formatter.format(srv.estimatedPriceSyp)} ل.س",
                        color = Amber400,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = srv.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Area Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${areaMeters.toInt()} متر مربع",
                color = Amber400,
                fontWeight = FontWeight.Black,
                fontSize = 14.sp
            )
            Text(
                text = "المساحة التقريبية للجدران/الأسقف:",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }

        Slider(
            value = areaMeters,
            onValueChange = { areaMeters = it },
            valueRange = 10f..500f,
            colors = SliderDefaults.colors(
                thumbColor = Amber500,
                activeTrackColor = Amber500,
                inactiveTrackColor = Slate800
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Quality Tier
        Text(
            text = "فئة المواد والتشطيب:",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("اقتصادي نظيف", "فاخر (نخب أول)", "ملكي إيطالي VIP").forEach { tier ->
                val active = qualityTier == tier
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (active) Amber500 else Slate900)
                        .border(1.dp, if (active) Amber500 else Slate800, RoundedCornerShape(10.dp))
                        .clickable { qualityTier = tier }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tier,
                        color = if (active) Slate950 else Slate300,
                        fontWeight = if (active) FontWeight.Black else FontWeight.Normal,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // Total Estimate Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Slate900)
                .border(1.dp, Amber500.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                .padding(18.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "التكلفة التقديرية الإجمالية للمشروع",
                    color = Slate300,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${formatter.format(totalEstimateSyp)} ل.س",
                    color = Amber400,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp
                )

                Text(
                    text = "تشمل المواد المتفق عليها وأجور اليد العاملة والضمان",
                    color = Slate400,
                    fontSize = 10.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        onApplyToQuote("${service.title} - مساحة ${areaMeters.toInt()} م² ($qualityTier)", totalEstimateSyp)
                        onClose()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber500),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "اعتماد هذه التقديرات وطلب المعاينة المجانية",
                        color = Slate950,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
