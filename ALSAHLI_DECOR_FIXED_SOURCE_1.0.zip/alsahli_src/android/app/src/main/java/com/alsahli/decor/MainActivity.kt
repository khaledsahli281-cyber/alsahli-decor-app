package com.alsahli.decor

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.alsahli.decor.data.DecorRepository
import com.alsahli.decor.ui.components.AppBottomNav
import com.alsahli.decor.ui.components.AppHeader
import com.alsahli.decor.ui.components.ImageViewerDialog
import com.alsahli.decor.ui.screens.*
import com.alsahli.decor.ui.theme.AlsahliDecorTheme
import com.alsahli.decor.ui.theme.Amber500
import com.alsahli.decor.ui.theme.Slate400
import com.alsahli.decor.ui.theme.Slate800
import com.alsahli.decor.ui.theme.Slate900
import com.alsahli.decor.ui.theme.Slate950

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AlsahliDecorTheme {
                MainAppScreen()
            }
        }
    }
}

@Composable
fun MainAppScreen() {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf("home") }
    var selectedServiceIdForQuote by remember { mutableStateOf<String?>(null) }

    var isCalculatorOpen by remember { mutableStateOf(false) }
    var isColorsOpen by remember { mutableStateOf(false) }
    var isMyOrdersOpen by remember { mutableStateOf(false) }
    var isOwnerLoginOpen by remember { mutableStateOf(false) }
    var isOwnerLoggedIn by remember { mutableStateOf(false) }

    var selectedImageUrl by remember { mutableStateOf<String?>(null) }
    var selectedImageTitle by remember { mutableStateOf<String?>(null) }

    var ownerPinInput by remember { mutableStateOf("") }
    var ownerLoginError by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header (Only show when not in Owner Dashboard)
            if (activeTab != "owner") {
                AppHeader(
                    isOwnerLoggedIn = isOwnerLoggedIn,
                    ordersCount = 0,
                    onOpenOwnerDashboard = { activeTab = "owner" },
                    onOpenOwnerLogin = {
                        isOwnerLoginOpen = true
                        ownerLoginError = ""
                        ownerPinInput = ""
                    },
                    onOpenOrders = { isMyOrdersOpen = true }
                )
            }

            // Body Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (activeTab) {
                    "home" -> HomeScreen(
                        onNavigateTab = { tab -> activeTab = tab },
                        onOpenCalculator = { isCalculatorOpen = true },
                        onOpenColors = { isColorsOpen = true },
                        onOpenMyOrders = { isMyOrdersOpen = true },
                        onSelectService = { srvId ->
                            selectedServiceIdForQuote = srvId
                            activeTab = "quote"
                        },
                        onOpenImage = { url, title ->
                            selectedImageUrl = url
                            selectedImageTitle = title
                        }
                    )
                    "services" -> ServicesScreen(
                        onSelectServiceForQuote = { srvId ->
                            selectedServiceIdForQuote = srvId
                            activeTab = "quote"
                        }
                    )
                    "gallery" -> GalleryScreen(
                        onOpenImage = { url, title ->
                            selectedImageUrl = url
                            selectedImageTitle = title
                        },
                        onSelectServiceForQuote = { srvId ->
                            selectedServiceIdForQuote = srvId
                            activeTab = "quote"
                        }
                    )
                    "quote" -> QuoteScreen(
                        initialServiceId = selectedServiceIdForQuote,
                        onOpenImage = { url, title ->
                            selectedImageUrl = url
                            selectedImageTitle = title
                        },
                        onOrderSubmittedSuccess = {
                            // order saved to local repository
                        }
                    )
                    "contact" -> ContactScreen()
                    "owner" -> OwnerDashboardScreen(
                        onExit = { activeTab = "home" },
                        onLogout = {
                            isOwnerLoggedIn = false
                            activeTab = "home"
                        },
                        onOpenImage = { url, title ->
                            selectedImageUrl = url
                            selectedImageTitle = title
                        }
                    )
                }
            }

            // Bottom Navigation (Hide in Owner Dashboard)
            if (activeTab != "owner") {
                AppBottomNav(
                    activeTab = activeTab,
                    onTabSelected = { tab ->
                        if (tab == "quote") {
                            selectedServiceIdForQuote = null
                        }
                        activeTab = tab
                    }
                )
            }
        }

        // Full Screen Image Viewer Dialog
        if (selectedImageUrl != null) {
            ImageViewerDialog(
                imageUrl = selectedImageUrl,
                title = selectedImageTitle,
                onDismiss = {
                    selectedImageUrl = null
                    selectedImageTitle = null
                }
            )
        }

        // Calculator Modal
        if (isCalculatorOpen) {
            Dialog(onDismissRequest = { isCalculatorOpen = false }) {
                CostCalculatorScreen(
                    onClose = { isCalculatorOpen = false },
                    onApplyToQuote = { serviceDetails, estimatedCost ->
                        selectedServiceIdForQuote = null
                        activeTab = "quote"
                    }
                )
            }
        }

        // Color Palette Modal
        if (isColorsOpen) {
            Dialog(onDismissRequest = { isColorsOpen = false }) {
                ColorPaletteScreen(onClose = { isColorsOpen = false })
            }
        }

        // My Orders Modal
        if (isMyOrdersOpen) {
            Dialog(onDismissRequest = { isMyOrdersOpen = false }) {
                MyOrdersScreen(
                    onClose = { isMyOrdersOpen = false },
                    onOpenImage = { url, title ->
                        selectedImageUrl = url
                        selectedImageTitle = title
                    }
                )
            }
        }

        // Owner PIN Login Dialog
        if (isOwnerLoginOpen) {
            Dialog(onDismissRequest = { isOwnerLoginOpen = false }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(Slate900)
                        .padding(20.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "تسجيل دخول المالك",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "أدخل رمز الأمان السري للوصول للوحة التحكم:",
                            color = Slate400,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = ownerPinInput,
                            onValueChange = { ownerPinInput = it; ownerLoginError = "" },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Amber500,
                                unfocusedBorderColor = Slate800,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        if (ownerLoginError.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = ownerLoginError,
                                color = com.alsahli.decor.ui.theme.Rose400,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val clean = DecorRepository.normalizeDigits(ownerPinInput)
                                val current = DecorRepository.normalizeDigits(DecorRepository.getOwnerPin(context))
                                if (clean.isNotEmpty() && clean == current) {
                                    isOwnerLoggedIn = true
                                    isOwnerLoginOpen = false
                                    activeTab = "owner"
                                } else {
                                    ownerLoginError = "رمز PIN غير صحيح!"
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Amber500),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "تأكيد الدخول",
                                color = Slate950,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
